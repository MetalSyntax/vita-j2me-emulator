/*
 * Copyright  1990-2007 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions.
 */

/* This file is auto-generated. Do not edit*/



#ifndef _ROM_STRUCTS_H_
#define _ROM_STRUCTS_H_

#ifdef __cplusplus
extern "C" {
#endif
#define _ROM_STRUCTS_VERSION_ "internal"

/* Define JVM_LIMIT_OBJECT_FIELD_WRITES=0 if your C
   compiler does not allow the 'const' modifier
   in the ROM structs */
#ifndef JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_LIMIT_OBJECT_FIELD_WRITES 0 /* IMPL_NOTE: TMP */
#endif
#if !JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_FIELD_CONST
#else
#define JVM_FIELD_CONST const
#endif

typedef struct {
    void * dummy;
    int length;
    jboolean elements[1];
} jboolean_array;
typedef struct {
    void * dummy;
    int length;
    jchar elements[1];
} jchar_array;
typedef struct {
    void * dummy;
    int length;
    jbyte elements[1];
} jbyte_array;
typedef struct {
    void * dummy;
    int length;
    jshort elements[1];
} jshort_array;
typedef struct {
    void * dummy;
    int length;
    jint elements[1];
} jint_array;
typedef struct {
    void * dummy;
    int length;
    jlong elements[1];
} jlong_array;
typedef struct {
    void * dummy;
    int length;
    struct Java_java_lang_Object * JVM_FIELD_CONST elements[1];
} jobject_array;
typedef struct {
    void * dummy;
    int length;
    jfloat elements[1];
} jfloat_array;
typedef struct {
    void * dummy;
    int length;
    jdouble elements[1];
} jdouble_array;

struct Java_java_lang_Object {
    /* java/lang/Object */
	void * __do_not_use__;
};

struct Java_java_lang_String {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/String */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint offset;
    /* @12 */	jint count;
};

struct Java_java_lang_Class {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Class */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST vmClass;
    /*  @8 */	jint status;
    /* @12 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
};

struct Java_java_lang_StringBuffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/StringBuffer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint count;
    /* @12 */	jboolean shared;
    /* @13 */	jbyte ___pad1;
    /* @14 */	jbyte ___pad2;
    /* @15 */	jbyte ___pad3;
};

struct Java_java_lang_Thread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
};

struct Java_java_lang_Throwable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
};

struct Java_java_lang_Error {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
};

struct Java_java_io_InputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
};

struct Java_java_io_PrintStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/PrintStream */
    /*  @4 */	struct Java_java_io_OutputStreamWriter * JVM_FIELD_CONST charOut;
    /*  @8 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST byteOut;
    /* @12 */	jboolean trouble;
    /* @13 */	jboolean closing;
    /* @14 */	jbyte ___pad4;
    /* @15 */	jbyte ___pad5;
};

struct Java_java_io_OutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
};

struct Java_java_lang_Runtime {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runtime */
};

struct Java_java_lang_System {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/System */
};

struct Java_java_lang_Math {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Math */
};

struct Java_com_sun_cldchi_jvm_JVM {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/JVM */
};

struct Java_com_sun_cldchi_jvm_FileDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/FileDescriptor */
    /*  @4 */	jint handle;
    /*  @8 */	jint valid;
};

struct Java_java_lang_ref_Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
};

struct Java_java_lang_ref_WeakReference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
    /* java/lang/ref/WeakReference */
    /*  @4 */	jint referent_index;
};

struct Java_java_lang_VirtualMachineError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
};

struct Java_java_lang_OutOfMemoryError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
    /* java/lang/OutOfMemoryError */
};

struct Java_java_lang_Runnable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runnable */
};

struct Java_java_lang_Exception {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
};

struct Java_java_lang_RuntimeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
};

struct Java_java_lang_NullPointerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NullPointerException */
};

struct Java_java_lang_IndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
};

struct Java_java_lang_ArrayIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/ArrayIndexOutOfBoundsException */
};

struct Java_java_lang_IllegalMonitorStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalMonitorStateException */
};

struct Java_java_lang_ArithmeticException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArithmeticException */
};

struct Java_com_sun_cldc_isolate_Isolate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Isolate */
    /*  @4 */	jint _priority;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST _next;
    /* @12 */	jlong _uniqueId;
    /* @20 */	jint _terminated;
    /* @24 */	jint _saved_exit_code;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST _mainClass;
    /* @32 */	jobject_array * JVM_FIELD_CONST _mainArgs;
    /* @36 */	jobject_array * JVM_FIELD_CONST _app_classpath;
    /* @40 */	jobject_array * JVM_FIELD_CONST _sys_classpath;
    /* @44 */	jobject_array * JVM_FIELD_CONST _hidden_packages;
    /* @48 */	jobject_array * JVM_FIELD_CONST _restricted_packages;
    /* @52 */	jint _memoryReserve;
    /* @56 */	jint _memoryLimit;
    /* @60 */	jint _APIAccess;
    /* @64 */	jint _ConnectDebugger;
    /* @68 */	jint _UseVerifier;
    /* @72 */	jint _profileId;
};

struct Java_java_lang_IllegalArgumentException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
};

struct Java_java_io_IOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
};

struct Java_java_util_Hashtable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST table;
    /*  @8 */	jint count;
    /* @12 */	jint threshold;
};

struct Java_com_sun_cldc_io_ResourceInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/cldc/io/ResourceInputStream */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST fileDecoder;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST savedDecoder;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @16 */	jint pos;
    /* @20 */	jint mark;
};

struct Java_java_lang_InterruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InterruptedException */
};

struct Java_java_lang_NoClassDefFoundError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/NoClassDefFoundError */
};

struct Java_com_sun_cldc_isolate_IsolateResourceError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* com/sun/cldc/isolate/IsolateResourceError */
};

struct Java_com_sun_cldc_isolate_IsolateStartupException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/cldc/isolate/IsolateStartupException */
};

struct Java_java_lang_SecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/SecurityException */
};

struct Java_com_sun_cldc_isolate_IllegalIsolateStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* com/sun/cldc/isolate/IllegalIsolateStateException */
};

struct Java_java_lang_StringIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/StringIndexOutOfBoundsException */
};

struct Java_com_sun_cldc_util_SemaphoreLock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/SemaphoreLock */
    /*  @4 */	jint permits;
};

struct Java_com_sun_cldc_util_Semaphore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/Semaphore */
    /*  @4 */	struct Java_com_sun_cldc_util_SemaphoreLock * JVM_FIELD_CONST lock;
};

struct Java_com_nokia_mid_sound_Sound {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/sound/Sound */
    /*  @4 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST m_player;
    /*  @8 */	struct Java_com_nokia_mid_sound_Sound * JVM_FIELD_CONST m_instance;
    /* @12 */	struct Java_com_nokia_mid_sound_SoundListener * JVM_FIELD_CONST listener;
    /* @16 */	jint status;
    /* @20 */	jint type;
    /* @24 */	jint dataLen;
};

struct Java_com_nokia_mid_sound_SoundListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/sound/SoundListener */
};

struct Java_javax_microedition_media_Player {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Player */
};

struct Java_javax_microedition_media_PlayerListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/PlayerListener */
};

struct Java_com_nokia_mid_sound_Sound_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/sound/Sound$1 */
    /*  @4 */	struct Java_com_nokia_mid_sound_Sound * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_media_Control {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Control */
};

struct Java_java_io_ByteArrayInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/ByteArrayInputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint pos;
    /* @12 */	jint mark;
    /* @16 */	jint count;
};

struct Java_com_nokia_mid_ui_DeviceControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/ui/DeviceControl */
};

struct Java_javax_microedition_lcdui_Image {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Image */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageData;
};

struct Java_com_nokia_mid_ui_DirectGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/ui/DirectGraphics */
};

struct Java_javax_microedition_lcdui_Graphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Graphics */
    /*  @4 */	jint transX;
    /*  @8 */	jint transY;
    /* @12 */	jint ax;
    /* @16 */	jint ay;
    /* @20 */	jint rgbColor;
    /* @24 */	jint gray;
    /* @28 */	jint pixel;
    /* @32 */	jint style;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST currentFont;
    /* @40 */	jint displayId;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST img;
    /* @48 */	struct Java_java_lang_Object * JVM_FIELD_CONST creator;
    /* @52 */	jshort clipX1;
    /* @54 */	jshort clipY1;
    /* @56 */	jshort clipX2;
    /* @58 */	jshort clipY2;
    /* @60 */	jshort systemClipX1;
    /* @62 */	jshort systemClipY1;
    /* @64 */	jshort systemClipX2;
    /* @66 */	jshort systemClipY2;
    /* @68 */	jshort maxWidth;
    /* @70 */	jshort maxHeight;
    /* @72 */	jboolean clipped;
    /* @73 */	jboolean runtimeClipEnforce;
    /* @74 */	jbyte ___pad6;
    /* @75 */	jbyte ___pad7;
};

struct Java_com_nokia_mid_ui_DirectGraphicsImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/ui/DirectGraphicsImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST graphics;
};

struct Java_com_nokia_mid_ui_DirectUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/nokia/mid/ui/DirectUtils */
};

struct Java_javax_microedition_lcdui_Command {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
};

struct Java_javax_microedition_lcdui_CommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CommandListener */
};

struct Java_javax_microedition_lcdui_CanvasLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CanvasLF */
};

struct Java_javax_microedition_lcdui_DisplayableLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLF */
};

struct Java_javax_microedition_lcdui_Canvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad8;
    /* @31 */	jbyte ___pad9;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad10;
    /* @38 */	jbyte ___pad11;
    /* @39 */	jbyte ___pad12;
};

struct Java_javax_microedition_lcdui_LFFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
};

struct Java_javax_microedition_lcdui_Ticker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Ticker */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST message;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayedMessage;
    /* @12 */	struct Java_javax_microedition_lcdui_TickerLF * JVM_FIELD_CONST tickerLF;
};

struct Java_javax_microedition_lcdui_Item {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
};

struct Java_javax_microedition_lcdui_Displayable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad13;
    /* @31 */	jbyte ___pad14;
};

struct Java_com_nokia_mid_ui_FullCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad15;
    /* @31 */	jbyte ___pad16;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad17;
    /* @38 */	jbyte ___pad18;
    /* @39 */	jbyte ___pad19;
    /* com/nokia/mid/ui/FullCanvas */
};

struct Java_com_pspkvm_keypad_KeyMapInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/keypad/KeyMapInfo */
};

struct Java_com_pspkvm_keypad_PSPCtrlCodes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/keypad/PSPCtrlCodes */
};

struct Java_com_pspkvm_keypad_RawState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/keypad/RawState */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_Associational1 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/Associational1 */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_Associational2 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/Associational2 */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_Associational {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/Associational */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_PYNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/PYNode */
    /*  @4 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_PYNode * JVM_FIELD_CONST father;
    /*  @8 */	jobject_array * JVM_FIELD_CONST next;
    /* @12 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_Hanzi * JVM_FIELD_CONST listHead;
    /* @16 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_Hanzi * JVM_FIELD_CONST current;
    /* @20 */	jint numOfCharacter;
    /* @24 */	jchar symbol;
    /* @25 */	jbyte ___pad20;
    /* @26 */	jbyte ___pad21;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_Hanzi {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/Hanzi */
    /*  @4 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_Hanzi * JVM_FIELD_CONST pre;
    /*  @8 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_Hanzi * JVM_FIELD_CONST next;
    /* @12 */	jchar code;
    /* @13 */	jbyte ___pad22;
    /* @14 */	jbyte ___pad23;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_CNLib {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/CNLib */
    /*  @4 */	jchar_array * JVM_FIELD_CONST charTable;
    /*  @8 */	jobject_array * JVM_FIELD_CONST pinyin;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeLib {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/strokeLib */
    /*  @4 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeNode * JVM_FIELD_CONST Hz;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_IMCandidateBar {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/IMCandidateBar */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST pinyin;
    /*  @8 */	jint cur_pos;
    /* @12 */	jint cur_sel;
    /* @16 */	jchar_array * JVM_FIELD_CONST cur_candidates;
    /* @20 */	jchar_array * JVM_FIELD_CONST cur_stroke;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_pinyinTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/pinyinTable */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/strokeNode */
    /*  @4 */	jchar_array * JVM_FIELD_CONST ret;
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeLib1 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/strokeLib1 */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeLib2 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/strokeLib2 */
};

struct Java_com_pspkvm_midp_lcdui_vk_awf_strokeNode1 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/awf/strokeNode1 */
    /*  @4 */	jchar_array * JVM_FIELD_CONST ret;
};

struct Java_com_pspkvm_midp_lcdui_vk_qwert_PYNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/qwert/PYNode */
    /*  @4 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_PYNode * JVM_FIELD_CONST father;
    /*  @8 */	jobject_array * JVM_FIELD_CONST next;
    /* @12 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_Hanzi * JVM_FIELD_CONST listHead;
    /* @16 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_Hanzi * JVM_FIELD_CONST current;
    /* @20 */	jint numOfCharacter;
    /* @24 */	jchar symbol;
    /* @25 */	jbyte ___pad24;
    /* @26 */	jbyte ___pad25;
};

struct Java_com_pspkvm_midp_lcdui_vk_qwert_Hanzi {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/qwert/Hanzi */
    /*  @4 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_Hanzi * JVM_FIELD_CONST pre;
    /*  @8 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_Hanzi * JVM_FIELD_CONST next;
    /* @12 */	jchar code;
    /* @13 */	jbyte ___pad26;
    /* @14 */	jbyte ___pad27;
};

struct Java_com_pspkvm_midp_lcdui_vk_qwert_CNLib {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/qwert/CNLib */
    /*  @4 */	jchar_array * JVM_FIELD_CONST charTable;
};

struct Java_com_pspkvm_midp_lcdui_vk_qwert_IMCandidateBar {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/qwert/IMCandidateBar */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST pinyin;
    /*  @8 */	jint cur_pos;
    /* @12 */	jint cur_sel;
    /* @16 */	jchar_array * JVM_FIELD_CONST cur_candidates;
};

struct Java_com_pspkvm_midp_lcdui_vk_qwert_pinyinTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/midp/lcdui/vk/qwert/pinyinTable */
};

struct Java_javax_microedition_lcdui_ChoiceGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @56 */	jint choiceType;
    /* @60 */	jint fitPolicy;
    /* @64 */	jint numOfEls;
    /* @68 */	jobject_array * JVM_FIELD_CONST cgElements;
};

struct Java_javax_microedition_lcdui_Choice {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Choice */
};

struct Java_javax_microedition_lcdui_FormLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/FormLF */
};

struct Java_javax_microedition_lcdui_ItemStateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemStateListener */
};

struct Java_javax_microedition_lcdui_Screen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad28;
    /* @31 */	jbyte ___pad29;
    /* javax/microedition/lcdui/Screen */
};

struct Java_javax_microedition_lcdui_Form {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad30;
    /* @31 */	jbyte ___pad31;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
};

struct Java_javax_microedition_lcdui_TextField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/TextField */
    /* @52 */	jint selectionStart;
    /* @56 */	jint selectionLength;
    /* @60 */	struct Java_javax_microedition_lcdui_TextFieldLF * JVM_FIELD_CONST textFieldLF;
    /* @64 */	struct Java_com_sun_midp_lcdui_DynamicCharacterArray * JVM_FIELD_CONST buffer;
    /* @68 */	jint constraints;
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
};

struct Java_com_pspkvm_system_VMSettingsForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad32;
    /* @31 */	jbyte ___pad33;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/pspkvm/system/VMSettingsForm */
};

struct Java_com_pspkvm_system_FontSettingsForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad34;
    /* @31 */	jbyte ___pad35;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/pspkvm/system/VMSettingsForm */
    /* com/pspkvm/system/FontSettingsForm */
    /* @48 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST useInternal;
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST fsSmall;
    /* @56 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST fsMed;
    /* @60 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST fsLarge;
};

struct Java_javax_microedition_lcdui_ChoiceGroup_00024CGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroup$CGElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST stringEl;
    /*  @8 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST imageEl;
    /* @12 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImageEl;
    /* @16 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageDataEl;
    /* @20 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST fontEl;
    /* @24 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST this_0440;
    /* @28 */	jboolean selected;
    /* @29 */	jbyte ___pad36;
    /* @30 */	jbyte ___pad37;
    /* @31 */	jbyte ___pad38;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroupLF */
};

struct Java_javax_microedition_lcdui_ItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLF */
};

struct Java_javax_microedition_lcdui_Font {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Font */
    /*  @4 */	jint face;
    /*  @8 */	jint style;
    /* @12 */	jint size;
    /* @16 */	jint baseline;
    /* @20 */	jint height;
};

struct Java_javax_microedition_lcdui_ItemCommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemCommandListener */
};

struct Java_com_pspkvm_system_KeymapSettingsForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad39;
    /* @31 */	jbyte ___pad40;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/pspkvm/system/VMSettingsForm */
    /* com/pspkvm/system/KeymapSettingsForm */
    /* @48 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST defaultKeymap;
};

struct Java_com_pspkvm_system_Power {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/system/Power */
};

struct Java_com_pspkvm_system_VKSettingsForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad41;
    /* @31 */	jbyte ___pad42;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/pspkvm/system/VMSettingsForm */
    /* com/pspkvm/system/VKSettingsForm */
    /* @48 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST boardType;
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST defaultSCMap;
    /* @56 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST defaultAWFMap;
    /* @60 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST optionsGroup;
};

struct Java_javax_microedition_lcdui_List {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad43;
    /* @31 */	jbyte ___pad44;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/List */
    /* @32 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectCommand;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST listLF;
};

struct Java_javax_microedition_midlet_MIDlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
};

struct Java_javax_microedition_lcdui_Display {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display */
    /*  @4 */	jint displayId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST nameOfOwner;
    /* @12 */	struct Java_javax_microedition_lcdui_Display_00024DisplayAccessImpl * JVM_FIELD_CONST accessor;
    /* @16 */	struct Java_javax_microedition_lcdui_Display_00024DisplayEventConsumerImpl * JVM_FIELD_CONST consumer;
    /* @20 */	struct Java_javax_microedition_lcdui_Display_00024ForegroundEventConsumerImpl * JVM_FIELD_CONST foregroundConsumer;
    /* @24 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST cham_tunnel;
    /* @28 */	jint_array * JVM_FIELD_CONST region;
    /* @32 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST inputSession;
    /* @36 */	struct Java_com_sun_midp_chameleon_layers_PTILayer * JVM_FIELD_CONST pt_popup;
    /* @40 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @44 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer * JVM_FIELD_CONST keyboardLayer;
    /* @48 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST screenGraphics;
    /* @52 */	jint wantsForeground;
    /* @56 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST initialDisplayable;
    /* @60 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST current;
    /* @64 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST transitionCurrent;
    /* @68 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST pendingCurrent;
    /* @72 */	struct Java_com_sun_midp_chameleon_MIDPWindow * JVM_FIELD_CONST window;
    /* @76 */	struct Java_com_sun_midp_chameleon_CGraphicsQ * JVM_FIELD_CONST graphicsQ;
    /* @80 */	jboolean screenModeKnown;
    /* @81 */	jboolean isRotatedKnown;
    /* @82 */	jboolean wantRotation;
    /* @83 */	jboolean lastFullScnMode;
    /* @84 */	jboolean hasForeground;
    /* @85 */	jboolean paintSuspended;
    /* @86 */	jbyte ___pad45;
    /* @87 */	jbyte ___pad46;
};

struct Java_com_sun_midp_security_SecurityToken {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityToken */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
};

struct Java_com_sun_midp_midlet_MIDletPeer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletPeer */
    /*  @4 */	jint state;
    /*  @8 */	struct Java_javax_microedition_midlet_MIDlet * JVM_FIELD_CONST midlet;
};

struct Java_com_sun_midp_midlet_MIDletSuite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletSuite */
};

struct Java_com_sun_midp_midlet_MIDletTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletTunnel */
};

struct Java_com_sun_midp_security_ImplicitlyTrustedClass {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/ImplicitlyTrustedClass */
};

struct Java_javax_microedition_midlet_MIDlet_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet$1 */
};

struct Java_com_pspkvm_system_VMConfigMidlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/pspkvm/system/VMConfigMidlet */
    /*  @8 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST selector;
};

struct Java_com_pspkvm_system_VMSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/system/VMSettings */
};

struct Java_com_pspkvm_system_WifiStatus {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/pspkvm/system/WifiStatus */
};

struct Java_com_sun_cldc_i18n_StreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_cldc_i18n_StreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_java_io_Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
};

struct Java_java_io_Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
};

struct Java_com_sun_cldc_i18n_Helper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/Helper */
};

struct Java_java_io_UnsupportedEncodingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UnsupportedEncodingException */
};

struct Java_java_lang_ClassCastException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ClassCastException */
};

struct Java_java_lang_ClassNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/ClassNotFoundException */
};

struct Java_java_lang_InstantiationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InstantiationException */
};

struct Java_java_lang_IllegalAccessException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/IllegalAccessException */
};

struct Java_java_io_ByteArrayOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/ByteArrayOutputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint count;
    /* @12 */	jboolean isClosed;
    /* @13 */	jbyte ___pad47;
    /* @14 */	jbyte ___pad48;
    /* @15 */	jbyte ___pad49;
};

struct Java_com_sun_cldc_i18n_j2me_Conv {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/j2me/Conv */
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/Gen_Reader */
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @20 */	jint id;
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint maxByteLen;
    /* @32 */	jbyte_array * JVM_FIELD_CONST tmp;
    /* @36 */	jint pos;
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/Gen_Writer */
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @24 */	jint id;
    /* @28 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @32 */	jint maxByteLen;
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_16_Reader */
    /* @16 */	jint firstByte;
    /* @20 */	jint byteOrder;
    /* @24 */	jint markFirstByte;
    /* @28 */	jint markByteOrder;
    /* @32 */	jint bytesForBOM;
    /* @36 */	jboolean markIsSet;
    /* @37 */	jbyte ___pad50;
    /* @38 */	jbyte ___pad51;
    /* @39 */	jbyte ___pad52;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116BE_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_16_Reader */
    /* @16 */	jint firstByte;
    /* @20 */	jint byteOrder;
    /* @24 */	jint markFirstByte;
    /* @28 */	jint markByteOrder;
    /* @32 */	jint bytesForBOM;
    /* @36 */	jboolean markIsSet;
    /* @37 */	jbyte ___pad53;
    /* @38 */	jbyte ___pad54;
    /* @39 */	jbyte ___pad55;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116BE_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116LE_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_16_Reader */
    /* @16 */	jint firstByte;
    /* @20 */	jint byteOrder;
    /* @24 */	jint markFirstByte;
    /* @28 */	jint markByteOrder;
    /* @32 */	jint bytesForBOM;
    /* @36 */	jboolean markIsSet;
    /* @37 */	jbyte ___pad56;
    /* @38 */	jbyte ___pad57;
    /* @39 */	jbyte ___pad58;
    /* com/sun/cldc/i18n/j2me/UTF_16LE_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116LE_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Writer */
    /* com/sun/cldc/i18n/j2me/UTF_16LE_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Writer */
    /* com/sun/cldc/i18n/j2me/UTF_16_Writer */
    /* @20 */	jboolean addedBOM;
    /* @21 */	jbyte ___pad59;
    /* @22 */	jbyte ___pad60;
    /* @23 */	jbyte ___pad61;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_8_Reader */
    /* @16 */	jint_array * JVM_FIELD_CONST readAhead;
    /* @20 */	jint pendingSurrogate;
    /* @24 */	struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader_00024MarkInfo * JVM_FIELD_CONST markInfo;
    /* @28 */	jboolean markIsSet;
    /* @29 */	jbyte ___pad62;
    /* @30 */	jbyte ___pad63;
    /* @31 */	jbyte ___pad64;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader_00024MarkInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/j2me/UTF_8_Reader$MarkInfo */
    /*  @4 */	jint_array * JVM_FIELD_CONST readAhead;
    /*  @8 */	jint pendingSurrogate;
    /* @12 */	struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_8_Writer */
    /* @20 */	jint pendingSurrogate;
};

struct Java_com_sun_cldc_i18n_uclc_DefaultCaseConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/uclc/DefaultCaseConverter */
};

struct Java_javax_microedition_io_Connection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connection */
};

struct Java_com_sun_cldc_io_ConnectionBaseInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/io/ConnectionBaseInterface */
};

struct Java_com_sun_cldc_isolate_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Util */
};

struct Java_com_sun_cldc_isolate_Verifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Verifier */
};

struct Java_java_util_TimeZone {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
};

struct Java_java_util_Date {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Date */
    /*  @4 */	struct Java_java_util_Calendar * JVM_FIELD_CONST calendar;
    /*  @8 */	jlong fastTime;
};

struct Java_java_util_Calendar {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad65;
    /* @30 */	jbyte ___pad66;
    /* @31 */	jbyte ___pad67;
};

struct Java_com_sun_cldc_util_j2me_CalendarImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad68;
    /* @30 */	jbyte ___pad69;
    /* @31 */	jbyte ___pad70;
    /* com/sun/cldc/util/j2me/CalendarImpl */
};

struct Java_com_sun_cldc_util_j2me_TimeZoneImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
    /* com/sun/cldc/util/j2me/TimeZoneImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST ID;
    /*  @8 */	jint startMonth;
    /* @12 */	jint startDay;
    /* @16 */	jint startDayOfWeek;
    /* @20 */	jint startTime;
    /* @24 */	jint endMonth;
    /* @28 */	jint endDay;
    /* @32 */	jint endDayOfWeek;
    /* @36 */	jint endTime;
    /* @40 */	jint startYear;
    /* @44 */	jint rawOffset;
    /* @48 */	jint startMode;
    /* @52 */	jint endMode;
    /* @56 */	jint dstSavings;
    /* @60 */	jboolean isCustom;
    /* @61 */	jboolean useDaylight;
    /* @62 */	jbyte ___pad71;
    /* @63 */	jbyte ___pad72;
};

struct Java_com_sun_cldchi_io_ConsoleOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/cldchi/io/ConsoleOutputStream */
};

struct Java_javax_microedition_location_AddressInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/AddressInfo */
    /*  @4 */	jobject_array * JVM_FIELD_CONST data;
};

struct Java_javax_microedition_location_QualifiedCoordinates {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Coordinates */
    /*  @4 */	jdouble latitude;
    /* @12 */	jdouble longitude;
    /* @20 */	jfloat altitude;
    /* @24 */	jfloat azimuth;
    /* @28 */	jfloat distance;
    /* javax/microedition/location/QualifiedCoordinates */
    /* @32 */	jfloat horizontalAccuracy;
    /* @36 */	jfloat verticalAccuracy;
};

struct Java_java_io_DataOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/DataOutputStream */
    /*  @4 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_j2me_location_LandmarkImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LandmarkImpl */
    /*  @4 */	jobject_array * JVM_FIELD_CONST categories;
    /*  @8 */	jint recordId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST storeName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST description;
    /* @24 */	struct Java_javax_microedition_location_QualifiedCoordinates * JVM_FIELD_CONST coordinates;
    /* @28 */	struct Java_javax_microedition_location_AddressInfo * JVM_FIELD_CONST addressInfo;
};

struct Java_javax_microedition_location_Location {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Location */
};

struct Java_com_sun_j2me_location_LocationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Location */
    /* com/sun/j2me/location/LocationImpl */
    /*  @4 */	jlong timestamp;
    /* @12 */	struct Java_javax_microedition_location_QualifiedCoordinates * JVM_FIELD_CONST coordinates;
    /* @16 */	jfloat speed;
    /* @20 */	jfloat course;
    /* @24 */	jint method;
    /* @28 */	struct Java_javax_microedition_location_AddressInfo * JVM_FIELD_CONST address;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoNMEA;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoLIF;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoPlain;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoOther;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoOtherMIMEType;
    /* @52 */	jboolean isValid;
    /* @53 */	jbyte ___pad73;
    /* @54 */	jbyte ___pad74;
    /* @55 */	jbyte ___pad75;
};

struct Java_com_sun_j2me_location_LocationInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationInfo */
    /*  @4 */	jlong timestamp;
    /* @12 */	jdouble latitude;
    /* @20 */	jdouble longitude;
    /* @28 */	jfloat altitude;
    /* @32 */	jfloat horizontalAccuracy;
    /* @36 */	jfloat verticalAccuracy;
    /* @40 */	jfloat speed;
    /* @44 */	jfloat course;
    /* @48 */	jint method;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_EXTENSION;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_STREET;
    /* @60 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_POSTAL_CODE;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_CITY;
    /* @68 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_COUNTY;
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_STATE;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_COUNTRY;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_COUNTRY_CODE;
    /* @84 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_DISTRICT;
    /* @88 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_BUILDING_NAME;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_BUILDING_FLOOR;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_BUILDING_ROOM;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_BUILDING_ZONE;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_CROSSING1;
    /* @108 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_CROSSING2;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_URL;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST AddressInfo_PHONE_NUMBER;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoNMEA;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoLIF;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoPlain;
    /* @132 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoOther;
    /* @136 */	struct Java_java_lang_String * JVM_FIELD_CONST extraInfoOtherMIMEType;
    /* @140 */	jboolean isValid;
    /* @141 */	jboolean isAddressInfo;
    /* @142 */	jbyte ___pad76;
    /* @143 */	jbyte ___pad77;
};

struct Java_com_sun_j2me_location_LocationPersistentStorage_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationPersistentStorage$1 */
};

struct Java_java_util_Enumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Enumeration */
};

struct Java_com_sun_j2me_location_LocationPersistentStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationPersistentStorage */
};

struct Java_com_sun_j2me_location_LocationPersistentStorage_00024LandmarkEnumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationPersistentStorage$LandmarkEnumeration */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST category;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @12 */	jdouble minLatitude;
    /* @20 */	jdouble maxLatitude;
    /* @28 */	jdouble minLongitude;
    /* @36 */	jdouble maxLongitude;
    /* @44 */	struct Java_java_util_Enumeration * JVM_FIELD_CONST enumeration;
    /* @48 */	struct Java_com_sun_j2me_location_LocationPersistentStorage * JVM_FIELD_CONST this_0440;
};

struct Java_java_io_EOFException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/EOFException */
};

struct Java_com_sun_j2me_location_LocationPersistentStorage_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationPersistentStorage$SecurityTrusted */
};

struct Java_java_util_Vector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
};

struct Java_com_sun_midp_rms_RecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreImpl */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST compactBuffer;
    /*  @8 */	jint suiteId;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST rsLock;
    /* @16 */	jbyte_array * JVM_FIELD_CONST dbHeader;
    /* @20 */	struct Java_com_sun_midp_rms_RecordStoreIndex * JVM_FIELD_CONST dbIndex;
    /* @24 */	struct Java_com_sun_midp_rms_RecordStoreFile * JVM_FIELD_CONST dbFile;
};

struct Java_javax_microedition_rms_RecordStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
};

struct Java_javax_microedition_rms_RecordStoreNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotFoundException */
};

struct Java_javax_microedition_location_LandmarkException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/location/LandmarkException */
};

struct Java_javax_microedition_rms_InvalidRecordIDException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/InvalidRecordIDException */
};

struct Java_com_sun_j2me_location_LocationProviderImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/LocationProvider */
    /* com/sun/j2me/location/LocationProviderImpl */
    /*  @4 */	struct Java_javax_microedition_location_LocationListener * JVM_FIELD_CONST locationListener;
    /*  @8 */	struct Java_javax_microedition_location_Criteria * JVM_FIELD_CONST criteria;
    /* @12 */	struct Java_com_sun_j2me_location_LocationThread * JVM_FIELD_CONST locationThread;
    /* @16 */	struct Java_com_sun_j2me_location_StateThread * JVM_FIELD_CONST stateThread;
    /* @20 */	jint locationQueries;
    /* @24 */	jboolean resetRequested;
    /* @25 */	jbyte ___pad78;
    /* @26 */	jbyte ___pad79;
    /* @27 */	jbyte ___pad80;
};

struct Java_javax_microedition_location_Criteria {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Criteria */
    /*  @4 */	jint preferredPowerConsumption;
    /*  @8 */	jint horizontalAccuracy;
    /* @12 */	jint verticalAccuracy;
    /* @16 */	jint preferredResponseTime;
    /* @20 */	jboolean allowedToCost;
    /* @21 */	jboolean speedAndCourseRequired;
    /* @22 */	jboolean altitudeRequired;
    /* @23 */	jboolean addressInfoRequired;
};

struct Java_javax_microedition_location_LocationListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/LocationListener */
};

struct Java_com_sun_j2me_location_LocationThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/j2me/location/LocationThread */
    /* @28 */	struct Java_com_sun_j2me_location_LocationProviderImpl * JVM_FIELD_CONST provider;
    /* @32 */	struct Java_javax_microedition_location_Location * JVM_FIELD_CONST LastKnownLocation;
    /* @36 */	struct Java_javax_microedition_location_LocationListener * JVM_FIELD_CONST listener;
    /* @40 */	jint interval;
    /* @44 */	jint timeout;
    /* @48 */	jint maxAge;
    /* @52 */	jboolean terminated;
    /* @53 */	jbyte ___pad81;
    /* @54 */	jbyte ___pad82;
    /* @55 */	jbyte ___pad83;
};

struct Java_com_sun_j2me_location_StateThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/j2me/location/StateThread */
    /* @28 */	struct Java_com_sun_j2me_location_LocationProviderImpl * JVM_FIELD_CONST provider;
    /* @32 */	struct Java_javax_microedition_location_LocationListener * JVM_FIELD_CONST listener;
    /* @36 */	jboolean terminated;
    /* @37 */	jbyte ___pad84;
    /* @38 */	jbyte ___pad85;
    /* @39 */	jbyte ___pad86;
};

struct Java_javax_microedition_location_ProximityListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/ProximityListener */
};

struct Java_javax_microedition_location_Coordinates {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Coordinates */
    /*  @4 */	jdouble latitude;
    /* @12 */	jdouble longitude;
    /* @20 */	jfloat altitude;
    /* @24 */	jfloat azimuth;
    /* @28 */	jfloat distance;
};

struct Java_com_sun_j2me_location_ProximityNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/ProximityNotifier */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST proximityListeners;
    /*  @8 */	struct Java_com_sun_j2me_location_ProximityThread * JVM_FIELD_CONST proximityThread;
    /* @12 */	struct Java_com_sun_j2me_location_StateMonitorThread * JVM_FIELD_CONST stateThread;
    /* @16 */	struct Java_com_sun_j2me_location_LocationProviderImpl * JVM_FIELD_CONST proximityProvider;
};

struct Java_javax_microedition_location_LocationProvider {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/LocationProvider */
};

struct Java_javax_microedition_location_LocationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/location/LocationException */
};

struct Java_com_sun_j2me_location_LocationProviderInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/LocationProviderInfo */
    /*  @4 */	jint powerConsumption;
    /*  @8 */	jint horizontalAccuracy;
    /* @12 */	jint verticalAccuracy;
    /* @16 */	jint defaultTimeout;
    /* @20 */	jint defaultMaxAge;
    /* @24 */	jint defaultInterval;
    /* @28 */	jint averageResponseTime;
    /* @32 */	jint defaultStateInterval;
    /* @36 */	jboolean incurCost;
    /* @37 */	jboolean canReportAltitude;
    /* @38 */	jboolean canReportAddressInfo;
    /* @39 */	jboolean canReportSpeedCource;
};

struct Java_com_sun_j2me_location_OrientationProvider {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/OrientationProvider */
};

struct Java_javax_microedition_location_Orientation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Orientation */
    /*  @4 */	jfloat azimuth;
    /*  @8 */	jfloat pitch;
    /* @12 */	jfloat roll;
    /* @16 */	jboolean isMagnetic;
    /* @17 */	jbyte ___pad87;
    /* @18 */	jbyte ___pad88;
    /* @19 */	jbyte ___pad89;
};

struct Java_com_sun_j2me_location_PlatformLocationProvider {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/LocationProvider */
    /* com/sun/j2me/location/LocationProviderImpl */
    /*  @4 */	struct Java_javax_microedition_location_LocationListener * JVM_FIELD_CONST locationListener;
    /*  @8 */	struct Java_javax_microedition_location_Criteria * JVM_FIELD_CONST criteria;
    /* @12 */	struct Java_com_sun_j2me_location_LocationThread * JVM_FIELD_CONST locationThread;
    /* @16 */	struct Java_com_sun_j2me_location_StateThread * JVM_FIELD_CONST stateThread;
    /* @20 */	jint locationQueries;
    /* @24 */	jboolean resetRequested;
    /* @25 */	jbyte ___pad90;
    /* @26 */	jbyte ___pad91;
    /* @27 */	jbyte ___pad92;
    /* com/sun/j2me/location/PlatformLocationProvider */
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST providerName;
    /* @32 */	jint provider;
    /* @36 */	struct Java_com_sun_j2me_location_LocationProviderInfo * JVM_FIELD_CONST providerInfo;
    /* @40 */	jint i3testProviderState;
    /* @44 */	struct Java_com_sun_j2me_location_LocationImpl * JVM_FIELD_CONST i3testLocation;
};

struct Java_com_sun_j2me_location_ProximityNotifier_00024ProximityListenerDecorator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/ProximityNotifier$ProximityListenerDecorator */
    /*  @4 */	struct Java_javax_microedition_location_ProximityListener * JVM_FIELD_CONST listener;
    /*  @8 */	struct Java_javax_microedition_location_Coordinates * JVM_FIELD_CONST coordinates;
    /* @12 */	jfloat proximityRadius;
};

struct Java_com_sun_j2me_location_ProximityThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/j2me/location/ProximityThread */
    /* @28 */	jboolean terminated;
    /* @29 */	jbyte ___pad93;
    /* @30 */	jbyte ___pad94;
    /* @31 */	jbyte ___pad95;
};

struct Java_com_sun_j2me_location_StateMonitorThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/j2me/location/StateMonitorThread */
    /* @28 */	jboolean terminated;
    /* @29 */	jbyte ___pad96;
    /* @30 */	jbyte ___pad97;
    /* @31 */	jbyte ___pad98;
};

struct Java_com_sun_midp_midlet_Scheduler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/Scheduler */
};

struct Java_com_sun_j2me_location_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/location/Util */
};

struct Java_com_sun_j2me_security_AccessControlContext {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/security/AccessControlContext */
};

struct Java_com_sun_j2me_security_AccessControlContextAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/security/AccessControlContextAdapter */
};

struct Java_com_sun_j2me_security_InterruptedSecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/SecurityException */
    /* com/sun/j2me/security/InterruptedSecurityException */
};

struct Java_com_sun_j2me_security_AccessController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/security/AccessController */
};

struct Java_com_sun_j2mews_xml_rpc_Constants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2mews/xml/rpc/Constants */
};

struct Java_com_sun_j2mews_xml_rpc_SOAPDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/j2mews/xml/rpc/SOAPDecoder */
    /*  @4 */	struct Java_javax_xml_parsers_SAXParser * JVM_FIELD_CONST parser;
    /*  @8 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST token;
    /* @12 */	jint state;
    /* @16 */	jint bodyNEnvelope;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST eName;
    /* @24 */	struct Java_javax_microedition_xml_rpc_ComplexType * JVM_FIELD_CONST faultCT;
    /* @28 */	struct Java_javax_microedition_xml_rpc_FaultDetailHandler * JVM_FIELD_CONST handler;
    /* @32 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST detailName;
    /* @36 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST handlerDetail;
    /* @40 */	struct Java_java_util_Stack * JVM_FIELD_CONST valueStack;
    /* @44 */	struct Java_java_util_Stack * JVM_FIELD_CONST typeStack;
    /* @48 */	struct Java_java_util_Stack * JVM_FIELD_CONST stateStack;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST errString;
    /* @56 */	jboolean processingHeader;
    /* @57 */	jboolean isNill;
    /* @58 */	jboolean faultMode;
    /* @59 */	jbyte ___pad99;
};

struct Java_com_sun_j2mews_xml_rpc_SOAPEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2mews/xml/rpc/SOAPEncoder */
    /*  @4 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST buffer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultNS;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST errString;
};

struct Java_javax_microedition_xml_rpc_FaultDetailHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/FaultDetailHandler */
};

struct Java_javax_microedition_xml_rpc_Element {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
    /* javax/microedition/xml/rpc/Element */
    /*  @8 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST name;
    /* @12 */	struct Java_javax_microedition_xml_rpc_Type * JVM_FIELD_CONST contentType;
    /* @16 */	jint minOccurs;
    /* @20 */	jint maxOccurs;
    /* @24 */	jboolean isNillable;
    /* @25 */	jboolean isArray;
    /* @26 */	jboolean isOptional;
    /* @27 */	jbyte ___pad100;
};

struct Java_javax_xml_namespace_QName {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/namespace/QName */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST localPart;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST prefix;
};

struct Java_javax_microedition_io_HttpConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpConnection */
};

struct Java_javax_microedition_xml_rpc_Type {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
};

struct Java_javax_microedition_xml_rpc_Operation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Operation */
};

struct Java_com_sun_j2mews_xml_rpc_OperationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Operation */
    /* com/sun/j2mews/xml/rpc/OperationImpl */
    /*  @4 */	jobject_array * JVM_FIELD_CONST properties;
    /*  @8 */	jint propertyIndex;
    /* @12 */	struct Java_com_sun_j2mews_xml_rpc_SOAPEncoder * JVM_FIELD_CONST encoder;
    /* @16 */	struct Java_com_sun_j2mews_xml_rpc_SOAPDecoder * JVM_FIELD_CONST decoder;
    /* @20 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST name;
    /* @24 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST inputType;
    /* @28 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST returnType;
    /* @32 */	struct Java_javax_microedition_xml_rpc_FaultDetailHandler * JVM_FIELD_CONST faultHandler;
    /* @36 */	jboolean resourceMoved;
    /* @37 */	jbyte ___pad101;
    /* @38 */	jbyte ___pad102;
    /* @39 */	jbyte ___pad103;
};

struct Java_javax_xml_rpc_JAXRPCException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/xml/rpc/JAXRPCException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST cause;
};

struct Java_java_rmi_RemoteException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
};

struct Java_java_rmi_MarshalException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
    /* java/rmi/MarshalException */
};

struct Java_java_rmi_ServerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
    /* java/rmi/ServerException */
};

struct Java_javax_microedition_xml_rpc_FaultDetailException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/xml/rpc/FaultDetailException */
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST faultDetail;
    /* @16 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST faultDetailName;
};

struct Java_java_lang_Boolean {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Boolean */
    /*  @4 */	jboolean value;
    /* @5 */	jbyte ___pad104;
    /* @6 */	jbyte ___pad105;
    /* @7 */	jbyte ___pad106;
};

struct Java_java_lang_Byte {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Byte */
    /*  @4 */	jbyte value;
    /* @5 */	jbyte ___pad107;
    /* @6 */	jbyte ___pad108;
    /* @7 */	jbyte ___pad109;
};

struct Java_java_lang_Double {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Double */
    /*  @4 */	jdouble value;
};

struct Java_java_lang_Float {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Float */
    /*  @4 */	jfloat value;
};

struct Java_java_lang_Integer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Integer */
    /*  @4 */	jint value;
};

struct Java_java_lang_Long {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Long */
    /*  @4 */	jlong value;
};

struct Java_java_lang_Short {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Short */
    /*  @4 */	jshort value;
    /* @5 */	jbyte ___pad110;
    /* @6 */	jbyte ___pad111;
};

struct Java_javax_microedition_xml_rpc_ComplexType {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
    /* javax/microedition/xml/rpc/ComplexType */
    /*  @8 */	jobject_array * JVM_FIELD_CONST elements;
};

struct Java_javax_xml_parsers_SAXParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParser */
};

struct Java_java_util_Stack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
    /* java/util/Stack */
};

struct Java_org_xml_sax_helpers_DefaultHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
};

struct Java_javax_xml_parsers_SAXParserFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParserFactory */
    /*  @4 */	jboolean namespaceAware;
    /*  @5 */	jboolean validating;
    /* @6 */	jbyte ___pad112;
    /* @7 */	jbyte ___pad113;
};

struct Java_org_xml_sax_InputSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/InputSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST publicId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST systemId;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST byteStream;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST encoding;
    /* @20 */	struct Java_java_io_Reader * JVM_FIELD_CONST characterStream;
};

struct Java_org_xml_sax_Locator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/Locator */
};

struct Java_org_xml_sax_Attributes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/Attributes */
};

struct Java_org_xml_sax_SAXParseException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXParseException */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST publicId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST systemId;
    /* @20 */	jint lineNumber;
    /* @24 */	jint columnNumber;
};

struct Java_javax_xml_parsers_ParserConfigurationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/xml/parsers/ParserConfigurationException */
};

struct Java_org_xml_sax_SAXException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
};

struct Java_java_lang_NumberFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/NumberFormatException */
};

struct Java_com_sun_j2mews_xml_rpc_TypedVector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
    /* com/sun/j2mews/xml/rpc/TypedVector */
    /* @16 */	jint type;
    /* @20 */	jint minOccurs;
    /* @24 */	jint maxOccurs;
    /* @28 */	jboolean nillable;
    /* @29 */	jboolean isArrayWrapper;
    /* @30 */	jbyte ___pad114;
    /* @31 */	jbyte ___pad115;
};

struct Java_com_sun_kvem_midp_pim_PIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMField */
};

struct Java_com_sun_kvem_midp_pim_PIMHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMHandler */
    /*  @4 */	jint YEAR;
    /*  @8 */	jint MONTH;
    /* @12 */	jint DAY_OF_MONTH;
    /* @16 */	jint HOUR_OF_DAY;
    /* @20 */	jint MINUTE;
    /* @24 */	jint SECOND;
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad116;
    /* @26 */	jbyte ___pad117;
    /* @27 */	jbyte ___pad118;
};

struct Java_com_sun_kvem_midp_pim_PIMFormat {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMFormat */
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	jint listType;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad119;
    /* @38 */	jbyte ___pad120;
    /* @39 */	jbyte ___pad121;
};

struct Java_javax_microedition_pim_PIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIMItem */
};

struct Java_javax_microedition_pim_PIMList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIMList */
};

struct Java_javax_microedition_pim_PIMException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/pim/PIMException */
    /* @12 */	jint exception_reason;
};

struct Java_javax_microedition_pim_FieldFullException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/FieldFullException */
    /* @12 */	jint offending_field;
};

struct Java_com_sun_kvem_midp_pim_EmptyPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/EmptyPIMField */
};

struct Java_com_sun_kvem_midp_pim_ScalarPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/ScalarPIMField */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /*  @8 */	jint attributes;
};

struct Java_com_sun_kvem_midp_pim_VectorPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/VectorPIMField */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST values;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST attributes;
};

struct Java_javax_microedition_pim_UnsupportedFieldException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/UnsupportedFieldException */
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMList_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList$1 */
    /*  @4 */	jint index;
    /*  @8 */	jobject_array * JVM_FIELD_CONST val_044data;
    /* @12 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST this_0440;
};

struct Java_java_util_NoSuchElementException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/NoSuchElementException */
};

struct Java_com_sun_kvem_midp_pim_PIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMItem */
};

struct Java_com_sun_kvem_midp_pim_Contact {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/Contact */
};

struct Java_javax_microedition_pim_Contact {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/Contact */
};

struct Java_com_sun_kvem_midp_pim_ContactImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	jint listType;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad122;
    /* @38 */	jbyte ___pad123;
    /* @39 */	jbyte ___pad124;
    /* com/sun/kvem/midp/pim/ContactImpl */
};

struct Java_com_sun_kvem_midp_pim_LineReader_00024Matcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/LineReader$Matcher */
};

struct Java_com_sun_kvem_midp_pim_formats_FormatSupport_00024DataElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/FormatSupport$DataElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST propertyName;
    /*  @8 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST data;
};

struct Java_com_sun_kvem_midp_pim_LineReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* java/io/InputStreamReader */
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST __dup1__in;
    /* com/sun/kvem/midp/pim/LineReader */
    /* @16 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* @20 */	struct Java_com_sun_kvem_midp_pim_LineReader_00024Matcher * JVM_FIELD_CONST matcher;
};

struct Java_com_sun_kvem_midp_pim_formats_EndMatcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
};

struct Java_com_sun_kvem_midp_pim_formats_VCardFormat {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
};

struct Java_com_sun_kvem_midp_pim_formats_VCard30Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
    /* com/sun/kvem/midp/pim/formats/VCard30Format */
};

struct Java_javax_microedition_pim_ContactList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ContactList */
};

struct Java_com_sun_kvem_midp_pim_ContactListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad125;
    /* @26 */	jbyte ___pad126;
    /* @27 */	jbyte ___pad127;
    /* com/sun/kvem/midp/pim/ContactListImpl */
};

struct Java_com_sun_kvem_midp_pim_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/Event */
};

struct Java_javax_microedition_pim_RepeatRule {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/RepeatRule */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST fields;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST exceptions;
};

struct Java_javax_microedition_pim_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/Event */
};

struct Java_com_sun_kvem_midp_pim_EventImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	jint listType;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad128;
    /* @38 */	jbyte ___pad129;
    /* @39 */	jbyte ___pad130;
    /* com/sun/kvem/midp/pim/EventImpl */
    /* @40 */	struct Java_javax_microedition_pim_RepeatRule * JVM_FIELD_CONST repeatRule;
};

struct Java_com_sun_kvem_midp_pim_formats_Parser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/Parser */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /*  @8 */	jint index;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST endDate;
};

struct Java_com_sun_kvem_midp_pim_ToDoImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	jint listType;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad131;
    /* @38 */	jbyte ___pad132;
    /* @39 */	jbyte ___pad133;
    /* com/sun/kvem/midp/pim/ToDoImpl */
};

struct Java_javax_microedition_pim_ToDo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ToDo */
};

struct Java_com_sun_kvem_midp_pim_formats_VCalendar10Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCalendar10Format */
};

struct Java_javax_microedition_pim_FieldEmptyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/FieldEmptyException */
    /* @12 */	jint offending_field;
};

struct Java_javax_microedition_pim_EventList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/EventList */
};

struct Java_com_sun_kvem_midp_pim_EventListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad134;
    /* @26 */	jbyte ___pad135;
    /* @27 */	jbyte ___pad136;
    /* com/sun/kvem/midp/pim/EventListImpl */
};

struct Java_com_sun_kvem_midp_pim_KeySortUtility {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/KeySortUtility */
};

struct Java_com_sun_kvem_midp_pim_MarkableInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/midp/pim/MarkableInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_io_ByteArrayOutputStream * JVM_FIELD_CONST baos;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @16 */	jint bufferIndex;
};

struct Java_java_io_InputStreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* java/io/InputStreamReader */
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST in;
};

struct Java_com_sun_kvem_midp_pim_PIMBridge {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMHandler */
    /*  @4 */	jint YEAR;
    /*  @8 */	jint MONTH;
    /* @12 */	jint DAY_OF_MONTH;
    /* @16 */	jint HOUR_OF_DAY;
    /* @20 */	jint MINUTE;
    /* @24 */	jint SECOND;
    /* com/sun/kvem/midp/pim/PIMBridge */
};

struct Java_com_sun_kvem_midp_pim_PIMBridge_00024List {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMBridge$List */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @12 */	struct Java_com_sun_kvem_midp_pim_PIMBridge * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_midp_pim_PIMFieldDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMFieldDescriptor */
    /*  @4 */	jint field;
    /*  @8 */	jint dataType;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST defaultValue;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @20 */	jobject_array * JVM_FIELD_CONST labelResources;
    /* @24 */	jlong attributes;
    /* @32 */	jint maxValues;
    /* @36 */	jboolean hasDefaultValue;
    /* @37 */	jbyte ___pad137;
    /* @38 */	jbyte ___pad138;
    /* @39 */	jbyte ___pad139;
};

struct Java_com_sun_kvem_midp_pim_PIMDatabase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMDatabase */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST dir;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST categoriesMap;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST fileSep;
    /* @16 */	jobject_array * JVM_FIELD_CONST LISTS;
};

struct Java_com_sun_kvem_midp_pim_PIMDatabase_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMDatabase$1 */
};

struct Java_com_sun_kvem_midp_pim_PIMDatabase_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMDatabase$SecurityTrusted */
};

struct Java_java_io_DataInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/DataInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_javax_microedition_pim_PIM {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIM */
};

struct Java_com_sun_kvem_midp_pim_PIMImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIM */
    /* com/sun/kvem/midp/pim/PIMImpl */
};

struct Java_com_sun_kvem_midp_pim_UnsupportedPIMFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/kvem/midp/pim/UnsupportedPIMFormatException */
};

struct Java_javax_microedition_pim_ToDoList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ToDoList */
};

struct Java_com_sun_kvem_midp_pim_ToDoListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad140;
    /* @26 */	jbyte ___pad141;
    /* @27 */	jbyte ___pad142;
    /* com/sun/kvem/midp/pim/ToDoListImpl */
};

struct Java_com_sun_kvem_midp_pim_SupportedPIMFields {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/SupportedPIMFields */
};

struct Java_com_sun_kvem_midp_pim_ToDo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/ToDo */
};

struct Java_com_sun_kvem_midp_pim_formats_Base64Encoding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/Base64Encoding */
};

struct Java_com_sun_kvem_midp_pim_formats_Extensions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/Extensions */
};

struct Java_com_sun_kvem_midp_pim_formats_FormatSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/FormatSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_QuotedPrintableEncoding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/QuotedPrintableEncoding */
};

struct Java_java_io_OutputStreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* java/io/OutputStreamWriter */
    /* @16 */	struct Java_java_io_Writer * JVM_FIELD_CONST out;
};

struct Java_com_sun_kvem_midp_pim_formats_VCard21Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
    /* com/sun/kvem/midp/pim/formats/VCard21Format */
};

struct Java_com_sun_kvem_midp_pim_formats_VCardSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VCardSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_VEventSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VEventSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_VToDoSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VToDoSupport */
};

struct Java_com_sun_midp_appmanager_AMSCustomItem_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/AMSCustomItem$1 */
};

struct Java_com_sun_midp_appmanager_AMSCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad143;
};

struct Java_java_util_TimerTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
};

struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/appmanager/AMSCustomItem$TextScrollPainter */
    /* @28 */	struct Java_com_sun_midp_appmanager_AMSCustomItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_appmanager_AppManagerUI {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad144;
    /* @31 */	jbyte ___pad145;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppManagerUI */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCaManagerCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeOkCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST runYesCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST runNoCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST unmarkAllCmd;
    /* @80 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @84 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @88 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @92 */	jlong lastDisplayChange;
    /* @100 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST removeMsi;
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST lastSelectedMsi;
    /* @108 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST appManagerMidlet;
    /* @112 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @116 */	struct Java_com_sun_midp_appmanager_MIDletSwitcher * JVM_FIELD_CONST midletSwitcher;
    /* @120 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST rootFolder;
    /* @124 */	struct Java_com_sun_midp_appmanager_AMSSystemFolderCustomItem * JVM_FIELD_CONST systemFolder;
    /* @128 */	struct Java_java_util_Vector * JVM_FIELD_CONST markedItems;
    /* @132 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST folderToDelete;
    /* @136 */	jint failedMidletDeletes;
    /* @140 */	jboolean caManagerIncluded;
    /* @141 */	jboolean first;
    /* @142 */	jboolean removingMultipleMidlets;
    /* @143 */	jbyte ___pad146;
};

struct Java_java_util_Timer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Timer */
    /*  @4 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /*  @8 */	struct Java_java_util_TimerThread * JVM_FIELD_CONST thread;
};

struct Java_com_sun_midp_appmanager_Sortable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/Sortable */
};

struct Java_javax_microedition_lcdui_CustomItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CustomItemLF */
};

struct Java_javax_microedition_lcdui_CustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
};

struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteInfo */
    /*  @4 */	jint suiteId;
    /*  @8 */	jint storageId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST iconName;
    /* @28 */	jboolean enabled;
    /* @29 */	jboolean trusted;
    /* @30 */	jboolean preinstalled;
    /* @31 */	jbyte ___pad147;
    /* com/sun/midp/appmanager/RunningMIDletSuiteInfo */
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @36 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
};

struct Java_com_sun_midp_main_MIDletProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxy */
    /*  @4 */	jint externalId;
    /*  @8 */	jint isolateId;
    /* @12 */	jint displayId;
    /* @16 */	jint suiteId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @28 */	jint midletState;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempting;
    /* @36 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempted;
    /* @40 */	struct Java_java_util_Timer * JVM_FIELD_CONST proxyTimer;
    /* @44 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST parent;
    /* @48 */	jboolean wasNotActive;
    /* @49 */	jboolean wantsForegroundState;
    /* @50 */	jboolean requestedForeground;
    /* @51 */	jboolean alertWaiting;
};

struct Java_com_sun_midp_appmanager_DisplayError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/DisplayError */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
};

struct Java_com_sun_midp_appmanager_AMSFolderCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad148;
    /* com/sun/midp/appmanager/AMSFolderCustomItem */
    /* @104 */	jobject_array * JVM_FIELD_CONST subfolders;
    /* @108 */	jobject_array * JVM_FIELD_CONST items;
    /* @112 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @116 */	jboolean open;
    /* @117 */	jbyte ___pad149;
    /* @118 */	jbyte ___pad150;
    /* @119 */	jbyte ___pad151;
};

struct Java_com_sun_midp_appmanager_ApplicationManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/ApplicationManager */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteStorage */
};

struct Java_com_sun_midp_appmanager_MIDletSwitcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad152;
    /* @31 */	jbyte ___pad153;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/List */
    /* @32 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectCommand;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST listLF;
    /* com/sun/midp/appmanager/MIDletSwitcher */
    /* @44 */	jint mcount;
    /* @48 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @52 */	jint pitch;
    /* @56 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @60 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST managerUI;
    /* @64 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST fgCmd;
};

struct Java_com_sun_midp_appmanager_AMSSystemFolderCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad154;
    /* com/sun/midp/appmanager/AMSFolderCustomItem */
    /* @104 */	jobject_array * JVM_FIELD_CONST subfolders;
    /* @108 */	jobject_array * JVM_FIELD_CONST items;
    /* @112 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @116 */	jboolean open;
    /* @117 */	jbyte ___pad155;
    /* @118 */	jbyte ___pad156;
    /* @119 */	jbyte ___pad157;
    /* com/sun/midp/appmanager/AMSSystemFolderCustomItem */
    /* @120 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST discoveryMidlet;
    /* @124 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST wifiMidlet;
    /* @128 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST vmConfigMidlet;
    /* @132 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST appGalleryMidlet;
};

struct Java_javax_microedition_lcdui_AlertType {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertType */
    /*  @4 */	jint type;
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad158;
    /* com/sun/midp/appmanager/AMSMidletCustomItem */
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @108 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @112 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteImpl */
    /*  @4 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /*  @8 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @12 */	struct Java_com_sun_midp_midletsuite_SuiteProperties * JVM_FIELD_CONST suiteProperties;
    /* @16 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST suiteSettings;
    /* @20 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @24 */	jint id;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_name;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_class;
    /* @36 */	jint numberOfMidlets;
    /* @40 */	jboolean locked;
    /* @41 */	jbyte ___pad159;
    /* @42 */	jbyte ___pad160;
    /* @43 */	jbyte ___pad161;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteInfo */
    /*  @4 */	jint suiteId;
    /*  @8 */	jint storageId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST iconName;
    /* @28 */	jboolean enabled;
    /* @29 */	jboolean trusted;
    /* @30 */	jboolean preinstalled;
    /* @31 */	jbyte ___pad162;
};

struct Java_javax_microedition_lcdui_Alert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad163;
    /* @31 */	jbyte ___pad164;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
};

struct Java_javax_microedition_rms_RecordStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordStore */
    /*  @4 */	struct Java_com_sun_midp_rms_RecordStoreImpl * JVM_FIELD_CONST peer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST recordStoreName;
    /* @12 */	jint suiteId;
    /* @16 */	jint opencount;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST recordListener;
};

struct Java_javax_microedition_lcdui_TextBox {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad165;
    /* @31 */	jbyte ___pad166;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/TextBox */
    /* @32 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST textField;
    /* @36 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST textBoxLF;
};

struct Java_com_sun_midp_appmanager_AMSCustomItemRenameForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad167;
    /* @31 */	jbyte ___pad168;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/TextBox */
    /* @32 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST textField;
    /* @36 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST textBoxLF;
    /* com/sun/midp/appmanager/AMSCustomItemRenameForm */
    /* @40 */	struct Java_com_sun_midp_appmanager_AMSCustomItem * JVM_FIELD_CONST target;
    /* @44 */	jboolean createFolder;
    /* @45 */	jbyte ___pad169;
    /* @46 */	jbyte ___pad170;
    /* @47 */	jbyte ___pad171;
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_00024iconLoadingThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/AMSMidletCustomItem$iconLoadingThread */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST icons;
    /*  @8 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteInfo */
    /*  @4 */	jint suiteId;
    /*  @8 */	jint storageId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST iconName;
    /* @28 */	jboolean enabled;
    /* @29 */	jboolean trusted;
    /* @30 */	jboolean preinstalled;
    /* @31 */	jbyte ___pad172;
    /* com/sun/midp/appmanager/RunningMIDletSuiteInfo */
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @36 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem$1 */
    /* @40 */	struct Java_com_sun_midp_appmanager_AMSMidletCustomItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_1AppGallery {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad173;
    /* com/sun/midp/appmanager/AMSMidletCustomItem */
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @108 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @112 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem_AppGallery */
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_1Installer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteInfo */
    /*  @4 */	jint suiteId;
    /*  @8 */	jint storageId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST iconName;
    /* @28 */	jboolean enabled;
    /* @29 */	jboolean trusted;
    /* @30 */	jboolean preinstalled;
    /* @31 */	jbyte ___pad174;
    /* com/sun/midp/appmanager/RunningMIDletSuiteInfo */
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @36 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem_Installer$1 */
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_1Installer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad175;
    /* com/sun/midp/appmanager/AMSMidletCustomItem */
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @108 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @112 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem_Installer */
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_1VMConfigPanel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad176;
    /* com/sun/midp/appmanager/AMSMidletCustomItem */
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @108 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @112 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem_VMConfigPanel */
};

struct Java_com_sun_midp_appmanager_AMSMidletCustomItem_1WifiManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AMSCustomItem */
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	jchar_array * JVM_FIELD_CONST text;
    /* @68 */	jint textLen;
    /* @72 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST default_command;
    /* @80 */	jint depth;
    /* @84 */	jint indent;
    /* @88 */	struct Java_com_sun_midp_appmanager_AMSCustomItem_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @92 */	jint scrollWidth;
    /* @96 */	jint xScrollOffset;
    /* @100 */	jboolean marked;
    /* @101 */	jboolean truncated;
    /* @102 */	jboolean hasFocus;
    /* @103 */	jbyte ___pad177;
    /* com/sun/midp/appmanager/AMSMidletCustomItem */
    /* @104 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @108 */	struct Java_com_sun_midp_appmanager_AMSFolderCustomItem * JVM_FIELD_CONST parent;
    /* @112 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* com/sun/midp/appmanager/AMSMidletCustomItem_WifiManager */
};

struct Java_com_sun_midp_midletsuite_InstallInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/InstallInfo */
    /*  @4 */	jint id;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST jadUrl;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST jarUrl;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST jarFilename;
    /* @20 */	jint expectedJarSize;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteName;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteVendor;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteVersion;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST description;
    /* @40 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @48 */	jbyte_array * JVM_FIELD_CONST verifyHash;
    /* @52 */	jboolean trusted;
    /* @53 */	jbyte ___pad178;
    /* @54 */	jbyte ___pad179;
    /* @55 */	jbyte ___pad180;
};

struct Java_com_sun_midp_appmanager_AppInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad181;
    /* @31 */	jbyte ___pad182;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppInfo */
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST suiteIcon;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST singleSuiteIcon;
    /* @56 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @60 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @64 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @68 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @72 */	jint numberOfMidlets;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
};

struct Java_javax_microedition_lcdui_ImageItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageItemLF */
};

struct Java_javax_microedition_lcdui_ImageItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/ImageItem */
    /* @52 */	struct Java_javax_microedition_lcdui_ImageItemLF * JVM_FIELD_CONST imageItemLF;
    /* @56 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST immutableImg;
    /* @60 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImg;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST altText;
    /* @68 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_StringItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/StringItemLF */
};

struct Java_javax_microedition_lcdui_StringItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/StringItem */
    /* @52 */	struct Java_javax_microedition_lcdui_StringItemLF * JVM_FIELD_CONST stringItemLF;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST str;
    /* @60 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @64 */	jint appearanceMode;
};

struct Java_com_sun_midp_appmanager_AppManagerUI_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/AppManagerUI$1 */
    /*  @4 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_appmanager_RadioButtonSet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @56 */	jint choiceType;
    /* @60 */	jint fitPolicy;
    /* @64 */	jint numOfEls;
    /* @68 */	jobject_array * JVM_FIELD_CONST cgElements;
    /* com/sun/midp/appmanager/RadioButtonSet */
    /* @72 */	jint_array * JVM_FIELD_CONST ids;
};

struct Java_com_sun_midp_security_PermissionGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionGroup */
    /*  @4 */	jint name;
    /*  @8 */	jint settingsQuestion;
    /* @12 */	jint disableSettingChoice;
    /* @16 */	jint runtimeDialogTitle;
    /* @20 */	jint runtimeQuestion;
    /* @24 */	jint runtimeOneshotQuestion;
    /* @28 */	jbyte identifiedMaxiumLevel;
    /* @29 */	jbyte identifiedDefaultLevel;
    /* @30 */	jbyte unidentifiedMaxiumLevel;
    /* @31 */	jbyte unidentifiedDefaultLevel;
};

struct Java_com_sun_midp_appmanager_AppSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad183;
    /* @31 */	jbyte ___pad184;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppSettings */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveAppSettingsCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @56 */	jint displayedSettingID;
    /* @60 */	jint lastPopupChoice;
    /* @64 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST initialSetting;
    /* @68 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST settingsPopup;
    /* @72 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST interruptChoice;
    /* @76 */	jobject_array * JVM_FIELD_CONST groupSettings;
    /* @80 */	jint numberOfSettings;
    /* @84 */	jbyte_array * JVM_FIELD_CONST maxLevels;
    /* @88 */	jbyte_array * JVM_FIELD_CONST curLevels;
    /* @92 */	jint pushOptions;
    /* @96 */	jobject_array * JVM_FIELD_CONST groups;
    /* @100 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @104 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @108 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @112 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteDisplayName;
    /* @120 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST midletSuite;
    /* @124 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @128 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @132 */	jbyte pushInterruptSetting;
    /* @133 */	jbyte ___pad185;
    /* @134 */	jbyte ___pad186;
    /* @135 */	jbyte ___pad187;
};

struct Java_com_sun_midp_appmanager_DeviceSetting {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad188;
    /* @31 */	jbyte ___pad189;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/DeviceSetting */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @56 */	jint suiteId;
    /* @60 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @64 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @68 */	jint selectedDevice;
    /* @72 */	jint selectedCPUSpeed;
};

struct Java_javax_microedition_lcdui_AlertLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertLF */
};

struct Java_javax_microedition_lcdui_Gauge {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/Gauge */
    /* @52 */	struct Java_javax_microedition_lcdui_GaugeLF * JVM_FIELD_CONST gaugeLF;
    /* @56 */	jint value;
    /* @60 */	jint maxValue;
    /* @64 */	jboolean interactive;
    /* @65 */	jbyte ___pad190;
    /* @66 */	jbyte ___pad191;
    /* @67 */	jbyte ___pad192;
};

struct Java_com_sun_midp_appmanager_Ca {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/Ca */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	jboolean enabled;
    /*  @9 */	jboolean willBeEnabled;
    /* @10 */	jbyte ___pad193;
    /* @11 */	jbyte ___pad194;
};

struct Java_com_sun_midp_appmanager_CaManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/CaManager */
};

struct Java_com_sun_midp_publickeystore_PublicKeyInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST owner;
    /*  @8 */	jlong notBefore;
    /* @16 */	jlong notAfter;
    /* @24 */	jbyte_array * JVM_FIELD_CONST modulus;
    /* @28 */	jbyte_array * JVM_FIELD_CONST exponent;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @36 */	jboolean enabled;
    /* @37 */	jbyte ___pad195;
    /* @38 */	jbyte ___pad196;
    /* @39 */	jbyte ___pad197;
};

struct Java_com_sun_midp_publickeystore_WebPublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
    /* com/sun/midp/publickeystore/WebPublicKeyStore */
};

struct Java_com_sun_midp_appmanager_CaForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad198;
    /* @31 */	jbyte ___pad199;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/CaForm */
    /* @48 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST suiteStorage;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST disableSuites;
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST enableSuites;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST confirmCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST caList;
    /* @80 */	struct Java_com_sun_midp_appmanager_CaManager * JVM_FIELD_CONST parent;
    /* @84 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @88 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST choices;
    /* @92 */	jint firstIndex;
};

struct Java_com_sun_midp_security_SecurityHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityHandler */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST sessionValues;
    /* @12 */	jbyte_array * JVM_FIELD_CONST maxPermissionLevels;
    /* @16 */	jboolean trusted;
    /* @17 */	jbyte ___pad200;
    /* @18 */	jbyte ___pad201;
    /* @19 */	jbyte ___pad202;
};

struct Java_com_sun_midp_midletsuite_SuiteProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteProperties */
    /*  @4 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /*  @8 */	jint suiteId;
};

struct Java_com_sun_midp_midletsuite_SuiteSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteSettings */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jint pushOptions;
    /* @12 */	jint suiteId;
    /* @16 */	jbyte pushInterruptSetting;
    /* @17 */	jboolean enabled;
    /* @18 */	jboolean loaded;
    /* @19 */	jbyte ___pad203;
};

struct Java_com_sun_midp_midlet_MIDletStateHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletStateHandler */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletLoader * JVM_FIELD_CONST midletLoader;
    /* @12 */	jobject_array * JVM_FIELD_CONST midlets;
    /* @16 */	jint nmidlets;
    /* @20 */	jint scanIndex;
    /* @24 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST underConstructionPeer;
};

struct Java_com_sun_midp_appmanager_DeviceSetting_00024KeySettingItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @56 */	jint choiceType;
    /* @60 */	jint fitPolicy;
    /* @64 */	jint numOfEls;
    /* @68 */	jobject_array * JVM_FIELD_CONST cgElements;
    /* com/sun/midp/appmanager/DeviceSetting$KeySettingItem */
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @76 */	jint value;
    /* @80 */	struct Java_com_sun_midp_appmanager_DeviceSetting * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_midletsuite_MIDletInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST icon;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST classname;
};

struct Java_com_sun_midp_appmanager_MIDletSelector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSelector */
    /*  @4 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST mlist;
    /*  @8 */	struct Java_com_sun_midp_appmanager_RunningMIDletSuiteInfo * JVM_FIELD_CONST suiteInfo;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST parentDisplayable;
    /* @20 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @24 */	jint mcount;
    /* @28 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @40 */	jint selectedMidlet;
};

struct Java_com_sun_midp_appmanager_MIDletSuiteLauncher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/MIDletSuiteLauncher */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @16 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
};

struct Java_com_sun_midp_main_MIDletProxyList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyList */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST midletProxies;
    /* @12 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundMidlet;
    /* @16 */	struct Java_com_sun_midp_main_DisplayController * JVM_FIELD_CONST displayController;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST amsProxy;
    /* @24 */	jboolean allPaused;
    /* @25 */	jbyte ___pad204;
    /* @26 */	jbyte ___pad205;
    /* @27 */	jbyte ___pad206;
};

struct Java_com_sun_midp_main_MIDletProxyListListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyListListener */
};

struct Java_com_sun_midp_main_DisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
};

struct Java_com_sun_midp_main_DisplayControllerListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayControllerListener */
};

struct Java_com_sun_midp_appmanager_MVMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/MVMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
};

struct Java_com_sun_midp_main_MVMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* com/sun/midp/main/MVMDisplayController */
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundSelector;
};

struct Java_com_sun_midp_appmanager_QuicksortAlg {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/QuicksortAlg */
};

struct Java_com_sun_midp_appmanager_SMMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/SMMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	jint suiteId;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @44 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @48 */	jboolean allowMidletLaunch;
    /* @49 */	jbyte ___pad207;
    /* @50 */	jbyte ___pad208;
    /* @51 */	jbyte ___pad209;
};

struct Java_com_sun_midp_main_SMMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* com/sun/midp/main/SMMDisplayController */
    /* @16 */	jint lastMidletSuiteId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @24 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletInForeground;
};

struct Java_com_sun_midp_appmanager_SelectorBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/SelectorBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST mlist;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	jint mcount;
    /* @20 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @32 */	jint selectedMidlet;
};

struct Java_com_sun_midp_appmanager_Selector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/SelectorBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST mlist;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	jint mcount;
    /* @20 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @32 */	jint selectedMidlet;
    /* com/sun/midp/appmanager/Selector */
};

struct Java_com_sun_midp_appmanager_SplashScreen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad210;
    /* @31 */	jbyte ___pad211;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad212;
    /* @38 */	jbyte ___pad213;
    /* @39 */	jbyte ___pad214;
    /* com/sun/midp/appmanager/SplashScreen */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST splashScreen;
    /* @44 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @48 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @52 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @56 */	struct Java_java_util_Timer * JVM_FIELD_CONST timeoutTimer;
};

struct Java_com_sun_midp_appmanager_SplashScreen_00024TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/appmanager/SplashScreen$TimeoutTask */
    /* @28 */	struct Java_com_sun_midp_appmanager_SplashScreen * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_appmanager_WifiSelector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/WifiSelector */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST wifiprof;
    /* @16 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @20 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectWIFICmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST getWIFIStatusCmd;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST disconnectCmd;
    /* @36 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alertConnectOK;
    /* @40 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alertConnectFail;
    /* @44 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alertConnecting;
    /* @48 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alertNetworkStatus;
    /* @52 */	jboolean connect_stop;
    /* @53 */	jbyte ___pad215;
    /* @54 */	jbyte ___pad216;
    /* @55 */	jbyte ___pad217;
};

struct Java_com_sun_midp_appmanager_WifiSelector_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/appmanager/WifiSelector$1 */
    /* @28 */	struct Java_com_sun_midp_appmanager_WifiSelector * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_events_EventQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventQueue */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventQueueThread;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST nextEvent;
    /* @12 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST lastEvent;
    /* @16 */	jobject_array * JVM_FIELD_CONST dispatchTable;
    /* @20 */	jint numEvents;
    /* @24 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventMonitorThread;
    /* @28 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
    /* @32 */	jint nativeEventQueueHandle;
    /* @36 */	jboolean alive;
    /* @37 */	jbyte ___pad218;
    /* @38 */	jbyte ___pad219;
    /* @39 */	jbyte ___pad220;
};

struct Java_com_sun_midp_main_MIDletControllerEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint currentIsolateId;
    /* @16 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST startErrorEvent;
    /* @20 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletCreatedEvent;
    /* @24 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletActiveEvent;
    /* @28 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletPausedEvent;
    /* @32 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletDestroyedEvent;
    /* @36 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletRsPausedEvent;
};

struct Java_com_sun_midp_automation_AutomationInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/automation/AutomationInitializer */
};

struct Java_java_lang_IllegalStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalStateException */
};

struct Java_com_sun_midp_chameleon_CGraphicsQ {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsQ */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST refreshQ;
};

struct Java_com_sun_midp_chameleon_CGraphicsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsUtil */
};

struct Java_com_sun_midp_chameleon_CWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_com_sun_midp_chameleon_CLayerList * JVM_FIELD_CONST layers;
    /* @12 */	jint dirtyCount;
    /* @16 */	jint dirtyMaxCount;
    /* @20 */	jobject_array * JVM_FIELD_CONST dirtyLayers;
    /* @24 */	struct Java_com_sun_midp_chameleon_layers_BackgroundLayer * JVM_FIELD_CONST bgLayer;
    /* @28 */	jint cX;
    /* @32 */	jint cY;
    /* @36 */	jint cW;
    /* @40 */	jint cH;
    /* @44 */	jint tranX;
    /* @48 */	jint tranY;
    /* @52 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @56 */	jint color;
    /* @60 */	jboolean dirty;
    /* @61 */	jbyte ___pad221;
    /* @62 */	jbyte ___pad222;
    /* @63 */	jbyte ___pad223;
};

struct Java_com_sun_midp_chameleon_CLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad224;
    /* @47 */	jbyte ___pad225;
};

struct Java_com_sun_midp_chameleon_CLayerElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayerElement */
    /*  @4 */	struct Java_com_sun_midp_chameleon_CLayer * JVM_FIELD_CONST layer;
    /*  @8 */	struct Java_com_sun_midp_chameleon_CLayerElement * JVM_FIELD_CONST upper;
    /* @12 */	struct Java_com_sun_midp_chameleon_CLayerElement * JVM_FIELD_CONST lower;
};

struct Java_com_sun_midp_chameleon_CLayerList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayerList */
    /*  @4 */	struct Java_com_sun_midp_chameleon_CLayerElement * JVM_FIELD_CONST top;
    /*  @8 */	struct Java_com_sun_midp_chameleon_CLayerElement * JVM_FIELD_CONST bottom;
    /* @12 */	jint count;
};

struct Java_com_sun_midp_chameleon_layers_BackgroundLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad226;
    /* @47 */	jbyte ___pad227;
    /* com/sun/midp/chameleon/layers/BackgroundLayer */
};

struct Java_com_sun_midp_chameleon_ChamDisplayTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/ChamDisplayTunnel */
};

struct Java_com_sun_midp_chameleon_layers_AlertLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad228;
    /* @47 */	jbyte ___pad229;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @48 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @52 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* com/sun/midp/chameleon/layers/AlertLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
};

struct Java_com_sun_midp_chameleon_layers_WashLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad230;
    /* @47 */	jbyte ___pad231;
    /* com/sun/midp/chameleon/layers/WashLayer */
};

struct Java_com_sun_midp_chameleon_layers_BodyLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad232;
    /* @47 */	jbyte ___pad233;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @48 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @52 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
};

struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad234;
    /* @47 */	jbyte ___pad235;
    /* com/sun/midp/chameleon/layers/SoftButtonLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST labels;
    /* @52 */	jobject_array * JVM_FIELD_CONST scrCmds;
    /* @56 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrListener;
    /* @60 */	jobject_array * JVM_FIELD_CONST itmCmds;
    /* @64 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemListener;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST soft1;
    /* @72 */	jobject_array * JVM_FIELD_CONST soft2;
    /* @76 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST subMenu;
    /* @80 */	struct Java_com_sun_midp_chameleon_CLayer * JVM_FIELD_CONST cachedScrollable;
    /* @84 */	struct Java_com_sun_midp_chameleon_ScrollListener * JVM_FIELD_CONST cachedListener;
    /* @88 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @92 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @96 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST swap;
    /* @100 */	jint typeX;
    /* @104 */	jint typeY;
    /* @108 */	jint buttonx;
    /* @112 */	jint buttony;
    /* @116 */	jint buttonw;
    /* @120 */	jint buttonh;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST tips;
    /* @128 */	jint tipsColor;
    /* @132 */	jboolean menuUP;
    /* @133 */	jboolean alertUP;
    /* @134 */	jboolean isInteractive;
    /* @135 */	jboolean soft_btn1_pressed;
    /* @136 */	jboolean soft_btn2_pressed;
    /* @137 */	jbyte ___pad236;
    /* @138 */	jbyte ___pad237;
    /* @139 */	jbyte ___pad238;
};

struct Java_com_sun_midp_chameleon_layers_PTILayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad239;
    /* @47 */	jbyte ___pad240;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/PTILayer */
    /* @56 */	jobject_array * JVM_FIELD_CONST list;
    /* @60 */	jint selId;
    /* @64 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST iSession;
    /* @68 */	jint widthMax;
    /* @72 */	jboolean checkReleased;
    /* @73 */	jbyte ___pad241;
    /* @74 */	jbyte ___pad242;
    /* @75 */	jbyte ___pad243;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad244;
    /* @47 */	jbyte ___pad245;
    /* com/sun/midp/chameleon/layers/TickerLayer */
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @52 */	jint textLoc;
    /* @56 */	jint textLen;
    /* @60 */	struct Java_java_util_Timer * JVM_FIELD_CONST tickerTimer;
    /* @64 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer_00024TickerPainter * JVM_FIELD_CONST tickerPainter;
};

struct Java_com_sun_midp_chameleon_layers_TitleLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad246;
    /* @47 */	jbyte ___pad247;
    /* com/sun/midp/chameleon/layers/TitleLayer */
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @52 */	jint titlex;
    /* @56 */	jint titley;
    /* @60 */	jint titlew;
    /* @64 */	jint titleh;
};

struct Java_com_sun_midp_chameleon_layers_PopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad248;
    /* @47 */	jbyte ___pad249;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad250;
    /* @47 */	jbyte ___pad251;
    /* com/sun/midp/chameleon/layers/ScrollIndLayer */
    /* @48 */	struct Java_com_sun_midp_chameleon_CLayer * JVM_FIELD_CONST scrollable;
    /* @52 */	struct Java_com_sun_midp_chameleon_ScrollListener * JVM_FIELD_CONST listener;
    /* @56 */	jboolean alertMode;
    /* @57 */	jbyte ___pad252;
    /* @58 */	jbyte ___pad253;
    /* @59 */	jbyte ___pad254;
};

struct Java_com_sun_midp_chameleon_MIDPWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_com_sun_midp_chameleon_CLayerList * JVM_FIELD_CONST layers;
    /* @12 */	jint dirtyCount;
    /* @16 */	jint dirtyMaxCount;
    /* @20 */	jobject_array * JVM_FIELD_CONST dirtyLayers;
    /* @24 */	struct Java_com_sun_midp_chameleon_layers_BackgroundLayer * JVM_FIELD_CONST bgLayer;
    /* @28 */	jint cX;
    /* @32 */	jint cY;
    /* @36 */	jint cW;
    /* @40 */	jint cH;
    /* @44 */	jint tranX;
    /* @48 */	jint tranY;
    /* @52 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @56 */	jint color;
    /* @60 */	jboolean dirty;
    /* @61 */	jbyte ___pad255;
    /* @62 */	jbyte ___pad256;
    /* @63 */	jbyte ___pad257;
    /* com/sun/midp/chameleon/MIDPWindow */
    /* @64 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_WashLayer * JVM_FIELD_CONST washLayer;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_WashLayer * JVM_FIELD_CONST alertWashLayer;
    /* @76 */	struct Java_com_sun_midp_chameleon_layers_AlertLayer * JVM_FIELD_CONST alertLayer;
    /* @80 */	struct Java_com_sun_midp_chameleon_layers_TitleLayer * JVM_FIELD_CONST titleLayer;
    /* @84 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST tickerLayer;
    /* @88 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST buttonLayer;
    /* @92 */	struct Java_com_sun_midp_chameleon_layers_PTILayer * JVM_FIELD_CONST ptiLayer;
    /* @96 */	struct Java_com_sun_midp_chameleon_layers_BodyLayer * JVM_FIELD_CONST bodyLayer;
    /* @100 */	jint screenMode;
    /* @104 */	jobject_array * JVM_FIELD_CONST scrCmdCache;
    /* @108 */	jint scrCmdCount;
    /* @112 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrCmdListener;
    /* @116 */	jobject_array * JVM_FIELD_CONST itemCmdCache;
    /* @120 */	jint itemCmdCount;
    /* @124 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemCmdListener;
    /* @128 */	jobject_array * JVM_FIELD_CONST mainLayers;
    /* @132 */	jboolean sizeChangedOccured;
    /* @133 */	jboolean bodyChecked;
    /* @134 */	jboolean bodyOverlapped;
    /* @135 */	jbyte ___pad258;
};

struct Java_com_sun_midp_chameleon_ScrollListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/ScrollListener */
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_00024TickerPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/chameleon/layers/TickerLayer$TickerPainter */
    /* @28 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/layers/TickerLayer$1 */
};

struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad259;
    /* @47 */	jbyte ___pad260;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/ScrollablePopupLayer */
    /* @56 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* com/sun/midp/chameleon/layers/CascadeMenuLayer */
    /* @60 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @64 */	jint selI;
    /* @68 */	jint scrollIndex;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @76 */	jint itemIndexWhenPressed;
};

struct Java_com_sun_midp_chameleon_layers_MenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad261;
    /* @47 */	jbyte ___pad262;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/ScrollablePopupLayer */
    /* @56 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* com/sun/midp/chameleon/layers/MenuLayer */
    /* @60 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @64 */	jint selI;
    /* @68 */	jint scrollIndex;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST btnLayer;
    /* @76 */	struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer * JVM_FIELD_CONST cascadeMenu;
    /* @80 */	jint itemIndexWhenPressed;
    /* @84 */	jboolean cascadeMenuUp;
    /* @85 */	jbyte ___pad263;
    /* @86 */	jbyte ___pad264;
    /* @87 */	jbyte ___pad265;
};

struct Java_com_sun_midp_chameleon_SubMenuCommand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
    /* com/sun/midp/chameleon/SubMenuCommand */
    /* @24 */	jobject_array * JVM_FIELD_CONST subCommands;
    /* @28 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_input_InputModeMediator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputModeMediator */
};

struct Java_com_sun_midp_chameleon_input_InputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputMode */
};

struct Java_com_sun_midp_chameleon_input_BasicInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad266;
};

struct Java_com_sun_midp_chameleon_input_AlphaNumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad267;
    /* com/sun/midp/chameleon/input/AlphaNumericInputMode */
    /* @32 */	jint capsModePointer;
};

struct Java_com_sun_midp_chameleon_input_TextInputComponent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputComponent */
};

struct Java_com_sun_midp_chameleon_input_TextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputSession */
};

struct Java_com_sun_midp_chameleon_input_BasicTextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicTextInputSession */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST currentMode;
    /*  @8 */	jobject_array * JVM_FIELD_CONST inputModeSet;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST previousScreen;
    /* @20 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST stickyMode;
    /* @24 */	struct Java_com_sun_midp_chameleon_input_TextInputComponent * JVM_FIELD_CONST textComponent;
};

struct Java_com_sun_midp_chameleon_input_InputModeFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputModeFactory */
};

struct Java_com_sun_midp_chameleon_input_KeyboardInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/KeyboardInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
};

struct Java_com_sun_midp_chameleon_input_NumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad268;
    /* com/sun/midp/chameleon/input/NumericInputMode */
    /* @32 */	jobject_array * JVM_FIELD_CONST numericKeyMap;
    /* @36 */	jobject_array * JVM_FIELD_CONST decimalKeyMap;
    /* @40 */	jobject_array * JVM_FIELD_CONST phoneNumericKeyMap;
    /* @44 */	jobject_array * JVM_FIELD_CONST anyKeyMap;
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_00024StringDiff {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode$StringDiff */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST state;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_input_PTIterator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIterator */
};

struct Java_com_sun_midp_chameleon_input_PTDictionary {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionary */
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST part;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_00024StringDiff * JVM_FIELD_CONST diff;
    /* @20 */	jint capsMode;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad269;
    /* @31 */	jbyte ___pad270;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad271;
    /* @38 */	jbyte ___pad272;
    /* @39 */	jbyte ___pad273;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable */
    /* @40 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @44 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @48 */	jint cellSize;
    /* @52 */	jint hmargin;
    /* @56 */	jint wmargin;
    /* @60 */	jint margin;
    /* @64 */	jint wx;
    /* @68 */	jint wy;
    /* @72 */	jint ww;
    /* @76 */	jint wh;
    /* @80 */	jint cols;
    /* @84 */	jint rows;
    /* @88 */	jint pos;
    /* @92 */	jint newpos;
    /* @96 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @100 */	jint x_cursor_coord;
    /* @104 */	jint y_cursor_coord;
    /* @108 */	jint defaultSymbolCursorPos;
    /* @112 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST accept;
    /* @116 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST reject;
    /* @120 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable * JVM_FIELD_CONST st;
};

struct Java_com_sun_midp_chameleon_input_NativeInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/NativeInputMode */
    /*  @4 */	jint STATE_CALLBACK_RES;
    /*  @8 */	jint STATE_FUNC_TOKEN;
    /* @12 */	jint STATE_NEXT_STATE;
    /* @16 */	jint STATE_INT_ARG;
    /* @20 */	jint STATE_FINAL_RES;
    /* @24 */	jint STATE_INTERNAL;
    /* @28 */	jint STATE_INTERNAL_EXT;
    /* @32 */	jint STATE_DATA_ARRAY_SIZE;
    /* @36 */	jint MEDIATOR_NOOP;
    /* @40 */	jint MEDIATOR_COMMIT;
    /* @44 */	jint MEDIATOR_CLEAR;
    /* @48 */	jint MEDIATOR_SUBINPUTMODECHANGED;
    /* @52 */	jint MEDIATOR_INPUTMODECOMPLETED;
    /* @56 */	jint MEDIATOR_ISCLEARKEY;
    /* @60 */	jint MEDIATOR_GETAVAILABLESIZE;
    /* @64 */	jint id;
    /* @68 */	jint instanceData;
    /* @72 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @76 */	jobject_array * JVM_FIELD_CONST isMap;
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryFactory */
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST language;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
};

struct Java_com_sun_midp_chameleon_input_PTIteratorImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIteratorImpl */
    /*  @4 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST buffer;
    /*  @8 */	jint selected;
    /* @12 */	jobject_array * JVM_FIELD_CONST keyMap;
    /* @16 */	jobject_array * JVM_FIELD_CONST list;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST states;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$1 */
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable_00024Accept {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Accept */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable_00024Reject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Reject */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00024SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_layers_ScrollablePopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad274;
    /* @47 */	jbyte ___pad275;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/ScrollablePopupLayer */
    /* @56 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
};

struct Java_com_sun_midp_chameleon_layers_InputModeLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad276;
    /* @47 */	jbyte ___pad277;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/InputModeLayer */
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST mode;
    /* @60 */	jint stringWidth;
    /* @64 */	jint stringHeight;
    /* @68 */	jint_array * JVM_FIELD_CONST anchor;
};

struct Java_com_sun_midp_chameleon_layers_ScrollArrowLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad278;
    /* @47 */	jbyte ___pad279;
    /* com/sun/midp/chameleon/layers/ScrollIndLayer */
    /* @48 */	struct Java_com_sun_midp_chameleon_CLayer * JVM_FIELD_CONST scrollable;
    /* @52 */	struct Java_com_sun_midp_chameleon_ScrollListener * JVM_FIELD_CONST listener;
    /* @56 */	jboolean alertMode;
    /* @57 */	jbyte ___pad280;
    /* @58 */	jbyte ___pad281;
    /* @59 */	jbyte ___pad282;
    /* com/sun/midp/chameleon/layers/ScrollArrowLayer */
    /* @60 */	jboolean upViz;
    /* @61 */	jboolean downViz;
    /* @62 */	jbyte ___pad283;
    /* @63 */	jbyte ___pad284;
};

struct Java_com_sun_midp_chameleon_layers_ScrollBarLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad285;
    /* @47 */	jbyte ___pad286;
    /* com/sun/midp/chameleon/layers/ScrollIndLayer */
    /* @48 */	struct Java_com_sun_midp_chameleon_CLayer * JVM_FIELD_CONST scrollable;
    /* @52 */	struct Java_com_sun_midp_chameleon_ScrollListener * JVM_FIELD_CONST listener;
    /* @56 */	jboolean alertMode;
    /* @57 */	jbyte ___pad287;
    /* @58 */	jbyte ___pad288;
    /* @59 */	jbyte ___pad289;
    /* com/sun/midp/chameleon/layers/ScrollBarLayer */
    /* @60 */	jint lastx;
    /* @64 */	jint lasty;
    /* @68 */	jint gap;
    /* @72 */	jint scrollType;
    /* @76 */	jint proportion;
    /* @80 */	jint position;
    /* @84 */	jint thumbY;
    /* @88 */	jint thumbHeight;
    /* @92 */	jint barHeight;
    /* @96 */	struct Java_java_util_Timer * JVM_FIELD_CONST aT;
};

struct Java_com_sun_midp_chameleon_layers_ScrollBarLayer_00024ArrowTimerTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/chameleon/layers/ScrollBarLayer$ArrowTimerTask */
    /* @28 */	struct Java_com_sun_midp_chameleon_layers_ScrollBarLayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_skins_AlertSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/AlertSkin */
};

struct Java_com_sun_midp_chameleon_skins_BusyCursorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/BusyCursorSkin */
};

struct Java_com_sun_midp_chameleon_skins_ChoiceGroupSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ChoiceGroupSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateEditorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateEditorSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_GaugeSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/GaugeSkin */
};

struct Java_com_sun_midp_chameleon_skins_ImageItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ImageItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_InputModeSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/InputModeSkin */
};

struct Java_com_sun_midp_chameleon_skins_MenuSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/MenuSkin */
};

struct Java_com_sun_midp_chameleon_skins_PTISkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/PTISkin */
};

struct Java_com_sun_midp_chameleon_skins_ProgressBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ProgressBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScreenSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScreenSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScrollIndSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScrollIndSkin */
};

struct Java_com_sun_midp_chameleon_skins_SkinPropertiesIDs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SkinPropertiesIDs */
};

struct Java_com_sun_midp_chameleon_skins_SoftButtonSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SoftButtonSkin */
};

struct Java_com_sun_midp_chameleon_skins_StringItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/StringItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_TextFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TextFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_TickerSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TickerSkin */
};

struct Java_com_sun_midp_chameleon_skins_TitleSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TitleSkin */
};

struct Java_com_sun_midp_chameleon_skins_UpdateBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/UpdateBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_resources_AlertResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/AlertResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_BusyCursorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/BusyCursorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ChoiceGroupResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ChoiceGroupResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateEditorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateEditorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_FontResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/FontResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_FontResourcesConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/FontResourcesConstants */
};

struct Java_com_sun_midp_chameleon_skins_resources_GaugeResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/GaugeResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ImageItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ImageItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_InputModeResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/InputModeResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinData */
    /*  @4 */	jint_array * JVM_FIELD_CONST properties;
    /*  @8 */	jint_array * JVM_FIELD_CONST intSeqValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST stringValues;
    /* @16 */	jint_array * JVM_FIELD_CONST fontValues;
    /* @20 */	jobject_array * JVM_FIELD_CONST imageValues;
    /* @24 */	jint_array * JVM_FIELD_CONST romizedImageIndexes;
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinResources */
    /*  @4 */	jobject_array * JVM_FIELD_CONST fonts;
    /*  @8 */	jobject_array * JVM_FIELD_CONST images;
};

struct Java_com_sun_midp_chameleon_skins_resources_MenuResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/MenuResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_PTIResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/PTIResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ProgressBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ProgressBarResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScreenResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScreenResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScrollIndResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScrollIndResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScrollIndResourcesConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScrollIndResourcesConstants */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResources_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResources$1 */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResources_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResources$SecurityTrusted */
};

struct Java_com_sun_midp_lcdui_DisplayAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayAccess */
};

struct Java_com_sun_midp_lcdui_GraphicsAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GraphicsAccess */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResourcesConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResourcesConstants */
};

struct Java_com_sun_midp_chameleon_skins_resources_SoftButtonResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SoftButtonResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_StringItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/StringItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TextFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TextFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TickerResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TickerResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TitleResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TitleResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_UpdateBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/UpdateBarResources */
};

struct Java_com_sun_midp_configurator_AlertTypeConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/configurator/AlertTypeConstants */
};

struct Java_com_sun_midp_configurator_Constants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/configurator/Constants */
};

struct Java_com_sun_midp_content_CHManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/content/CHManager */
};

struct Java_com_sun_midp_installer_Installer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_com_sun_midp_installer_Verifier * JVM_FIELD_CONST verifier;
    /*  @8 */	struct Java_com_sun_midp_installer_InstallStateImpl * JVM_FIELD_CONST state;
    /* @12 */	struct Java_com_sun_j2me_security_AccessControlContext * JVM_FIELD_CONST accessControlContext;
    /* @16 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST info;
    /* @20 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST settings;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcRuntimeEnv;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST additionalPermissions;
    /* @44 */	jboolean notCopyJarFile;
    /* @45 */	jbyte ___pad290;
    /* @46 */	jbyte ___pad291;
    /* @47 */	jbyte ___pad292;
};

struct Java_com_sun_midp_installer_InstallState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallState */
};

struct Java_com_sun_midp_crypto_Cipher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
};

struct Java_com_sun_midp_crypto_Key {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Key */
};

struct Java_com_sun_midp_crypto_CryptoParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/CryptoParameter */
};

struct Java_com_sun_midp_crypto_AES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/AES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_Padder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Padder */
};

struct Java_com_sun_midp_crypto_BlockCipherBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad293;
};

struct Java_com_sun_midp_crypto_AES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad294;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_AES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad295;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
    /* com/sun/midp/crypto/AES_CBC */
    /* @72 */	jbyte_array * JVM_FIELD_CONST scratchPad;
    /* @76 */	jbyte_array * JVM_FIELD_CONST savedState;
};

struct Java_com_sun_midp_crypto_GeneralSecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
};

struct Java_com_sun_midp_crypto_InvalidKeyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeyException */
};

struct Java_com_sun_midp_crypto_SecretKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecretKey */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST secret;
};

struct Java_com_sun_midp_crypto_ARC4 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/ARC4 */
    /*  @4 */	jint mode;
    /*  @8 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST ckey;
    /* @12 */	jbyte_array * JVM_FIELD_CONST S;
    /* @16 */	jint_array * JVM_FIELD_CONST ii;
    /* @20 */	jint_array * JVM_FIELD_CONST jj;
};

struct Java_com_sun_midp_crypto_NoSuchPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchPaddingException */
};

struct Java_com_sun_midp_crypto_ShortBufferException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/ShortBufferException */
};

struct Java_com_sun_midp_crypto_BadPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/BadPaddingException */
};

struct Java_com_sun_midp_crypto_PKCS5Padding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PKCS5Padding */
    /*  @4 */	jint blockSize;
};

struct Java_com_sun_midp_crypto_InvalidAlgorithmParameterException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidAlgorithmParameterException */
};

struct Java_com_sun_midp_crypto_IllegalBlockSizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/IllegalBlockSizeException */
};

struct Java_com_sun_midp_crypto_NoSuchAlgorithmException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchAlgorithmException */
};

struct Java_com_sun_midp_crypto_DES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_DES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad296;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad297;
    /* @50 */	jbyte ___pad298;
    /* @51 */	jbyte ___pad299;
};

struct Java_com_sun_midp_crypto_DES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad300;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad301;
    /* @50 */	jbyte ___pad302;
    /* @51 */	jbyte ___pad303;
    /* com/sun/midp/crypto/DES_CBC */
    /* @52 */	jbyte_array * JVM_FIELD_CONST chainingBlock;
    /* @56 */	jbyte_array * JVM_FIELD_CONST storeBuffer;
    /* @60 */	jbyte_array * JVM_FIELD_CONST savedChainingBlock;
};

struct Java_com_sun_midp_crypto_DESEDE {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
    /* com/sun/midp/crypto/DESEDE */
};

struct Java_com_sun_midp_crypto_DigestException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/DigestException */
};

struct Java_com_sun_midp_crypto_InvalidKeySpecException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeySpecException */
};

struct Java_com_sun_midp_crypto_IvParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/IvParameter */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST IV;
};

struct Java_com_sun_midp_crypto_MessageDigest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
};

struct Java_com_sun_midp_crypto_MD2 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD2 */
    /*  @4 */	jint_array * JVM_FIELD_CONST num;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint_array * JVM_FIELD_CONST cksm;
    /* @16 */	jint_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_MD5 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD5 */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SHA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/SHA */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SecureRandom {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
};

struct Java_com_sun_midp_crypto_PRand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
    /* com/sun/midp/crypto/PRand */
};

struct Java_com_sun_midp_crypto_PrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PrivateKey */
};

struct Java_com_sun_midp_crypto_PublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PublicKey */
};

struct Java_com_sun_midp_crypto_RSAKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
};

struct Java_com_sun_midp_crypto_RSA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/RSA */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST ckey;
    /*  @8 */	jint mode;
    /* @12 */	jbyte_array * JVM_FIELD_CONST messageToSign;
    /* @16 */	jint bytesInMessage;
};

struct Java_com_sun_midp_crypto_RSAPrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPrivateKey */
};

struct Java_com_sun_midp_crypto_RSAPublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPublicKey */
};

struct Java_com_sun_midp_crypto_RSASig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSASig */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @12 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST c;
    /* @16 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST k;
    /* @20 */	jbyte_array * JVM_FIELD_CONST prefix;
};

struct Java_com_sun_midp_crypto_SignatureException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/SignatureException */
};

struct Java_com_sun_midp_crypto_Signature {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
};

struct Java_com_sun_midp_crypto_RsaMd5Sig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaMd5Sig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_RsaShaSig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaShaSig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Util */
};

struct Java_com_sun_midp_events_EventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventListener */
};

struct Java_com_sun_midp_events_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
};

struct Java_com_sun_midp_events_DispatchData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/DispatchData */
    /*  @4 */	struct Java_com_sun_midp_events_EventListener * JVM_FIELD_CONST listener;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST waitingEvent;
};

struct Java_com_sun_midp_events_NativeEventPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventPool */
    /*  @4 */	jobject_array * JVM_FIELD_CONST eventStack;
    /*  @8 */	jint eventsInPool;
};

struct Java_com_sun_midp_events_NativeEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/events/NativeEvent */
    /* @12 */	jint intParam1;
    /* @16 */	jint intParam2;
    /* @20 */	jint intParam3;
    /* @24 */	jint intParam4;
    /* @28 */	jint intParam5;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam1;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam2;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam3;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam4;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam5;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam6;
};

struct Java_com_sun_midp_events_NativeEventMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventMonitor */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST eventQueueLock;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @12 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
};

struct Java_com_sun_midp_events_EventTypes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventTypes */
};

struct Java_com_sun_midp_i18n_ResourceBundle {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceBundle */
};

struct Java_com_sun_midp_i18n_Resource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/Resource */
};

struct Java_com_sun_midp_l10n_LocalizedStringsBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
};

struct Java_com_sun_midp_l10n_LocalizedStrings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
    /* com/sun/midp/l10n/LocalizedStrings */
};

struct Java_com_sun_midp_i18n_ResourceConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceConstants */
};

struct Java_com_sun_midp_installer_AccessControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/security/AccessControlContextAdapter */
    /* com/sun/midp/installer/AccessControl */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST suite;
};

struct Java_com_sun_midp_installer_AppGallery {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AppGallery */
    /*  @8 */	struct Java_com_sun_midp_installer_AppGalleryJarList * JVM_FIELD_CONST chooseApp;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_com_sun_midp_installer_SplashScreen * JVM_FIELD_CONST splashScreen;
    /* @20 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @28 */	struct Java_java_util_Timer * JVM_FIELD_CONST tickerTimer;
    /* @32 */	jboolean cancel_conn;
    /* @33 */	jbyte ___pad304;
    /* @34 */	jbyte ___pad305;
    /* @35 */	jbyte ___pad306;
};

struct Java_com_sun_midp_installer_AppGalleryJarList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad307;
    /* @31 */	jbyte ___pad308;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/List */
    /* @32 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectCommand;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST listLF;
    /* com/sun/midp/installer/AppGalleryJarList */
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST entries;
};

struct Java_com_sun_midp_installer_JarEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/JarEntry */
    /*  @4 */	jint entryID;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST entryName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST entryTitle;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST entrySmalldesc;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST entryFilesize;
};

struct Java_com_sun_midp_installer_AppGallery_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGallery$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_FirstPageHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/midp/installer/FirstPageHandler */
    /*  @4 */	jint no_element;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST elements;
    /* @16 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST element;
    /* @24 */	jobject_array * JVM_FIELD_CONST values;
};

struct Java_com_sun_midp_installer_AppGallery_000242 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/midp/installer/FirstPageHandler */
    /*  @4 */	jint no_element;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST elements;
    /* @16 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST element;
    /* @24 */	jobject_array * JVM_FIELD_CONST values;
    /* com/sun/midp/installer/AppGallery$2 */
    /* @28 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_AppGallery_000243 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGalleryLoader */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST parser;
    /* com/sun/midp/installer/AppGallery$3 */
    /* @12 */	struct Java_com_sun_midp_installer_FirstPageHandler * JVM_FIELD_CONST val_044handler;
    /* @16 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
    /* @20 */	jboolean selected;
    /* @21 */	jbyte ___pad309;
    /* @22 */	jbyte ___pad310;
    /* @23 */	jbyte ___pad311;
};

struct Java_com_sun_midp_installer_AppGallery_000243_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGallery$3$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_AppGallery_000243 * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_installer_AppGallery_000243_000242 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGallery$3$2 */
    /*  @4 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST val_044list;
    /*  @8 */	struct Java_com_sun_midp_installer_AppGallery_000243 * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_installer_AppGalleryLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGalleryLoader */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST parser;
};

struct Java_com_sun_midp_installer_AppGallery_000244 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/midp/installer/FirstPageHandler */
    /*  @4 */	jint no_element;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST elements;
    /* @16 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST element;
    /* @24 */	jobject_array * JVM_FIELD_CONST values;
    /* com/sun/midp/installer/AppGallery$4 */
    /* @28 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_AppGallery_000245 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGalleryLoader */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST parser;
    /* com/sun/midp/installer/AppGallery$5 */
    /* @12 */	struct Java_com_sun_midp_installer_JarEntry * JVM_FIELD_CONST val_044entry;
    /* @16 */	struct Java_com_sun_midp_installer_FirstPageHandler * JVM_FIELD_CONST val_044handler;
    /* @20 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_AppGallery_000245_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGallery$5$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_AppGallery_000245 * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_installer_AppGallery_000246 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/midp/installer/FirstPageHandler */
    /*  @4 */	jint no_element;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST elements;
    /* @16 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST element;
    /* @24 */	jobject_array * JVM_FIELD_CONST values;
    /* com/sun/midp/installer/AppGallery$6 */
    /* @28 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_AppGallery_000247 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AppGalleryLoader */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST parser;
    /* com/sun/midp/installer/AppGallery$7 */
    /* @12 */	struct Java_com_sun_midp_installer_FirstPageHandler * JVM_FIELD_CONST val_044handler;
    /* @16 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_AppGallery_00024TickerTimerTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/installer/AppGallery$TickerTimerTask */
    /* @28 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @32 */	struct Java_com_sun_midp_installer_AppGalleryJarList * JVM_FIELD_CONST appList;
    /* @36 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_SplashScreen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad312;
    /* @31 */	jbyte ___pad313;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad314;
    /* @38 */	jbyte ___pad315;
    /* @39 */	jbyte ___pad316;
    /* com/sun/midp/installer/SplashScreen */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST splashScreen;
    /* @44 */	struct Java_com_sun_midp_installer_AppGallery * JVM_FIELD_CONST appgal;
};

struct Java_javax_microedition_io_ConnectionNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/io/ConnectionNotFoundException */
};

struct Java_com_sun_midp_installer_InstallListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallListener */
};

struct Java_com_sun_midp_installer_AutoTesterInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterInterface */
};

struct Java_com_sun_midp_installer_InvalidJadException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/midp/installer/InvalidJadException */
    /* @12 */	jint reason;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST extraData;
};

struct Java_com_sun_midp_installer_AutoTesterBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
};

struct Java_com_sun_midp_installer_AutoTester {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTester */
};

struct Java_com_sun_midp_lcdui_DynamicCharacterArray {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DynamicCharacterArray */
    /*  @4 */	jchar_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint length;
};

struct Java_javax_microedition_lcdui_TextFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLF */
};

struct Java_com_sun_midp_installer_InstallStateImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallStateImpl */
    /*  @4 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /*  @8 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST suiteSettings;
    /* @12 */	jint storageId;
    /* @16 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST listener;
    /* @20 */	jlong startTime;
    /* @28 */	jint nextStep;
    /* @32 */	struct Java_com_sun_midp_installer_InvalidJadException * JVM_FIELD_CONST exception;
    /* @36 */	jbyte_array * JVM_FIELD_CONST jad;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST jadEncoding;
    /* @44 */	struct Java_com_sun_midp_installer_JadProperties * JVM_FIELD_CONST jadProps;
    /* @48 */	struct Java_com_sun_midp_installer_ManifestProperties * JVM_FIELD_CONST jarProps;
    /* @52 */	struct Java_com_sun_midp_io_j2me_storage_File * JVM_FIELD_CONST file;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST username;
    /* @60 */	struct Java_java_lang_String * JVM_FIELD_CONST password;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyUsername;
    /* @68 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyPassword;
    /* @72 */	jint beginTransferDataStatus;
    /* @76 */	jint transferStatus;
    /* @80 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @84 */	jbyte_array * JVM_FIELD_CONST manifest;
    /* @88 */	struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream * JVM_FIELD_CONST storage;
    /* @92 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST storageRoot;
    /* @100 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST previousSuite;
    /* @104 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST previousInstallInfo;
    /* @108 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @112 */	jboolean stopInstallation;
    /* @113 */	jboolean ignoreCancel;
    /* @114 */	jboolean force;
    /* @115 */	jboolean removeRMS;
    /* @116 */	jboolean isPreviousVersion;
    /* @117 */	jbyte ___pad317;
    /* @118 */	jbyte ___pad318;
    /* @119 */	jbyte ___pad319;
};

struct Java_com_sun_midp_io_j2me_storage_File {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/storage/File */
};

struct Java_com_sun_midp_installer_JadProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
};

struct Java_com_sun_midp_installer_ManifestProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
    /* com/sun/midp/installer/ManifestProperties */
    /* @20 */	jint remainder;
};

struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad320;
    /* @22 */	jbyte ___pad321;
    /* @23 */	jbyte ___pad322;
    /* com/sun/midp/io/j2me/storage/RandomAccessStream */
    /* @24 */	jint handle;
};

struct Java_com_sun_midp_installer_Verifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Verifier */
};

struct Java_com_sun_midp_util_Properties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
};

struct Java_com_sun_midp_installer_HttpInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_com_sun_midp_installer_Verifier * JVM_FIELD_CONST verifier;
    /*  @8 */	struct Java_com_sun_midp_installer_InstallStateImpl * JVM_FIELD_CONST state;
    /* @12 */	struct Java_com_sun_j2me_security_AccessControlContext * JVM_FIELD_CONST accessControlContext;
    /* @16 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST info;
    /* @20 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST settings;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcRuntimeEnv;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST additionalPermissions;
    /* @44 */	jboolean notCopyJarFile;
    /* @45 */	jbyte ___pad323;
    /* @46 */	jbyte ___pad324;
    /* @47 */	jbyte ___pad325;
    /* com/sun/midp/installer/HttpInstaller */
    /* @48 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpConnection;
    /* @52 */	struct Java_java_io_InputStream * JVM_FIELD_CONST httpInputStream;
};

struct Java_com_sun_midp_installer_AutoTesterMulti_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$1 */
};

struct Java_com_sun_midp_installer_AutoTesterMulti {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTesterMulti */
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
};

struct Java_com_sun_midp_installer_AutoTesterMulti_00024AutoTesterRunner {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$AutoTesterRunner */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST storage;
    /* @12 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @16 */	struct Java_com_sun_midp_installer_AutoTesterMulti * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_DeviceDesc {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DeviceDesc */
};

struct Java_com_sun_midp_installer_DiscoveryApp_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$1 */
};

struct Java_com_sun_midp_installer_DiscoveryApp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/DiscoveryApp */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultInstallListUrl;
    /* @16 */	struct Java_javax_microedition_lcdui_TextBox * JVM_FIELD_CONST urlTextBox;
    /* @20 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @24 */	jint progressGaugeIndex;
    /* @28 */	jint progressUrlIndex;
    /* @32 */	jlong lastDisplayChange;
    /* @40 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST installListBox;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST lastInstallMidletName;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST discoverCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST installCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST chooseMethod;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST installLocCmd;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST last_dir;
    /* @84 */	jboolean http_install;
    /* @85 */	jbyte ___pad326;
    /* @86 */	jbyte ___pad327;
    /* @87 */	jbyte ___pad328;
};

struct Java_com_sun_midp_installer_DiscoveryApp_00024BackgroundInstallListGetter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$BackgroundInstallListGetter */
    /*  @4 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_DiscoveryApp_00024FileEntryItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/installer/DiscoveryApp$FileEntryItem */
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @60 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST parent;
    /* @64 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST ENTRY_FONT;
    /* @68 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST this_0440;
    /* @72 */	jboolean hasFocus;
    /* @73 */	jboolean dir;
    /* @74 */	jbyte ___pad329;
    /* @75 */	jbyte ___pad330;
};

struct Java_javax_microedition_lcdui_GaugeLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/GaugeLF */
};

struct Java_com_sun_midp_installer_FileInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_com_sun_midp_installer_Verifier * JVM_FIELD_CONST verifier;
    /*  @8 */	struct Java_com_sun_midp_installer_InstallStateImpl * JVM_FIELD_CONST state;
    /* @12 */	struct Java_com_sun_j2me_security_AccessControlContext * JVM_FIELD_CONST accessControlContext;
    /* @16 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST info;
    /* @20 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST settings;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcRuntimeEnv;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST additionalPermissions;
    /* @44 */	jboolean notCopyJarFile;
    /* @45 */	jbyte ___pad331;
    /* @46 */	jbyte ___pad332;
    /* @47 */	jbyte ___pad333;
    /* com/sun/midp/installer/FileInstaller */
};

struct Java_com_sun_midp_installer_GraphicalInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/GraphicalInstaller */
    /*  @8 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST passwordForm;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST usernameField;
    /* @24 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST passwordField;
    /* @28 */	struct Java_com_sun_midp_installer_GraphicalInstaller_00024BackgroundInstaller * JVM_FIELD_CONST backgroundInstaller;
    /* @32 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @36 */	jint progressGaugeIndex;
    /* @40 */	jint progressUrlIndex;
    /* @44 */	jlong lastDisplayChange;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST cancelledMessage;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST finishingMessage;
    /* @60 */	jint storageId;
    /* @64 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST stopCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST continueCmd;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST nextCmd;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keepRMSCmd;
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeRMSCmd;
    /* @96 */	jboolean http_install;
    /* @97 */	jbyte ___pad334;
    /* @98 */	jbyte ___pad335;
    /* @99 */	jbyte ___pad336;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_00024BackgroundInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$BackgroundInstaller */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST successMessage;
    /* @20 */	struct Java_com_sun_midp_installer_InstallState * JVM_FIELD_CONST installState;
    /* @24 */	jint preferredDispId;
    /* @28 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
    /* @32 */	jboolean update;
    /* @33 */	jboolean noConfirmation;
    /* @34 */	jboolean continueInstall;
    /* @35 */	jboolean jarOnly;
    /* @36 */	jboolean proxyAuth;
    /* @37 */	jbyte ___pad337;
    /* @38 */	jbyte ___pad338;
    /* @39 */	jbyte ___pad339;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_000242 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$2 */
    /*  @4 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST val_044selector;
    /*  @8 */	jint val_044mid;
    /* @12 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteLockedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteLockedException */
};

struct Java_javax_microedition_rms_RecordFilter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordFilter */
};

struct Java_javax_microedition_rms_RecordComparator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordComparator */
};

struct Java_javax_microedition_rms_RecordEnumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumeration */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteCorruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteCorruptedException */
};

struct Java_com_sun_midp_installer_InstallRetryHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallRetryHandler */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST token;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST suite;
};

struct Java_com_sun_midp_pki_X509Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/X509Certificate */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST fp;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST serialNumber;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST subject;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST issuer;
    /* @20 */	jlong from;
    /* @28 */	jlong until;
    /* @36 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST pubKey;
    /* @40 */	jint idx;
    /* @44 */	jbyte_array * JVM_FIELD_CONST enc;
    /* @48 */	jint TBSStart;
    /* @52 */	jint TBSLen;
    /* @56 */	jbyte_array * JVM_FIELD_CONST signature;
    /* @60 */	jbyte_array * JVM_FIELD_CONST TBSCertHash;
    /* @64 */	struct Java_java_util_Vector * JVM_FIELD_CONST subjectAltNames;
    /* @68 */	jint pLenConstr;
    /* @72 */	jint keyUsage;
    /* @76 */	jint extKeyUsage;
    /* @80 */	jboolean selfSigned;
    /* @81 */	jbyte version;
    /* @82 */	jbyte sigAlg;
    /* @83 */	jboolean badExt;
    /* @84 */	jboolean hasBC;
    /* @85 */	jboolean isCA;
    /* @86 */	jbyte ___pad340;
    /* @87 */	jbyte ___pad341;
};

struct Java_com_sun_midp_pki_CertStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/CertStore */
};

struct Java_javax_microedition_pki_Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pki/Certificate */
};

struct Java_com_sun_midp_installer_VerifierImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/VerifierImpl */
    /*  @4 */	struct Java_com_sun_midp_installer_InstallState * JVM_FIELD_CONST state;
    /*  @8 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @12 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cpCert;
};

struct Java_com_sun_midp_installer_InternalMIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InternalMIDletSuiteImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /*  @8 */	jint id;
    /* @12 */	jbyte_array * JVM_FIELD_CONST permissions;
    /* @16 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /* @20 */	struct Java_com_sun_midp_installer_JadProperties * JVM_FIELD_CONST jadProps;
    /* @24 */	struct Java_com_sun_midp_installer_ManifestProperties * JVM_FIELD_CONST jarProps;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST initialMIDletClassName;
    /* @32 */	jint numberOfMidlets;
    /* @36 */	jboolean trusted;
    /* @37 */	jbyte ___pad342;
    /* @38 */	jbyte ___pad343;
    /* @39 */	jbyte ___pad344;
};

struct Java_com_sun_midp_installer_PendingNotification {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/PendingNotification */
    /*  @4 */	jint retries;
    /*  @8 */	jint suiteId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
};

struct Java_com_sun_midp_installer_OtaNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/OtaNotifier */
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionPool */
    /*  @4 */	jlong m_connectionLingerTime;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST m_connections;
    /* @16 */	jint m_max_connections;
};

struct Java_javax_microedition_io_StreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnection */
};

struct Java_com_sun_midp_io_HttpUrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/HttpUrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST scheme;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST authority;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST fragment;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST machine;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
};

struct Java_com_sun_midp_io_j2me_http_Protocol_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/Protocol$1 */
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST m_protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST m_host;
    /* @12 */	jint m_port;
    /* @16 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST m_stream;
    /* @20 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST m_data_input_stream;
    /* @24 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST m_data_output_stream;
    /* @28 */	jlong m_time;
    /* @36 */	jboolean m_in_use;
    /* @37 */	jboolean m_removed;
    /* @38 */	jbyte ___pad345;
    /* @39 */	jbyte ___pad346;
};

struct Java_javax_microedition_io_OutputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/OutputConnection */
};

struct Java_javax_microedition_io_InputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/InputConnection */
};

struct Java_javax_microedition_io_ContentConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ContentConnection */
};

struct Java_com_sun_midp_io_ConnectionBaseAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad347;
    /* @22 */	jbyte ___pad348;
    /* @23 */	jbyte ___pad349;
};

struct Java_com_sun_midp_io_j2me_http_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad350;
    /* @22 */	jbyte ___pad351;
    /* @23 */	jbyte ___pad352;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @116 */	jboolean permissionChecked;
    /* @117 */	jboolean ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad353;
};

struct Java_com_sun_midp_installer_SuiteDownloadInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/SuiteDownloadInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @12 */	jboolean dir;
    /* @13 */	jboolean http;
    /* @14 */	jbyte ___pad354;
    /* @15 */	jbyte ___pad355;
};

struct Java_com_sun_midp_installer_SuiteVerifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/SuiteVerifier */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCommand;
    /* @16 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @20 */	jint progressGaugeIndex;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST jarPath;
    /* @28 */	jint suiteId;
    /* @32 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST suiteStorage;
};

struct Java_com_sun_midp_installer_SuiteVerifier_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/SuiteVerifier$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_SuiteVerifier * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_SuiteVerifier_00024BackgroundVerifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/SuiteVerifier$BackgroundVerifier */
    /*  @4 */	struct Java_com_sun_midp_installer_SuiteVerifier * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST jarPath;
    /* @12 */	struct Java_com_sun_midp_installer_SuiteVerifier * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_pki_CertificateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/pki/CertificateException */
    /* @12 */	struct Java_javax_microedition_pki_Certificate * JVM_FIELD_CONST cert;
    /* @16 */	jbyte reason;
    /* @17 */	jbyte ___pad356;
    /* @18 */	jbyte ___pad357;
    /* @19 */	jbyte ___pad358;
};

struct Java_com_sun_midp_publickeystore_WebPublicKeyStore_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/WebPublicKeyStore$1 */
};

struct Java_com_sun_midp_publickeystore_InputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/InputStorage */
    /*  @4 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_io_Base64 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Base64 */
};

struct Java_com_sun_midp_io_BaseInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/io/BaseInputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jbyte_array * JVM_FIELD_CONST markBuf;
    /* @16 */	jint markSize;
    /* @20 */	jint markPos;
    /* @24 */	jboolean isReadFromBuffer;
    /* @25 */	jbyte ___pad359;
    /* @26 */	jbyte ___pad360;
    /* @27 */	jbyte ___pad361;
};

struct Java_java_io_InterruptedIOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/InterruptedIOException */
    /* @12 */	jint bytesTransferred;
};

struct Java_com_sun_midp_io_BaseOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/io/BaseOutputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
};

struct Java_com_sun_midp_io_BufferedConnectionAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad362;
    /* @22 */	jbyte ___pad363;
    /* @23 */	jbyte ___pad364;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad365;
    /* @38 */	jbyte ___pad366;
    /* @39 */	jbyte ___pad367;
};

struct Java_com_sun_midp_io_NetworkConnectionBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad368;
    /* @22 */	jbyte ___pad369;
    /* @23 */	jbyte ___pad370;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad371;
    /* @38 */	jbyte ___pad372;
    /* @39 */	jbyte ___pad373;
    /* com/sun/midp/io/NetworkConnectionBase */
};

struct Java_com_sun_midp_io_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Util */
};

struct Java_javax_wireless_messaging_Message {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/Message */
};

struct Java_javax_wireless_messaging_MessageListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageListener */
};

struct Java_javax_wireless_messaging_MessageConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageConnection */
};

struct Java_com_sun_midp_io_j2me_ProtocolBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ProtocolBase */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST ADDRESS_PREFIX;
};

struct Java_javax_microedition_io_CommConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/CommConnection */
};

struct Java_com_sun_midp_io_j2me_comm_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad374;
    /* @22 */	jbyte ___pad375;
    /* @23 */	jbyte ___pad376;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad377;
    /* @38 */	jbyte ___pad378;
    /* @39 */	jbyte ___pad379;
    /* com/sun/midp/io/j2me/comm/Protocol */
    /* @40 */	jint handle;
    /* @44 */	jint bbc;
    /* @48 */	jint stop;
    /* @52 */	jint parity;
    /* @56 */	jint rts;
    /* @60 */	jint cts;
    /* @64 */	jint baud;
    /* @68 */	jboolean blocking;
    /* @69 */	jbyte ___pad380;
    /* @70 */	jbyte ___pad381;
    /* @71 */	jbyte ___pad382;
};

struct Java_java_io_DataInput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataInput */
};

struct Java_java_io_DataOutput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataOutput */
};

struct Java_javax_microedition_io_Datagram {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Datagram */
};

struct Java_com_sun_midp_io_j2me_datagram_DatagramObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/DatagramObject */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /* @20 */	jint ipNumber;
    /* @24 */	jint port;
    /* @28 */	jint readWritePosition;
};

struct Java_java_io_UTFDataFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UTFDataFormatException */
};

struct Java_com_sun_midp_io_j2me_datagram_Protocol_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/Protocol$1 */
};

struct Java_com_sun_midp_io_j2me_datagram_Protocol_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/Protocol$SecurityTrusted */
};

struct Java_javax_microedition_io_DatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/DatagramConnection */
};

struct Java_javax_microedition_io_UDPDatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/UDPDatagramConnection */
};

struct Java_com_sun_midp_io_j2me_datagram_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/Protocol */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @12 */	jint nativeHandle;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @20 */	jint port;
    /* @24 */	jboolean open;
    /* @25 */	jboolean ownerTrusted;
    /* @26 */	jbyte ___pad383;
    /* @27 */	jbyte ___pad384;
};

struct Java_com_sun_midp_io_j2me_datagram_ProtocolPushImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/ProtocolPush */
    /* com/sun/midp/io/j2me/datagram/ProtocolPushImpl */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_datagram_ProtocolPushImpl * JVM_FIELD_CONST pushInstance;
};

struct Java_com_sun_midp_io_j2me_push_ProtocolPush {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/ProtocolPush */
};

struct Java_com_sun_midp_io_j2me_file_BaseFileHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/BaseFileHandler */
};

struct Java_com_sun_midp_io_j2me_file_DefaultFileHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/DefaultFileHandler */
    /*  @4 */	jint readHandle;
    /*  @8 */	jint writeHandle;
    /* @12 */	jlong fileName;
    /* @20 */	jlong rootDir;
};

struct Java_com_sun_midp_io_j2me_file_EscapedUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/EscapedUtil */
};

struct Java_com_sun_midp_io_j2me_file_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad385;
    /* @22 */	jbyte ___pad386;
    /* @23 */	jbyte ___pad387;
    /* com/sun/midp/io/j2me/file/Protocol */
    /* @24 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST classSecurityToken;
    /* @28 */	jint mode;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST fileName;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST filePath;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST fileRoot;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST fileURL;
    /* @48 */	struct Java_com_sun_midp_io_j2me_file_BaseFileHandler * JVM_FIELD_CONST fileHandler;
    /* @52 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fis;
    /* @56 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST fos;
};

struct Java_com_sun_midp_io_j2me_file_FileConnectionInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/io/j2me/file/FileConnectionInputStream */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_file_Protocol * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jbyte_array * JVM_FIELD_CONST markBuf;
    /* @16 */	jint markSize;
    /* @20 */	jint markPos;
    /* @24 */	jboolean isReadFromBuffer;
    /* @25 */	jbyte ___pad388;
    /* @26 */	jbyte ___pad389;
    /* @27 */	jbyte ___pad390;
};

struct Java_javax_microedition_io_file_FileConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileConnection */
};

struct Java_javax_microedition_io_file_ConnectionClosedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/io/file/ConnectionClosedException */
};

struct Java_javax_microedition_io_file_IllegalModeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/io/file/IllegalModeException */
};

struct Java_com_sun_midp_io_j2me_file_RootCache {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/RootCache */
    /*  @4 */	jobject_array * JVM_FIELD_CONST roots;
};

struct Java_com_sun_midp_io_j2me_http_Protocol_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/Protocol$SecurityTrusted */
};

struct Java_com_sun_midp_io_j2me_socket_Protocol_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/socket/Protocol$1 */
};

struct Java_com_sun_midp_suspend_NetworkSubsystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST subsystems;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST dependencies;
    /* com/sun/midp/suspend/NetworkSubsystem */
};

struct Java_com_sun_midp_suspend_Subsystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/Subsystem */
};

struct Java_javax_microedition_io_SocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SocketConnection */
};

struct Java_com_sun_midp_io_j2me_socket_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad391;
    /* @22 */	jbyte ___pad392;
    /* @23 */	jbyte ___pad393;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad394;
    /* @38 */	jbyte ___pad395;
    /* @39 */	jbyte ___pad396;
    /* com/sun/midp/io/NetworkConnectionBase */
    /* com/sun/midp/io/j2me/socket/Protocol */
    /* @40 */	jint handle;
    /* @44 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /* @48 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @56 */	jint port;
    /* @60 */	jbyte_array * JVM_FIELD_CONST ipBytes;
    /* @64 */	jboolean outputShutdown;
    /* @65 */	jboolean ownerTrusted;
    /* @66 */	jbyte ___pad397;
    /* @67 */	jbyte ___pad398;
};

struct Java_com_sun_midp_io_j2me_https_Protocol_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/https/Protocol$1 */
};

struct Java_com_sun_midp_io_j2me_https_Protocol_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/https/Protocol$SecurityTrusted */
};

struct Java_com_sun_midp_ssl_SSLStreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLStreamConnection */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_In * JVM_FIELD_CONST uin;
    /* @12 */	struct Java_com_sun_midp_ssl_Out * JVM_FIELD_CONST uout;
    /* @16 */	struct Java_java_io_InputStream * JVM_FIELD_CONST sin;
    /* @20 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST sout;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST serverCert;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST cipherSuite;
    /* @40 */	jint inputStreamState;
    /* @44 */	jint outputStreamState;
    /* @48 */	jboolean copen;
    /* @49 */	jbyte ___pad399;
    /* @50 */	jbyte ___pad400;
    /* @51 */	jbyte ___pad401;
};

struct Java_javax_microedition_io_SecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecurityInfo */
};

struct Java_javax_microedition_io_HttpsConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpsConnection */
};

struct Java_com_sun_midp_io_j2me_https_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad402;
    /* @22 */	jbyte ___pad403;
    /* @23 */	jbyte ___pad404;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST __dup1__proxyHeaders;
    /* @116 */	jboolean __dup1__permissionChecked;
    /* @117 */	jboolean __dup1__ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad405;
    /* com/sun/midp/io/j2me/https/Protocol */
    /* @128 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @132 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
    /* @136 */	jboolean permissionChecked;
    /* @137 */	jboolean ownerTrusted;
    /* @138 */	jbyte ___pad406;
    /* @139 */	jbyte ___pad407;
};

struct Java_com_sun_midp_ssl_Record {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Record */
    /*  @4 */	jint HEADER_SIZE;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @16 */	jbyte_array * JVM_FIELD_CONST inputHeader;
    /* @20 */	jint headerBytesRead;
    /* @24 */	jint dataLength;
    /* @28 */	jint dataBytesRead;
    /* @32 */	jbyte_array * JVM_FIELD_CONST inputData;
    /* @36 */	jint plainTextLength;
    /* @40 */	struct Java_com_sun_midp_ssl_RecordEncoder * JVM_FIELD_CONST encoder;
    /* @44 */	struct Java_com_sun_midp_ssl_RecordDecoder * JVM_FIELD_CONST decoder;
    /* @48 */	jbyte rActive;
    /* @49 */	jbyte wActive;
    /* @50 */	jbyte ver;
    /* @51 */	jboolean shutdown;
};

struct Java_com_sun_midp_ssl_In {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/ssl/In */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	jint start;
    /* @12 */	jint cnt;
    /* @16 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @20 */	jboolean isClosed;
    /* @21 */	jboolean endOfStream;
    /* @22 */	jbyte ___pad408;
    /* @23 */	jbyte ___pad409;
};

struct Java_com_sun_midp_ssl_Out {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/ssl/Out */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @16 */	jboolean isClosed;
    /* @17 */	jbyte ___pad410;
    /* @18 */	jbyte ___pad411;
    /* @19 */	jbyte ___pad412;
};

struct Java_com_sun_midp_io_j2me_push_Connection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/Connection */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST params;
};

struct Java_com_sun_midp_io_j2me_push_ConnectionRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/ConnectionRegistry */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_io_j2me_push_PushRegistryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/PushRegistryImpl */
};

struct Java_com_sun_midp_io_j2me_push_PushRegistryInternal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/PushRegistryInternal */
};

struct Java_javax_wireless_messaging_BinaryMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/BinaryMessage */
};

struct Java_com_sun_midp_io_j2me_sms_MessageObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
};

struct Java_com_sun_midp_io_j2me_sms_BinaryObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/BinaryObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ProtocolBase */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST ADDRESS_PREFIX;
    /* com/sun/midp/io/j2me/sms/Protocol */
    /*  @8 */	jint m_iport;
};

struct Java_javax_wireless_messaging_TextMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/TextMessage */
};

struct Java_com_sun_midp_io_j2me_sms_TextObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/TextObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_sms_TextEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/TextEncoder */
};

struct Java_com_sun_midp_io_j2me_socket_Protocol_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/socket/Protocol$SecurityTrusted */
};

struct Java_com_sun_midp_io_j2me_socket_ProtocolPushImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/ProtocolPush */
    /* com/sun/midp/io/j2me/socket/ProtocolPushImpl */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_socket_ProtocolPushImpl * JVM_FIELD_CONST pushInstance;
};

struct Java_com_sun_midp_io_j2me_socket_ServerSocket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/socket/ServerSocket */
};

struct Java_com_sun_midp_io_j2me_ssl_Protocol_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ssl/Protocol$1 */
};

struct Java_com_sun_midp_io_j2me_ssl_Protocol_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ssl/Protocol$SecurityTrusted */
};

struct Java_javax_microedition_io_SecureConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecureConnection */
};

struct Java_com_sun_midp_io_j2me_ssl_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ssl/Protocol */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_socket_Protocol * JVM_FIELD_CONST tcpConnection;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
};

struct Java_com_sun_midp_jarutil_JarReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jarutil/JarReader */
};

struct Java_com_sun_midp_jsr_JSRInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr/JSRInitializer */
};

struct Java_com_sun_midp_jsr075_Initializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr075/Initializer */
};

struct Java_com_sun_midp_l10n_LocalizedStringsBasezhCN {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBasezhCN */
};

struct Java_com_sun_midp_l10n_LocalizedStringszhCN {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBasezhCN */
    /* com/sun/midp/l10n/LocalizedStringszhCN */
};

struct Java_com_sun_midp_lcdui_CommandAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/CommandAccess */
};

struct Java_com_sun_midp_lcdui_DisplayEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventConsumer */
};

struct Java_com_sun_midp_lcdui_ForegroundEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ForegroundEventConsumer */
};

struct Java_com_sun_midp_lcdui_DisplayContainer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayContainer */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint lastLocalDisplayId;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST displays;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayDeviceAccess */
    /*  @4 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST task;
    /*  @8 */	jint flashCount;
    /* @12 */	jboolean isLit;
    /* @13 */	jbyte ___pad413;
    /* @14 */	jbyte ___pad414;
    /* @15 */	jbyte ___pad415;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess_00024TimerClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/lcdui/DisplayDeviceAccess$TimerClient */
    /* @28 */	jint displayId;
    /* @32 */	struct Java_com_sun_midp_lcdui_DisplayDeviceAccess * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_lcdui_DisplayEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_ForegroundController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ForegroundController */
};

struct Java_com_sun_midp_lcdui_RepaintEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/RepaintEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent1;
    /* @12 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent2;
    /* @16 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent3;
    /* @20 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST queuedEvent;
    /* @24 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST eventInProcess;
};

struct Java_com_sun_midp_lcdui_DisplayEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandler */
};

struct Java_com_sun_midp_lcdui_DisplayEventHandlerFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandlerFactory */
};

struct Java_com_sun_midp_lcdui_DisplayEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_LCDUIEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/LCDUIEvent */
    /* @12 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST changedItem;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @20 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
    /* @24 */	jint minorCode;
    /* @28 */	jboolean hasForeground;
    /* @29 */	jbyte ___pad416;
    /* @30 */	jbyte ___pad417;
    /* @31 */	jbyte ___pad418;
};

struct Java_com_sun_midp_lcdui_DisplayStaticAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayStaticAccess */
};

struct Java_com_sun_midp_lcdui_DisplayFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayFactory */
};

struct Java_com_sun_midp_lcdui_EventConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/EventConstants */
};

struct Java_com_sun_midp_lcdui_ForegroundEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ForegroundEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_ForegroundEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ForegroundEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_javax_microedition_lcdui_game_GameCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad419;
    /* @31 */	jbyte ___pad420;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad421;
    /* @38 */	jbyte ___pad422;
    /* @39 */	jbyte ___pad423;
    /* javax/microedition/lcdui/game/GameCanvas */
    /* @40 */	struct Java_com_sun_midp_lcdui_GameCanvasLFImpl * JVM_FIELD_CONST gameCanvasLF;
};

struct Java_com_sun_midp_lcdui_GameCanvasLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GameCanvasLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_game_GameCanvas * JVM_FIELD_CONST owner;
    /*  @8 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST offscreenBuffer;
    /* @12 */	struct Java_com_sun_midp_lcdui_GraphicsAccess * JVM_FIELD_CONST graphicsAccess;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST gVector;
};

struct Java_com_sun_midp_lcdui_GameAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GameAccess */
};

struct Java_com_sun_midp_lcdui_GameMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GameMap */
};

struct Java_com_sun_midp_lcdui_ItemEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ItemEventConsumer */
};

struct Java_com_sun_midp_lcdui_LCDUIEnvironment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/LCDUIEnvironment */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
};

struct Java_com_sun_midp_lcdui_LCDUIEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/LCDUIEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_ItemEventConsumer * JVM_FIELD_CONST itemEventConsumer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_PhoneDial {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/PhoneDial */
};

struct Java_com_sun_midp_lcdui_RepaintEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/RepaintEvent */
    /* @12 */	jint paintX1;
    /* @16 */	jint paintY1;
    /* @20 */	jint paintX2;
    /* @24 */	jint paintY2;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST paintTarget;
    /* @32 */	jint perUseID;
    /* @36 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
};

struct Java_com_sun_midp_lcdui_SystemAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad424;
    /* @31 */	jbyte ___pad425;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* com/sun/midp/lcdui/SystemAlert */
    /* @72 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @76 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /* @80 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST explicitListener;
    /* @84 */	struct Java_java_lang_Object * JVM_FIELD_CONST listenerLock;
    /* @88 */	jboolean shown;
    /* @89 */	jbyte ___pad426;
    /* @90 */	jbyte ___pad427;
    /* @91 */	jbyte ___pad428;
};

struct Java_com_sun_midp_lcdui_TextCursor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextCursor */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jint index;
    /* @24 */	jint option;
    /* @28 */	jint preferredX;
    /* @32 */	jint yOffset;
    /* @36 */	jboolean visible;
    /* @37 */	jbyte ___pad429;
    /* @38 */	jbyte ___pad430;
    /* @39 */	jbyte ___pad431;
};

struct Java_com_sun_midp_lcdui_TextInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextInfo */
    /*  @4 */	jint numLines;
    /*  @8 */	jint visLines;
    /* @12 */	jint topVis;
    /* @16 */	jint cursorLine;
    /* @20 */	jint_array * JVM_FIELD_CONST lineStart;
    /* @24 */	jint_array * JVM_FIELD_CONST lineEnd;
    /* @28 */	jint height;
    /* @32 */	jint selectionStart;
    /* @36 */	jint selectionLength;
    /* @40 */	jboolean isModified;
    /* @41 */	jboolean scrollY;
    /* @42 */	jboolean scrollX;
    /* @43 */	jbyte ___pad432;
};

struct Java_com_sun_midp_lcdui_Text {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/Text */
};

struct Java_com_sun_midp_lcdui_TextPolicy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextPolicy */
};

struct Java_com_sun_midp_links_ClosedLinkException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/midp/links/ClosedLinkException */
};

struct Java_com_sun_midp_links_Link {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/links/Link */
    /*  @4 */	struct Java_com_sun_midp_links_Link * JVM_FIELD_CONST emptyLinkCache;
    /*  @8 */	jint nativePointer;
};

struct Java_com_sun_midp_links_LinkMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/links/LinkMessage */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST contents;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
};

struct Java_com_sun_midp_links_LinkPortal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/links/LinkPortal */
};

struct Java_com_sun_midp_links_NamedLinkPortal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/links/NamedLinkPortal */
};

struct Java_com_sun_midp_log_LogChannels {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/LogChannels */
};

struct Java_com_sun_midp_log_LoggingBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/LoggingBase */
};

struct Java_com_sun_midp_log_Logging {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/LoggingBase */
    /* com/sun/midp/log/Logging */
};

struct Java_com_sun_midp_main_AbstractMIDletSuiteLoader_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader$1 */
};

struct Java_com_sun_midp_main_AbstractMIDletSuiteLoader_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader$SecurityTrusted */
};

struct Java_com_sun_midp_midlet_MIDletSuiteExceptionListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletSuiteExceptionListener */
};

struct Java_com_sun_midp_main_AbstractMIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint suiteId;
    /* @16 */	jint externalAppId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST midletDisplayName;
    /* @28 */	jobject_array * JVM_FIELD_CONST args;
    /* @32 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @44 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @48 */	struct Java_com_sun_midp_lcdui_LCDUIEnvironment * JVM_FIELD_CONST lcduiEnvironment;
    /* @52 */	struct Java_com_sun_midp_midlet_MIDletStateHandler * JVM_FIELD_CONST midletStateHandler;
};

struct Java_com_sun_midp_main_MIDletExecuteEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletExecuteEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
};

struct Java_com_sun_midp_main_StartMIDletMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/StartMIDletMonitor */
    /*  @4 */	jint suiteId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @12 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
};

struct Java_com_sun_midp_main_AmsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AmsUtil */
};

struct Java_com_sun_midp_main_AppImageWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AppImageWriter */
};

struct Java_com_sun_midp_midlet_MIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventListener */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletStateHandler * JVM_FIELD_CONST midletStateHandler;
};

struct Java_com_sun_midp_midlet_MIDletStateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletStateListener */
};

struct Java_com_sun_midp_midlet_MIDletLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletLoader */
};

struct Java_com_sun_midp_midlet_PlatformRequest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/PlatformRequest */
};

struct Java_com_sun_midp_main_CldcMIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint suiteId;
    /* @16 */	jint externalAppId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST midletDisplayName;
    /* @28 */	jobject_array * JVM_FIELD_CONST args;
    /* @32 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @44 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @48 */	struct Java_com_sun_midp_lcdui_LCDUIEnvironment * JVM_FIELD_CONST lcduiEnvironment;
    /* @52 */	struct Java_com_sun_midp_midlet_MIDletStateHandler * JVM_FIELD_CONST midletStateHandler;
    /* com/sun/midp/main/CldcMIDletSuiteLoader */
    /* @56 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @60 */	struct Java_com_sun_midp_midlet_MIDletEventListener * JVM_FIELD_CONST midletEventListener;
    /* @64 */	struct Java_com_sun_midp_lcdui_ForegroundEventListener * JVM_FIELD_CONST foregroundEventListener;
};

struct Java_com_sun_midp_main_AppIsolateMIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint suiteId;
    /* @16 */	jint externalAppId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST midletDisplayName;
    /* @28 */	jobject_array * JVM_FIELD_CONST args;
    /* @32 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @44 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @48 */	struct Java_com_sun_midp_lcdui_LCDUIEnvironment * JVM_FIELD_CONST lcduiEnvironment;
    /* @52 */	struct Java_com_sun_midp_midlet_MIDletStateHandler * JVM_FIELD_CONST midletStateHandler;
    /* com/sun/midp/main/CldcMIDletSuiteLoader */
    /* @56 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @60 */	struct Java_com_sun_midp_midlet_MIDletEventListener * JVM_FIELD_CONST midletEventListener;
    /* @64 */	struct Java_com_sun_midp_lcdui_ForegroundEventListener * JVM_FIELD_CONST foregroundEventListener;
    /* com/sun/midp/main/AppIsolateMIDletSuiteLoader */
    /* @68 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST currentIsolate;
    /* @72 */	struct Java_com_sun_midp_main_MIDletExecuteEventProducer * JVM_FIELD_CONST midletExecuteEventProducer;
};

struct Java_com_sun_midp_main_CldcAccessControlContext {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2me/security/AccessControlContextAdapter */
    /* com/sun/midp/main/CldcAccessControlContext */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
};

struct Java_com_sun_midp_main_CldcForegroundController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CldcForegroundController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
};

struct Java_com_sun_midp_main_HeadlessAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad433;
    /* @31 */	jbyte ___pad434;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* com/sun/midp/main/HeadlessAlert */
    /* @72 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @76 */	jint displayId;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backgroundCommand;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCommand;
};

struct Java_com_sun_midp_main_CldcMIDletLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CldcMIDletLoader */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST classSecurityToken;
};

struct Java_com_sun_midp_suspend_SuspendSystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST subsystems;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST dependencies;
    /* com/sun/midp/suspend/SuspendSystem */
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
};

struct Java_com_sun_midp_main_CldcMIDletStateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CldcMIDletStateListener */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST classSecurityToken;
    /*  @8 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @12 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @16 */	jboolean vmInMidletStartMode;
    /* @17 */	jboolean previouslyActive;
    /* @18 */	jbyte ___pad435;
    /* @19 */	jbyte ___pad436;
};

struct Java_com_sun_midp_main_CldcPlatformRequest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CldcPlatformRequest */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST securityToken;
};

struct Java_com_sun_midp_main_RuntimeInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/RuntimeInfo */
    /*  @4 */	jint memoryReserved;
    /*  @8 */	jint memoryTotal;
    /* @12 */	jint usedMemory;
    /* @16 */	jint priority;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST profileName;
};

struct Java_com_sun_midp_main_CommandState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CommandState */
    /*  @4 */	jint status;
    /*  @8 */	jint suiteId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @16 */	jint lastSuiteId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST lastArg0;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST lastArg1;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @44 */	struct Java_com_sun_midp_main_RuntimeInfo * JVM_FIELD_CONST runtimeInfo;
    /* @48 */	jboolean logoDisplayed;
    /* @49 */	jbyte ___pad437;
    /* @50 */	jbyte ___pad438;
    /* @51 */	jbyte ___pad439;
};

struct Java_com_sun_midp_main_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/Configuration */
};

struct Java_com_sun_midp_main_ExecuteMIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/ExecuteMIDletEventListener */
    /*  @4 */	jint externalAppId;
    /*  @8 */	jint id;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
};

struct Java_com_sun_midp_main_IndicatorManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IndicatorManager */
};

struct Java_com_sun_midp_main_IsolateMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitor */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST isolates;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
};

struct Java_com_sun_midp_main_IsolateMonitorListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitorListener */
};

struct Java_com_sun_midp_main_TerminationNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TerminationNotifier */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST midlet;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
    /* @12 */	struct Java_com_sun_midp_main_IsolateMonitor * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_main_IsolateUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateUtil */
};

struct Java_com_sun_midp_main_MIDletAppImageGenerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGenerator */
};

struct Java_com_sun_midp_main_MIDletAppImageGeneratorBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGeneratorBase */
};

struct Java_com_sun_midp_main_MIDletControllerEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventConsumer */
};

struct Java_com_sun_midp_main_MIDletControllerEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventListener */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletControllerEventConsumer * JVM_FIELD_CONST midletControllerEventConsumer;
};

struct Java_com_sun_midp_main_MIDletDestroyTimer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/main/MIDletDestroyTimer$1 */
    /* @28 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST val_044mp;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST val_044mpl;
};

struct Java_com_sun_midp_main_MIDletDestroyTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletDestroyTimer */
};

struct Java_com_sun_midp_midlet_MIDletEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_suspend_SuspendDependency {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/SuspendDependency */
};

struct Java_com_sun_midp_main_MIDletProxyList_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyList$1 */
};

struct Java_com_sun_midp_main_MIDletProxyList_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyList$SecurityTrusted */
};

struct Java_com_sun_midp_suspend_SuspendSystemListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/SuspendSystemListener */
};

struct Java_com_sun_midp_main_MIDletProxyUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyUtils */
};

struct Java_com_sun_midp_main_MIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AbstractMIDletSuiteLoader */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint suiteId;
    /* @16 */	jint externalAppId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST midletDisplayName;
    /* @28 */	jobject_array * JVM_FIELD_CONST args;
    /* @32 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @44 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @48 */	struct Java_com_sun_midp_lcdui_LCDUIEnvironment * JVM_FIELD_CONST lcduiEnvironment;
    /* @52 */	struct Java_com_sun_midp_midlet_MIDletStateHandler * JVM_FIELD_CONST midletStateHandler;
    /* com/sun/midp/main/CldcMIDletSuiteLoader */
    /* @56 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @60 */	struct Java_com_sun_midp_midlet_MIDletEventListener * JVM_FIELD_CONST midletEventListener;
    /* @64 */	struct Java_com_sun_midp_lcdui_ForegroundEventListener * JVM_FIELD_CONST foregroundEventListener;
    /* com/sun/midp/main/MIDletSuiteLoader */
    /* @68 */	struct Java_com_sun_midp_main_CommandState * JVM_FIELD_CONST state;
    /* @72 */	jint disableAlerts;
    /* @76 */	struct Java_com_sun_midp_midlet_MIDletEventProducer * JVM_FIELD_CONST midletEventProducer;
    /* @80 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_main_MIDletSuiteUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteUtils */
};

struct Java_com_sun_midp_main_MIDletSuiteVerifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteVerifier */
};

struct Java_com_sun_midp_main_TrustedMIDletIcon_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TrustedMIDletIcon$1 */
};

struct Java_com_sun_midp_main_TrustedMIDletIcon_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TrustedMIDletIcon$SecurityTrusted */
};

struct Java_com_sun_midp_main_TrustedMIDletIcon {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TrustedMIDletIcon */
};

struct Java_com_sun_midp_midlet_MIDletEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventConsumer */
};

struct Java_javax_microedition_midlet_MIDletStateChangeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/midlet/MIDletStateChangeException */
};

struct Java_com_sun_midp_payment_PAPICleanUp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/payment/PAPICleanUp */
};

struct Java_com_sun_midp_pki_SubjectAlternativeName {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/SubjectAlternativeName */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST subjAltName;
    /*  @8 */	jbyte subjAltNameType;
    /* @9 */	jbyte ___pad440;
    /* @10 */	jbyte ___pad441;
    /* @11 */	jbyte ___pad442;
};

struct Java_com_sun_midp_pki_Utils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/Utils */
};

struct Java_com_sun_midp_publickeystore_Storage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
};

struct Java_com_sun_midp_publickeystore_OutputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/OutputStorage */
    /*  @4 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStoreBuilderBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST __dup1__keyList;
    /* com/sun/midp/publickeystore/PublicKeyStoreBuilderBase */
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_publickeystore_WebPublicKeyStore_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/WebPublicKeyStore$SecurityTrusted */
};

struct Java_com_sun_midp_rms_AbstractRecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreFile */
};

struct Java_com_sun_midp_rms_AbstractRecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreImpl */
};

struct Java_com_sun_midp_rms_IntToIntMapper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
};

struct Java_com_sun_midp_rms_OffsetCache {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
    /* com/sun/midp/rms/OffsetCache */
    /* @24 */	jint LastSeenOffset;
};

struct Java_com_sun_midp_rms_RMSConfig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RMSConfig */
};

struct Java_com_sun_midp_rms_RecordStoreFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFactory */
};

struct Java_com_sun_midp_rms_RecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFile */
    /*  @4 */	jint handle;
};

struct Java_com_sun_midp_rms_RecordStoreIndex {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreIndex */
    /*  @4 */	struct Java_com_sun_midp_rms_AbstractRecordStoreImpl * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_com_sun_midp_rms_AbstractRecordStoreFile * JVM_FIELD_CONST dbFile;
    /* @12 */	struct Java_com_sun_midp_rms_OffsetCache * JVM_FIELD_CONST recordIdOffsets;
};

struct Java_javax_microedition_rms_RecordStoreFullException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreFullException */
};

struct Java_com_sun_midp_rms_RecordStoreUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreUtil */
};

struct Java_com_sun_midp_scriptutil_CommandLineInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/scriptutil/CommandLineInstaller */
};

struct Java_com_sun_midp_scriptutil_HttpJadInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/scriptutil/HttpJadInstaller */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_com_sun_midp_installer_HttpInstaller * JVM_FIELD_CONST installer;
};

struct Java_com_sun_midp_scriptutil_SuiteLister {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/scriptutil/SuiteLister */
};

struct Java_com_sun_midp_scriptutil_SuiteRemover {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/scriptutil/SuiteRemover */
    /*  @8 */	jint suiteId;
};

struct Java_com_sun_midp_security_PermissionDialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionDialog */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /*  @8 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST yesCmd;
    /* @16 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST noCmd;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @24 */	jboolean answer;
    /* @25 */	jbyte ___pad443;
    /* @26 */	jbyte ___pad444;
    /* @27 */	jbyte ___pad445;
};

struct Java_com_sun_midp_security_PermissionSpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionSpec */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_com_sun_midp_security_PermissionGroup * JVM_FIELD_CONST group;
};

struct Java_com_sun_midp_security_Permissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/Permissions */
};

struct Java_com_sun_midp_security_PermissionsTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionsTable */
};

struct Java_com_sun_midp_security_SecurityInitializerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityInitializerImpl */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST internalSecurityToken;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST trustedClasses;
};

struct Java_com_sun_midp_security_SecurityInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityInitializer */
};

struct Java_com_sun_midp_services_SystemService {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemService */
};

struct Java_com_sun_midp_services_SystemServiceConnectionLinks {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceConnectionLinks */
    /*  @4 */	struct Java_com_sun_midp_links_Link * JVM_FIELD_CONST send;
    /*  @8 */	struct Java_com_sun_midp_links_Link * JVM_FIELD_CONST receive;
};

struct Java_com_sun_midp_services_SystemServiceManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceManager */
};

struct Java_com_sun_midp_services_SystemServiceRequestProtocolAMS {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestProtocolAMS */
    /*  @4 */	struct Java_com_sun_midp_services_SystemServiceRequestListener * JVM_FIELD_CONST requestListener;
    /*  @8 */	jint state;
};

struct Java_com_sun_midp_services_SystemServiceRequestListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestListener */
};

struct Java_com_sun_midp_services_SystemServiceConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceConnection */
};

struct Java_com_sun_midp_services_IsolateSystemServiceRequestHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/IsolateSystemServiceRequestHandler */
    /*  @4 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST serviceIsolate;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST clientIsolate;
    /* @12 */	struct Java_com_sun_midp_services_SystemServiceManager * JVM_FIELD_CONST serviceManager;
    /* @16 */	struct Java_com_sun_midp_services_SystemService * JVM_FIELD_CONST requestedService;
    /* @20 */	struct Java_com_sun_midp_services_SystemServiceConnectionLinks * JVM_FIELD_CONST sendReceiveLinks;
    /* @24 */	struct Java_com_sun_midp_services_SystemServiceRequestProtocolAMS * JVM_FIELD_CONST serviceRequestProtocol;
};

struct Java_com_sun_midp_services_SystemServiceConnectionListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceConnectionListener */
};

struct Java_com_sun_midp_services_SystemServiceConnectionImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceConnectionImpl */
    /*  @4 */	struct Java_com_sun_midp_services_SystemServiceConnectionLinks * JVM_FIELD_CONST connectionLinks;
    /*  @8 */	struct Java_com_sun_midp_services_SystemServiceConnectionListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_services_SystemServiceMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceMessage */
};

struct Java_com_sun_midp_services_SystemServiceConnectionClosedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/services/SystemServiceConnectionClosedException */
};

struct Java_com_sun_midp_services_SystemServiceConnectionImpl_00024ListenerThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/services/SystemServiceConnectionImpl$ListenerThread */
    /* @28 */	struct Java_com_sun_midp_services_SystemServiceConnectionImpl * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_services_SystemServiceReadMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceMessage */
    /* com/sun/midp/services/SystemServiceReadMessage */
    /*  @4 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST dataStream;
};

struct Java_com_sun_midp_services_SystemServiceManagerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceManager */
    /* com/sun/midp/services/SystemServiceManagerImpl */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST serviceEntries;
};

struct Java_com_sun_midp_services_SystemServiceManagerImpl_00024SystemServiceEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceManagerImpl$SystemServiceEntry */
    /*  @4 */	struct Java_com_sun_midp_services_SystemService * JVM_FIELD_CONST service;
    /*  @8 */	struct Java_com_sun_midp_services_SystemServiceManagerImpl * JVM_FIELD_CONST this_0440;
    /* @12 */	jboolean isStarted;
    /* @13 */	jbyte ___pad446;
    /* @14 */	jbyte ___pad447;
    /* @15 */	jbyte ___pad448;
};

struct Java_com_sun_midp_services_SystemServiceWriteMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceMessage */
    /* com/sun/midp/services/SystemServiceWriteMessage */
    /*  @4 */	struct Java_java_io_ByteArrayOutputStream * JVM_FIELD_CONST byteStream;
    /*  @8 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST dataStream;
};

struct Java_com_sun_midp_services_SystemServiceRequestHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestHandler */
    /*  @4 */	struct Java_com_sun_midp_services_SystemServiceManager * JVM_FIELD_CONST serviceManager;
};

struct Java_com_sun_midp_services_SystemServiceRequestHandler_00024IsolateRequestHandlerThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/services/SystemServiceRequestHandler$IsolateRequestHandlerThread */
    /* @28 */	struct Java_com_sun_midp_services_IsolateSystemServiceRequestHandler * JVM_FIELD_CONST requestHandler;
    /* @32 */	struct Java_com_sun_midp_services_SystemServiceRequestHandler * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_services_SystemServiceRequestProtocolClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestProtocolClient */
    /*  @4 */	struct Java_com_sun_midp_links_LinkMessage * JVM_FIELD_CONST startSessionMsg;
    /*  @8 */	struct Java_com_sun_midp_links_LinkMessage * JVM_FIELD_CONST endSessionMsg;
    /* @12 */	struct Java_com_sun_midp_links_LinkMessage * JVM_FIELD_CONST linksReceivedMsg;
    /* @16 */	struct Java_com_sun_midp_services_SystemServiceConnectionLinks * JVM_FIELD_CONST sendReceiveLinks;
    /* @20 */	struct Java_com_sun_midp_services_SystemServiceConnectionLinks * JVM_FIELD_CONST connectionLinks;
    /* @24 */	jint state;
};

struct Java_com_sun_midp_services_SystemServiceRequestor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestor */
};

struct Java_com_sun_midp_services_SystemServiceRequestorRemote {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestor */
    /* com/sun/midp/services/SystemServiceRequestorRemote */
    /*  @4 */	struct Java_com_sun_midp_services_SystemServiceConnectionLinks * JVM_FIELD_CONST sendReceiveLinks;
    /*  @8 */	struct Java_com_sun_midp_services_SystemServiceRequestProtocolClient * JVM_FIELD_CONST requestProtocol;
};

struct Java_com_sun_midp_services_SystemServiceRequestorLocal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/services/SystemServiceRequestor */
    /* com/sun/midp/services/SystemServiceRequestorLocal */
    /*  @4 */	struct Java_com_sun_midp_services_SystemServiceManager * JVM_FIELD_CONST serviceManager;
};

struct Java_com_sun_midp_ssl_CipherSuiteData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/CipherSuiteData */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST clientMACSecret;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST serverMACSecret;
    /* @12 */	jbyte_array * JVM_FIELD_CONST clientKey;
    /* @16 */	jbyte_array * JVM_FIELD_CONST serverKey;
    /* @20 */	jbyte_array * JVM_FIELD_CONST clientIV;
    /* @24 */	jbyte_array * JVM_FIELD_CONST serverIV;
    /* @28 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST clientBulkKey;
    /* @32 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST serverBulkKey;
    /* @36 */	jint digestLength;
    /* @40 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST encodeDigest;
    /* @44 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST decodeDigest;
    /* @48 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST encodeCipher;
    /* @52 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST decodeCipher;
    /* @56 */	jint padLength;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST sd;
    /* @68 */	jbyte_array * JVM_FIELD_CONST keyBlock;
    /* @72 */	jbyte suiteType;
    /* @73 */	jbyte ___pad449;
    /* @74 */	jbyte ___pad450;
    /* @75 */	jbyte ___pad451;
};

struct Java_com_sun_midp_ssl_Session {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Session */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /*  @8 */	jint port;
    /* @12 */	jbyte_array * JVM_FIELD_CONST id;
    /* @16 */	jbyte_array * JVM_FIELD_CONST master;
    /* @20 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cert;
};

struct Java_com_sun_midp_ssl_Handshake {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Handshake */
    /*  @4 */	struct Java_com_sun_midp_pki_CertStore * JVM_FIELD_CONST certStore;
    /*  @8 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST peerHost;
    /* @16 */	jint peerPort;
    /* @20 */	struct Java_com_sun_midp_crypto_SecureRandom * JVM_FIELD_CONST rnd;
    /* @24 */	struct Java_com_sun_midp_ssl_Session * JVM_FIELD_CONST cSession;
    /* @28 */	jbyte_array * JVM_FIELD_CONST sSessionId;
    /* @32 */	jbyte_array * JVM_FIELD_CONST crand;
    /* @36 */	jbyte_array * JVM_FIELD_CONST srand;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST negSuiteName;
    /* @44 */	jbyte_array * JVM_FIELD_CONST preMaster;
    /* @48 */	jbyte_array * JVM_FIELD_CONST master;
    /* @52 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST eKey;
    /* @56 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST sCert;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourMD5;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourSHA;
    /* @68 */	jint start;
    /* @72 */	jint nextMsgStart;
    /* @76 */	jint cnt;
    /* @80 */	jbyte ver;
    /* @81 */	jbyte role;
    /* @82 */	jbyte negSuite;
    /* @83 */	jbyte gotCertReq;
};

struct Java_com_sun_midp_ssl_MAC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
};

struct Java_com_sun_midp_ssl_RecordDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordDecoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_RecordEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordEncoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_SSLSecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLSecurityInfo */
    /*  @4 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_suspend_AbstractSubsystem_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem$1 */
};

struct Java_com_sun_midp_suspend_AbstractSubsystem_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem$SecurityTrusted */
};

struct Java_com_sun_midp_suspend_AbstractSubsystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST subsystems;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST dependencies;
};

struct Java_com_sun_midp_suspend_AlertTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Timer */
    /*  @4 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /*  @8 */	struct Java_java_util_TimerThread * JVM_FIELD_CONST thread;
    /* com/sun/midp/suspend/AlertTimer */
};

struct Java_com_sun_midp_suspend_AlertTimer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/suspend/AlertTimer$1 */
    /* @28 */	struct Java_com_sun_midp_suspend_AlertTimer * JVM_FIELD_CONST val_044timer;
};

struct Java_java_util_TaskQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TaskQueue */
    /*  @4 */	jobject_array * JVM_FIELD_CONST queue;
    /*  @8 */	jint size;
    /* @12 */	jboolean newTasksMayBeScheduled;
    /* @13 */	jbyte ___pad452;
    /* @14 */	jbyte ___pad453;
    /* @15 */	jbyte ___pad454;
};

struct Java_java_util_TimerThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* java/util/TimerThread */
    /* @28 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
};

struct Java_com_sun_midp_suspend_StateTransitionException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* com/sun/midp/suspend/StateTransitionException */
};

struct Java_com_sun_midp_suspend_SuspendResumeUI_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/SuspendResumeUI$1 */
};

struct Java_com_sun_midp_suspend_SuspendResumeUI {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/SuspendResumeUI */
};

struct Java_com_sun_midp_suspend_SuspendSystem_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/SuspendSystem$1 */
};

struct Java_com_sun_midp_suspend_SuspendSystem_00024MIDPSystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/suspend/AbstractSubsystem */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST subsystems;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST dependencies;
    /* com/sun/midp/suspend/SuspendSystem */
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* com/sun/midp/suspend/SuspendSystem$MIDPSystem */
    /* @24 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastForeground;
    /* @28 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST mpl;
    /* @32 */	jboolean midletKilled;
    /* @33 */	jboolean midletPaused;
    /* @34 */	jbyte ___pad455;
    /* @35 */	jbyte ___pad456;
};

struct Java_com_sun_midp_suspend_SuspendTimer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/suspend/SuspendTimer$1 */
    /* @28 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST val_044midletList;
};

struct Java_com_sun_midp_suspend_SuspendTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Timer */
    /*  @4 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /*  @8 */	struct Java_java_util_TimerThread * JVM_FIELD_CONST thread;
    /* com/sun/midp/suspend/SuspendTimer */
};

struct Java_com_sun_midp_util_DateParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/DateParser */
    /*  @4 */	jint year;
    /*  @8 */	jint month;
    /* @12 */	jint day;
    /* @16 */	jint hour;
    /* @20 */	jint minute;
    /* @24 */	jint second;
    /* @28 */	jint milli;
    /* @32 */	jint tzoffset;
    /* @36 */	jint_array * JVM_FIELD_CONST days_in_month;
    /* @40 */	jobject_array * JVM_FIELD_CONST month_shorts;
    /* @44 */	jobject_array * JVM_FIELD_CONST weekday_shorts;
};

struct Java_com_sun_midp_util_ResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/ResourceHandler */
};

struct Java_com_sun_midp_wma_WMACleanupMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/wma/WMACleanupMonitor */
};

struct Java_com_sun_mmedia_BasicPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad457;
    /* @115 */	jbyte ___pad458;
};

struct Java_javax_microedition_media_control_VolumeControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/VolumeControl */
};

struct Java_com_sun_mmedia_AudioRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/AudioRenderer */
    /*  @4 */	jint level;
    /*  @8 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @12 */	jboolean muted;
    /* @13 */	jbyte ___pad459;
    /* @14 */	jbyte ___pad460;
    /* @15 */	jbyte ___pad461;
};

struct Java_com_sun_mmedia_BasicAudioOut {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicAudioOut */
};

struct Java_com_sun_mmedia_EvtQ {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/mmedia/EvtQ */
    /* @28 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST p;
    /* @32 */	jobject_array * JVM_FIELD_CONST evtQ;
    /* @36 */	jobject_array * JVM_FIELD_CONST evtDataQ;
    /* @40 */	jint head;
    /* @44 */	jint tail;
};

struct Java_javax_microedition_media_protocol_DataSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
};

struct Java_javax_microedition_media_protocol_SourceStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/SourceStream */
};

struct Java_javax_microedition_media_TimeBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/TimeBase */
};

struct Java_javax_microedition_media_control_StopTimeControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/StopTimeControl */
};

struct Java_javax_microedition_media_Controllable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Controllable */
};

struct Java_javax_microedition_media_MediaException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/media/MediaException */
};

struct Java_com_sun_mmedia_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* @20 */	jboolean needAMMS;
    /* @21 */	jbyte ___pad462;
    /* @22 */	jbyte ___pad463;
    /* @23 */	jbyte ___pad464;
};

struct Java_com_sun_mmedia_ImageAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ImageAccess */
};

struct Java_com_sun_mmedia_VideoRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VideoRenderer */
};

struct Java_com_sun_mmedia_TonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/TonePlayer */
};

struct Java_com_sun_mmedia_DefaultConfiguration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* @20 */	jboolean needAMMS;
    /* @21 */	jbyte ___pad465;
    /* @22 */	jbyte ___pad466;
    /* @23 */	jbyte ___pad467;
    /* com/sun/mmedia/DefaultConfiguration */
    /* @24 */	jboolean debug;
    /* @25 */	jbyte ___pad468;
    /* @26 */	jbyte ___pad469;
    /* @27 */	jbyte ___pad470;
};

struct Java_com_sun_mmedia_MIDPVideoRenderer_00024MMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/MMCustomItem */
    /* @56 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST fullScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @64 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST oldDisplayable;
    /* @68 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST callerVideoControl;
    /* @72 */	struct Java_com_sun_mmedia_MIDPVideoPainter * JVM_FIELD_CONST videoPainter;
    /* com/sun/mmedia/MIDPVideoRenderer$MMItem */
    /* @76 */	jint ody;
    /* @80 */	jint odh;
    /* @84 */	jint odw;
    /* @88 */	jint_array * JVM_FIELD_CONST frame;
    /* @92 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST imageLock;
    /* @100 */	struct Java_com_sun_mmedia_MIDPVideoRenderer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_MMHelper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMHelper */
};

struct Java_com_sun_mmedia_MIDPVideoRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VideoRenderer */
    /* com/sun/mmedia/MIDPVideoRenderer */
    /*  @4 */	struct Java_com_sun_mmedia_MIDPVideoRenderer_00024MMItem * JVM_FIELD_CONST mmItem;
    /*  @8 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @12 */	jint mode;
    /* @16 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @20 */	jint dx;
    /* @24 */	jint tmpdx;
    /* @28 */	jint dy;
    /* @32 */	jint tmpdy;
    /* @36 */	jint dw;
    /* @40 */	jint tmpdw;
    /* @44 */	jint dh;
    /* @48 */	jint tmpdh;
    /* @52 */	jint videoWidth;
    /* @56 */	jint videoHeight;
    /* @60 */	jbyte_array * JVM_FIELD_CONST tempSnapData;
    /* @64 */	jint frameCount;
    /* @68 */	jlong frameStartTime;
    /* @76 */	struct Java_java_lang_Object * JVM_FIELD_CONST dispBoundsLock;
    /* @80 */	jint rgbMode;
    /* @84 */	jint pWidth;
    /* @88 */	jint pHeight;
    /* @92 */	jint_array * JVM_FIELD_CONST rgbData;
    /* @96 */	jint_array * JVM_FIELD_CONST scaledRGB;
    /* @100 */	jbyte_array * JVM_FIELD_CONST pngData;
    /* @104 */	jint pngDataLength;
    /* @108 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @112 */	struct Java_com_sun_mmedia_MMHelper * JVM_FIELD_CONST mmh;
    /* @116 */	jboolean fsmode;
    /* @117 */	jboolean closed;
    /* @118 */	jboolean cvis;
    /* @119 */	jboolean pvis;
    /* @120 */	jboolean nativeRender;
    /* @121 */	jboolean useAlpha;
    /* @122 */	jbyte ___pad471;
    /* @123 */	jbyte ___pad472;
};

struct Java_javax_microedition_media_control_VideoControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/VideoControl */
};

struct Java_com_sun_mmedia_MIDPVideoPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDPVideoPainter */
};

struct Java_javax_microedition_media_control_GUIControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/GUIControl */
};

struct Java_com_sun_mmedia_NativeTonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/NativeTonePlayer */
};

struct Java_com_sun_mmedia_DirectControls {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/DirectControls */
};

struct Java_com_sun_mmedia_DirectMIDIControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/DirectMIDIControl */
    /*  @4 */	struct Java_com_sun_mmedia_DirectPlayer * JVM_FIELD_CONST _player;
    /*  @8 */	jint _cachedRate;
};

struct Java_com_sun_mmedia_DirectPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad473;
    /* @115 */	jbyte ___pad474;
    /* com/sun/mmedia/DirectPlayer */
    /* @116 */	struct Java_com_sun_mmedia_PlayerStateSubscriber * JVM_FIELD_CONST state_subscriber;
    /* @120 */	jint hNative;
    /* @124 */	jint mediaType;
    /* @128 */	jlong restartPosition;
    /* @136 */	struct Java_com_sun_mmedia_DirectVolume * JVM_FIELD_CONST vc;
    /* @140 */	jlong remained;
    /* @148 */	struct Java_java_util_Timer * JVM_FIELD_CONST stopTimer;
    /* @152 */	struct Java_com_sun_mmedia_DirectRecord * JVM_FIELD_CONST recordControl;
    /* @156 */	struct Java_com_sun_mmedia_DirectMIDIControl * JVM_FIELD_CONST midiControl;
    /* @160 */	jint mvmOption;
    /* @164 */	jboolean needBuffering;
    /* @165 */	jboolean isStreaming;
    /* @166 */	jboolean isFirstStart;
    /* @167 */	jbyte ___pad475;
};

struct Java_com_sun_mmedia_MediaTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MediaTunnel */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST map;
    /*  @8 */	jboolean hasForeground;
    /* @9 */	jbyte ___pad476;
    /* @10 */	jbyte ___pad477;
    /* @11 */	jbyte ___pad478;
};

struct Java_com_sun_mmedia_DirectRecord {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/DirectRecord */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /*  @8 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST stream;
    /* @12 */	struct Java_com_sun_mmedia_DirectPlayer * JVM_FIELD_CONST player;
    /* @16 */	jbyte_array * JVM_FIELD_CONST dataBuffer;
    /* @20 */	struct Java_javax_microedition_io_file_FileConnection * JVM_FIELD_CONST fileCon;
    /* @24 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpCon;
    /* @28 */	jboolean suspended;
    /* @29 */	jboolean recordRequested;
    /* @30 */	jboolean recording;
    /* @31 */	jboolean recordingByNative;
    /* @32 */	jboolean extStream;
    /* @33 */	jboolean hasDataToCommit;
    /* @34 */	jbyte ___pad479;
    /* @35 */	jbyte ___pad480;
};

struct Java_com_sun_mmedia_PlayerStateSubscriber {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/PlayerStateSubscriber */
};

struct Java_com_sun_mmedia_DirectVolume {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/DirectVolume */
    /*  @4 */	jint _level;
    /*  @8 */	jint _mute;
    /* @12 */	jint _hNative;
    /* @16 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST _player;
};

struct Java_com_sun_mmedia_MediaEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MediaEventConsumer */
};

struct Java_com_sun_mmedia_DirectMIDI {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad481;
    /* @115 */	jbyte ___pad482;
    /* com/sun/mmedia/DirectPlayer */
    /* @116 */	struct Java_com_sun_mmedia_PlayerStateSubscriber * JVM_FIELD_CONST state_subscriber;
    /* @120 */	jint hNative;
    /* @124 */	jint mediaType;
    /* @128 */	jlong restartPosition;
    /* @136 */	struct Java_com_sun_mmedia_DirectVolume * JVM_FIELD_CONST vc;
    /* @140 */	jlong remained;
    /* @148 */	struct Java_java_util_Timer * JVM_FIELD_CONST stopTimer;
    /* @152 */	struct Java_com_sun_mmedia_DirectRecord * JVM_FIELD_CONST recordControl;
    /* @156 */	struct Java_com_sun_mmedia_DirectMIDIControl * JVM_FIELD_CONST midiControl;
    /* @160 */	jint mvmOption;
    /* @164 */	jboolean needBuffering;
    /* @165 */	jboolean isStreaming;
    /* @166 */	jboolean isFirstStart;
    /* @167 */	jbyte ___pad483;
    /* com/sun/mmedia/DirectMIDI */
    /* @168 */	struct Java_com_sun_mmedia_DirectMIDIControl * JVM_FIELD_CONST midiCtrl;
};

struct Java_javax_microedition_media_control_RateControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/RateControl */
};

struct Java_javax_microedition_media_control_TempoControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/TempoControl */
};

struct Java_javax_microedition_media_control_PitchControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/PitchControl */
};

struct Java_javax_microedition_media_control_MIDIControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/MIDIControl */
};

struct Java_com_sun_mmedia_DirectPlayer_00024StopTimeController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/mmedia/DirectPlayer$StopTimeController */
    /* @28 */	struct Java_com_sun_mmedia_DirectPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_media_control_RecordControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/RecordControl */
};

struct Java_javax_microedition_media_control_ToneControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/ToneControl */
};

struct Java_com_sun_mmedia_DirectTone {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad484;
    /* @115 */	jbyte ___pad485;
    /* com/sun/mmedia/DirectPlayer */
    /* @116 */	struct Java_com_sun_mmedia_PlayerStateSubscriber * JVM_FIELD_CONST state_subscriber;
    /* @120 */	jint hNative;
    /* @124 */	jint mediaType;
    /* @128 */	jlong restartPosition;
    /* @136 */	struct Java_com_sun_mmedia_DirectVolume * JVM_FIELD_CONST vc;
    /* @140 */	jlong remained;
    /* @148 */	struct Java_java_util_Timer * JVM_FIELD_CONST stopTimer;
    /* @152 */	struct Java_com_sun_mmedia_DirectRecord * JVM_FIELD_CONST recordControl;
    /* @156 */	struct Java_com_sun_mmedia_DirectMIDIControl * JVM_FIELD_CONST midiControl;
    /* @160 */	jint mvmOption;
    /* @164 */	jboolean needBuffering;
    /* @165 */	jboolean isStreaming;
    /* @166 */	jboolean isFirstStart;
    /* @167 */	jbyte ___pad486;
    /* com/sun/mmedia/DirectTone */
};

struct Java_com_sun_mmedia_DirectVideo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad487;
    /* @115 */	jbyte ___pad488;
    /* com/sun/mmedia/DirectPlayer */
    /* @116 */	struct Java_com_sun_mmedia_PlayerStateSubscriber * JVM_FIELD_CONST state_subscriber;
    /* @120 */	jint hNative;
    /* @124 */	jint mediaType;
    /* @128 */	jlong restartPosition;
    /* @136 */	struct Java_com_sun_mmedia_DirectVolume * JVM_FIELD_CONST vc;
    /* @140 */	jlong remained;
    /* @148 */	struct Java_java_util_Timer * JVM_FIELD_CONST stopTimer;
    /* @152 */	struct Java_com_sun_mmedia_DirectRecord * JVM_FIELD_CONST recordControl;
    /* @156 */	struct Java_com_sun_mmedia_DirectMIDIControl * JVM_FIELD_CONST midiControl;
    /* @160 */	jint mvmOption;
    /* @164 */	jboolean needBuffering;
    /* @165 */	jboolean isStreaming;
    /* @166 */	jboolean isFirstStart;
    /* @167 */	jbyte ___pad489;
    /* com/sun/mmedia/DirectVideo */
    /* @168 */	jint SCREEN_WIDTH;
    /* @172 */	jint SCREEN_HEIGHT;
    /* @176 */	jint DEFAULT_WIDTH;
    /* @180 */	jint DEFAULT_HEIGHT;
    /* @184 */	jint ALPHA_COLOR;
    /* @188 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @192 */	struct Java_com_sun_mmedia_DirectVideo_00024DVItem * JVM_FIELD_CONST item;
    /* @196 */	jint sw;
    /* @200 */	jint sh;
    /* @204 */	jint dx;
    /* @208 */	jint dy;
    /* @212 */	jint dw;
    /* @216 */	jint dh;
    /* @220 */	jint displayMode;
    /* @224 */	struct Java_com_sun_mmedia_MMHelper * JVM_FIELD_CONST mmh;
    /* @228 */	struct Java_java_lang_Object * JVM_FIELD_CONST boundLock;
    /* @232 */	jboolean visible;
    /* @233 */	jboolean hidden;
    /* @234 */	jboolean started;
    /* @235 */	jboolean locationInited;
};

struct Java_com_sun_mmedia_DirectVideo_00024DVItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/DirectVideo$DVItem */
    /* @56 */	struct Java_com_sun_mmedia_DirectVideo * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_DirectVideoItemImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/DirectVideoItemImpl */
};

struct Java_com_sun_mmedia_DirectVideoItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/DirectVideoItem */
    /* @56 */	struct Java_com_sun_mmedia_DirectVideoItemImpl * JVM_FIELD_CONST _impl;
};

struct Java_com_sun_mmedia_FormatConversionUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/FormatConversionUtils */
};

struct Java_com_sun_mmedia_GIFImageDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFImageDecoder */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	jint colorDepth;
    /* @16 */	jint globalColorDepth;
    /* @20 */	jint curColorDepth;
    /* @24 */	jbyte_array * JVM_FIELD_CONST globalPalette;
    /* @28 */	jbyte_array * JVM_FIELD_CONST curPalette;
    /* @32 */	jint_array * JVM_FIELD_CONST argb;
    /* @36 */	jint_array * JVM_FIELD_CONST curArgb;
    /* @40 */	jint backgroundIndex;
    /* @44 */	jint transparentColorIndex;
    /* @48 */	jint undrawFlag;
    /* @52 */	jint framePosX;
    /* @56 */	jint framePosY;
    /* @60 */	jint frameWidth;
    /* @64 */	jint frameHeight;
    /* @68 */	jshort_array * JVM_FIELD_CONST prefix;
    /* @72 */	jbyte_array * JVM_FIELD_CONST suffix;
    /* @76 */	jbyte_array * JVM_FIELD_CONST outCode;
    /* @80 */	jboolean interlace;
    /* @81 */	jbyte ___pad490;
    /* @82 */	jbyte ___pad491;
    /* @83 */	jbyte ___pad492;
};

struct Java_com_sun_mmedia_GIFPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_EvtQ * JVM_FIELD_CONST evtQ;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @36 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @40 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @44 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @48 */	jlong stopTime;
    /* @56 */	jint eventQueueSize;
    /* @60 */	jlong origin;
    /* @68 */	jlong offset;
    /* @76 */	jlong time;
    /* @84 */	jlong sysOffset;
    /* @92 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @96 */	jint NOT_SEEKABLE;
    /* @100 */	jint SEEKABLE_TO_START;
    /* @104 */	jint RANDOM_ACCESSIBLE;
    /* @108 */	jboolean EOM;
    /* @109 */	jboolean loopAfterEOM;
    /* @110 */	jboolean closedDelivered;
    /* @111 */	jboolean hasDataSource;
    /* @112 */	jboolean hasToneSequenceSet;
    /* @113 */	jboolean useSystemTime;
    /* @114 */	jbyte ___pad493;
    /* @115 */	jbyte ___pad494;
    /* com/sun/mmedia/GIFPlayer */
    /* @116 */	struct Java_com_sun_mmedia_GIFImageDecoder * JVM_FIELD_CONST imageDecoder;
    /* @120 */	jint videoWidth;
    /* @124 */	jint videoHeight;
    /* @128 */	jint_array * JVM_FIELD_CONST referenceFrame;
    /* @132 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @136 */	jlong startTime;
    /* @144 */	jlong EARLY_THRESHOLD;
    /* @152 */	jlong MIN_WAIT;
    /* @160 */	jlong ZERO_DURATION_WAIT;
    /* @168 */	struct Java_java_util_Vector * JVM_FIELD_CONST frameTimes;
    /* @172 */	jint frameCount;
    /* @176 */	jint scanFrameTime;
    /* @180 */	jlong mediaTimeOffset;
    /* @188 */	jlong displayTime;
    /* @196 */	struct Java_com_sun_mmedia_VideoRenderer * JVM_FIELD_CONST videoRenderer;
    /* @200 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST videoControl;
    /* @204 */	struct Java_com_sun_mmedia_GIFPlayer_00024FramePosCtrl * JVM_FIELD_CONST framePosControl;
    /* @208 */	struct Java_com_sun_mmedia_GIFPlayer_00024RateCtrl * JVM_FIELD_CONST rateControl;
    /* @212 */	jlong duration;
    /* @220 */	jint seekType;
    /* @224 */	jlong firstFramePos;
    /* @232 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @236 */	jbyte_array * JVM_FIELD_CONST imageData;
    /* @240 */	jint imageDataLength;
    /* @244 */	jint lzwCodeSize;
    /* @248 */	jbyte_array * JVM_FIELD_CONST oneByte;
    /* @252 */	jboolean done;
    /* @253 */	jboolean stopped;
    /* @254 */	jbyte ___pad495;
    /* @255 */	jbyte ___pad496;
};

struct Java_com_sun_mmedia_GIFPlayer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$1 */
    /*  @4 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_GIFPlayer_00024RateCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$RateCtrl */
    /*  @4 */	jint rate;
    /*  @8 */	jint MIN_PLAYBACK_RATE;
    /* @12 */	jint MAX_PLAYBACK_RATE;
    /* @16 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_media_control_FramePositioningControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/FramePositioningControl */
};

struct Java_com_sun_mmedia_GIFPlayer_00024FramePosCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$FramePosCtrl */
    /*  @4 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
    /*  @8 */	jboolean active;
    /* @9 */	jbyte ___pad497;
    /* @10 */	jbyte ___pad498;
    /* @11 */	jbyte ___pad499;
};

struct Java_com_sun_mmedia_MIDPImageAccessor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDPImageAccessor */
};

struct Java_com_sun_mmedia_MMCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/MMCustomItem */
    /* @56 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST fullScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @64 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST oldDisplayable;
    /* @68 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST callerVideoControl;
    /* @72 */	struct Java_com_sun_mmedia_MIDPVideoPainter * JVM_FIELD_CONST videoPainter;
};

struct Java_com_sun_mmedia_MMCustomItem_00024FullScreenCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad500;
    /* @31 */	jbyte ___pad501;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad502;
    /* @38 */	jbyte ___pad503;
    /* @39 */	jbyte ___pad504;
    /* com/sun/mmedia/MMCustomItem$FullScreenCanvas */
    /* @40 */	struct Java_com_sun_mmedia_MMCustomItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_MMEventHandler_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventHandler$1 */
};

struct Java_com_sun_mmedia_MMEventHandler_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventHandler$SecurityTrusted */
};

struct Java_com_sun_mmedia_MMEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventHandler */
};

struct Java_com_sun_mmedia_MMEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventListener */
};

struct Java_com_sun_mmedia_MMVideoItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @52 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/MMVideoItem */
    /* @56 */	struct Java_com_sun_mmedia_MMVideoItemImpl * JVM_FIELD_CONST _impl;
    /* @60 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST fullScreen;
    /* @64 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @68 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST oldDisplayable;
    /* @72 */	jboolean _isFullScreen;
    /* @73 */	jbyte ___pad505;
    /* @74 */	jbyte ___pad506;
    /* @75 */	jbyte ___pad507;
};

struct Java_com_sun_mmedia_MMVideoItemImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMVideoItemImpl */
};

struct Java_com_sun_mmedia_MMVideoItem_00024FullScreenCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad508;
    /* @31 */	jbyte ___pad509;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad510;
    /* @38 */	jbyte ___pad511;
    /* @39 */	jbyte ___pad512;
    /* com/sun/mmedia/MMVideoItem$FullScreenCanvas */
    /* @40 */	struct Java_com_sun_mmedia_MMVideoItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_PermissionAccessor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/PermissionAccessor */
};

struct Java_com_sun_mmedia_protocol_BasicDS {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
    /* com/sun/mmedia/protocol/BasicDS */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @16 */	jboolean connected;
    /* @17 */	jbyte ___pad513;
    /* @18 */	jbyte ___pad514;
    /* @19 */	jbyte ___pad515;
};

struct Java_javax_microedition_media_protocol_ContentDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/ContentDescriptor */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST encoding;
};

struct Java_com_sun_mmedia_protocol_CommonDS {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
    /* com/sun/mmedia/protocol/BasicDS */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @16 */	jboolean connected;
    /* @17 */	jbyte ___pad516;
    /* @18 */	jbyte ___pad517;
    /* @19 */	jbyte ___pad518;
    /* com/sun/mmedia/protocol/CommonDS */
    /* @20 */	jlong contentLength;
    /* @28 */	struct Java_java_io_InputStream * JVM_FIELD_CONST inputStream;
    /* @32 */	jlong location;
};

struct Java_com_sun_mmedia_protocol_LocatorParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/protocol/LocatorParser */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /*  @8 */	jint index;
    /* @12 */	jint length;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
};

struct Java_com_sun_perseus_model_FontFace {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad519;
    /* @30 */	jbyte ___pad520;
    /* @31 */	jbyte ___pad521;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad522;
    /* @71 */	jbyte ___pad523;
    /* com/sun/perseus/model/FontFace */
    /* @72 */	jobject_array * JVM_FIELD_CONST fontFamilies;
    /* @76 */	jint fontStyles;
    /* @80 */	jint fontWeights;
    /* @84 */	jfloat_array * JVM_FIELD_CONST fontSizes;
    /* @88 */	jfloat unitsPerEm;
    /* @92 */	struct Java_com_sun_perseus_model_Font * JVM_FIELD_CONST font;
    /* @96 */	jfloat emSquareScale;
};

struct Java_com_sun_perseus_model_ModelNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad524;
    /* @30 */	jbyte ___pad525;
    /* @31 */	jbyte ___pad526;
};

struct Java_com_sun_perseus_model_DocumentNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad527;
    /* @30 */	jbyte ___pad528;
    /* @31 */	jbyte ___pad529;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/Viewport */
    /* @40 */	jint width;
    /* @44 */	jint height;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @56 */	jint zoomAndPan;
    /* com/sun/perseus/model/DocumentNode */
    /* @60 */	jfloat pxMMSize;
    /* @64 */	jfloat_array * JVM_FIELD_CONST upt;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST namespaceMap;
    /* @72 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST unknownTraitsNS;
    /* @76 */	struct Java_com_sun_perseus_parser_ClockParser * JVM_FIELD_CONST clockParser;
    /* @80 */	struct Java_com_sun_perseus_parser_LengthParser * JVM_FIELD_CONST lengthParser;
    /* @84 */	struct Java_com_sun_perseus_parser_TimeConditionParser * JVM_FIELD_CONST timeConditionParser;
    /* @88 */	struct Java_com_sun_perseus_parser_NumberListParser * JVM_FIELD_CONST numberListParser;
    /* @92 */	struct Java_com_sun_perseus_parser_TransformListParser * JVM_FIELD_CONST transformListParser;
    /* @96 */	struct Java_com_sun_perseus_parser_ColorParser * JVM_FIELD_CONST colorParser;
    /* @100 */	struct Java_com_sun_perseus_parser_ViewBoxParser * JVM_FIELD_CONST viewBoxParser;
    /* @104 */	struct Java_com_sun_perseus_parser_PathParser * JVM_FIELD_CONST pathParser;
    /* @108 */	struct Java_com_sun_perseus_parser_UnicodeParser * JVM_FIELD_CONST unicodeParser;
    /* @112 */	struct Java_com_sun_perseus_model_ImageLoader * JVM_FIELD_CONST imageLoader;
    /* @116 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST defaultFontFace;
    /* @120 */	struct Java_org_w3c_dom_DOMException * JVM_FIELD_CONST delayedException;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultNamespaceURI;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST docURI;
    /* @132 */	jobject_array * JVM_FIELD_CONST initialFontFaces;
    /* @136 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST fontFaceDB;
    /* @140 */	struct Java_java_util_Vector * JVM_FIELD_CONST activeTraitAnims;
    /* @144 */	struct Java_java_util_Vector * JVM_FIELD_CONST activeMediaElements;
    /* @148 */	struct Java_com_sun_perseus_model_EventSupport * JVM_FIELD_CONST eventSupport;
    /* @152 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST updateListener;
    /* @156 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST updateQueue;
    /* @160 */	struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableHandler * JVM_FIELD_CONST runHandler;
    /* @164 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST idToElement;
    /* @168 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST reservedIds;
    /* @172 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST prefixes;
    /* @176 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST namespaces;
    /* @180 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST timeContainerRootSupport;
    /* @184 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST unresolvedIDRefs;
    /* @188 */	struct Java_java_util_Vector * JVM_FIELD_CONST animations;
    /* @192 */	struct Java_com_sun_perseus_model_ModelEvent * JVM_FIELD_CONST engineEvent;
    /* @196 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST hitChunkTxf;
    /* @200 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST bboxChunkTxf;
    /* @204 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintChunkTxf;
    /* @208 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintGlyphTxf;
    /* @212 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST bboxGlyphTxf;
    /* @216 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST hitGlyphTxf;
    /* @220 */	jboolean playing;
    /* @221 */	jbyte ___pad530;
    /* @222 */	jbyte ___pad531;
    /* @223 */	jbyte ___pad532;
};

struct Java_com_sun_perseus_model_UpdateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateListener */
};

struct Java_com_sun_perseus_builder_DefaultFontFace {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/DefaultFontFace */
};

struct Java_com_sun_perseus_model_UpdateAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateAdapter */
    /*  @4 */	struct Java_java_lang_Exception * JVM_FIELD_CONST loadingFailedException;
    /*  @8 */	jboolean loadComplete;
    /*  @9 */	jboolean loadingFailed;
    /* @10 */	jboolean loadStarting;
    /* @11 */	jbyte ___pad533;
};

struct Java_com_sun_perseus_model_ElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad534;
    /* @30 */	jbyte ___pad535;
    /* @31 */	jbyte ___pad536;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad537;
    /* @71 */	jbyte ___pad538;
};

struct Java_com_sun_perseus_model_CompositeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad539;
    /* @30 */	jbyte ___pad540;
    /* @31 */	jbyte ___pad541;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
};

struct Java_com_sun_perseus_builder_ModelBuilder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/perseus/builder/ModelBuilder */
    /*  @4 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST currentElement;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST modelRoot;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST entityStreams;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingPrefixMapping;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingPrefixMappingCache;
};

struct Java_org_w3c_dom_Element {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Element */
};

struct Java_com_sun_perseus_platform_MessagesSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/MessagesSupport */
};

struct Java_com_sun_perseus_builder_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/Messages */
};

struct Java_com_sun_perseus_builder_ModelBuilder_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$1 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_j2d_RGB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RGB */
    /*  @4 */	jint rgb;
};

struct Java_com_sun_perseus_j2d_Transform {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Transform */
    /*  @4 */	jfloat m0;
    /*  @8 */	jfloat m1;
    /* @12 */	jfloat m2;
    /* @16 */	jfloat m3;
    /* @20 */	jfloat m4;
    /* @24 */	jfloat m5;
};

struct Java_com_sun_perseus_parser_ClockParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/ClockParser */
    /* @16 */	jlong millis;
};

struct Java_com_sun_perseus_parser_ColorParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/ColorParser */
};

struct Java_org_w3c_dom_DOMException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* org/w3c/dom/DOMException */
    /* @12 */	jshort code;
    /* @13 */	jbyte ___pad542;
    /* @14 */	jbyte ___pad543;
};

struct Java_com_sun_perseus_model_ModelEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelEvent */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST type;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST target;
    /* @12 */	struct Java_org_w3c_dom_events_EventTarget * JVM_FIELD_CONST currentTarget;
    /* @16 */	struct Java_com_sun_perseus_model_Anchor * JVM_FIELD_CONST anchor;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /* @24 */	jint repeatCount;
    /* @28 */	jchar keyChar;
    /* @30 */	jboolean stopPropagation;
    /* @31 */	jbyte ___pad544;
};

struct Java_com_sun_perseus_model_EventSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/EventSupport */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST allListeners;
    /*  @8 */	jobject_array * JVM_FIELD_CONST freezeList;
};

struct Java_com_sun_perseus_model_ImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ImageLoader */
};

struct Java_com_sun_perseus_parser_LengthParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/LengthParser */
};

struct Java_com_sun_perseus_parser_NumberListParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/NumberListParser */
};

struct Java_com_sun_perseus_parser_PathParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/PathParser */
    /* @16 */	jfloat currentX;
    /* @20 */	jfloat currentY;
    /* @24 */	jfloat lastMoveToX;
    /* @28 */	jfloat lastMoveToY;
    /* @32 */	jfloat smoothQCenterX;
    /* @36 */	jfloat smoothQCenterY;
    /* @40 */	jfloat smoothCCenterX;
    /* @44 */	jfloat smoothCCenterY;
    /* @48 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST p;
};

struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$RunnableHandler */
};

struct Java_com_sun_perseus_parser_TimeConditionParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/ClockParser */
    /* @16 */	jlong millis;
    /* com/sun/perseus/parser/TimeConditionParser */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST conditions;
    /* @28 */	struct Java_com_sun_perseus_model_TimedElementNode * JVM_FIELD_CONST ten;
    /* @32 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST tes;
    /* @36 */	jboolean isBegin;
    /* @37 */	jbyte ___pad545;
    /* @38 */	jbyte ___pad546;
    /* @39 */	jbyte ___pad547;
};

struct Java_com_sun_perseus_model_TimeContainerRootSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong __dup1__lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad548;
    /* com/sun/perseus/model/TimeContainerSupport */
    /* @104 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleTime;
    /* @108 */	struct Java_java_util_Vector * JVM_FIELD_CONST timedElementChildren;
    /* com/sun/perseus/model/TimeContainerRootSupport */
    /* @112 */	jlong beginWallClockTime;
    /* @120 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastSampleTime;
    /* @124 */	jboolean seekingBack;
    /* @125 */	jbyte ___pad549;
    /* @126 */	jbyte ___pad550;
    /* @127 */	jbyte ___pad551;
};

struct Java_com_sun_perseus_parser_TransformListParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/TransformListParser */
    /* @16 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
};

struct Java_com_sun_perseus_parser_UnicodeParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/UnicodeParser */
};

struct Java_com_sun_perseus_util_RunnableQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST state;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST stateLock;
    /* @12 */	struct Java_com_sun_perseus_util_Scheduler * JVM_FIELD_CONST scheduler;
    /* @16 */	struct Java_com_sun_perseus_util_DoublyLinkedList * JVM_FIELD_CONST list;
    /* @20 */	struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableQueueHandler * JVM_FIELD_CONST queueHandler;
    /* @24 */	struct Java_java_lang_Thread * JVM_FIELD_CONST runnableQueueThread;
};

struct Java_com_sun_perseus_parser_ViewBoxParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/ViewBoxParser */
};

struct Java_com_sun_perseus_model_FontFace_00024Match {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FontFace$Match */
    /*  @4 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST fontFace;
    /*  @8 */	jint distance;
    /* @12 */	struct Java_com_sun_perseus_model_FontFace_00024Match * JVM_FIELD_CONST next;
};

struct Java_com_sun_perseus_model_Anchor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad552;
    /* @30 */	jbyte ___pad553;
    /* @31 */	jbyte ___pad554;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad555;
    /* @71 */	jbyte ___pad556;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Anchor */
    /* @140 */	struct Java_java_lang_String * JVM_FIELD_CONST href;
    /* @144 */	struct Java_java_lang_String * JVM_FIELD_CONST target;
};

struct Java_org_w3c_dom_events_EventTarget {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/EventTarget */
};

struct Java_com_sun_perseus_model_Time {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Time */
    /*  @4 */	jlong value;
};

struct Java_org_w3c_dom_svg_SVGMatrix {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGMatrix */
};

struct Java_com_sun_perseus_j2d_TextProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/TextProperties */
};

struct Java_com_sun_perseus_j2d_RenderGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
    /* @44 */	jint pack2;
    /* com/sun/perseus/j2d/PiscesRenderGraphics */
    /* @48 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintTransform;
    /* @56 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @60 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /* @64 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST imageTransform;
    /* @68 */	jint width;
    /* @72 */	jint height;
    /* @76 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST renderingTile;
    /* @80 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST primitiveTile;
    /* @84 */	jboolean needSetTransform;
    /* @85 */	jbyte ___pad557;
    /* @86 */	jbyte ___pad558;
    /* @87 */	jbyte ___pad559;
    /* com/sun/perseus/j2d/RenderGraphics */
};

struct Java_org_w3c_dom_Node {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Node */
};

struct Java_org_w3c_dom_Document {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Document */
};

struct Java_com_sun_perseus_model_Transformable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Transformable */
};

struct Java_com_sun_perseus_j2d_Box {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Box */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat y;
    /* @12 */	jfloat width;
    /* @16 */	jfloat height;
};

struct Java_org_w3c_dom_events_EventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/EventListener */
};

struct Java_com_sun_perseus_j2d_Tile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
};

struct Java_com_sun_perseus_j2d_Path {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Path */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST commands;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST data;
    /* @12 */	jint nSegments;
    /* @16 */	jint nData;
    /* @20 */	jint lastCmdIndex;
    /* @24 */	jint lastOffset;
};

struct Java_com_sun_perseus_model_Viewport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad560;
    /* @30 */	jbyte ___pad561;
    /* @31 */	jbyte ___pad562;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/Viewport */
    /* @40 */	jint width;
    /* @44 */	jint height;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @56 */	jint zoomAndPan;
};

struct Java_com_sun_perseus_model_IDRef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/IDRef */
};

struct Java_com_sun_perseus_builder_ModelBuilder_000242 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$2 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044ul;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST val_044startedNode;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_000243 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$3 */
    /*  @4 */	struct Java_com_sun_perseus_model_CompositeNode * JVM_FIELD_CONST val_044parent;
    /*  @8 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST val_044child;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_000244 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$4 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_000245 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$5 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_ElementNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad563;
    /* @30 */	jbyte ___pad564;
    /* @31 */	jbyte ___pad565;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad566;
    /* @54 */	jbyte ___pad567;
    /* @55 */	jbyte ___pad568;
};

struct Java_com_sun_perseus_model_TraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad569;
    /* @30 */	jbyte ___pad570;
    /* @31 */	jbyte ___pad571;
};

struct Java_org_w3c_dom_svg_SVGPath {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGPath */
};

struct Java_org_w3c_dom_svg_SVGRGBColor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGRGBColor */
};

struct Java_org_w3c_dom_svg_SVGRect {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGRect */
};

struct Java_com_sun_perseus_j2d_PaintServer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintServer */
};

struct Java_com_sun_perseus_j2d_PaintTarget {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintTarget */
};

struct Java_com_sun_perseus_parser_Length {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/Length */
    /*  @4 */	jint unit;
    /*  @8 */	jfloat value;
};

struct Java_org_w3c_dom_svg_SVGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGElement */
};

struct Java_com_sun_perseus_builder_ModelBuilder_000246 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$6 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044text;
    /*  @8 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044ul;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_000247 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$7 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044updateListener;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST val_044root;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST val_044fgzipIS;
};

struct Java_com_sun_perseus_builder_ModelBuilder_000248 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$8 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044updateListener;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST val_044root;
    /* @12 */	struct Java_java_lang_Exception * JVM_FIELD_CONST val_044e;
};

struct Java_com_sun_perseus_builder_SVGTinyModelFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/SVGTinyModelFactory */
};

struct Java_com_sun_perseus_j2d_GraphicsProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/GraphicsProperties */
};

struct Java_com_sun_pisces_LineSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
};

struct Java_com_sun_pisces_PathSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
};

struct Java_com_sun_perseus_j2d_HitTester {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/perseus/j2d/HitTester */
    /*  @4 */	jint windingRule;
    /*  @8 */	jint px;
    /* @12 */	jint py;
    /* @16 */	jint x0;
    /* @20 */	jint y0;
    /* @24 */	jint sx0;
    /* @28 */	jint sy0;
    /* @32 */	jint crossings;
};

struct Java_com_sun_perseus_j2d_ImageLoaderUtil_00024Base64StringStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/j2d/ImageLoaderUtil$Base64StringStream */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST str;
    /*  @8 */	jint len;
    /* @12 */	jint offset;
};

struct Java_com_sun_perseus_j2d_RasterImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RasterImage */
    /*  @4 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /*  @8 */	jint_array * JVM_FIELD_CONST argb;
};

struct Java_com_sun_perseus_j2d_ImageLoaderUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/ImageLoaderUtil */
    /*  @4 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST brokenImage;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST loadingImage;
};

struct Java_com_sun_perseus_util_Base64DecodeStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/util/Base64DecodeStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST src;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST decodeBuffer;
    /* @12 */	jbyte_array * JVM_FIELD_CONST outBuffer;
    /* @16 */	jint outOffset;
    /* @20 */	jboolean eof;
    /* @21 */	jbyte ___pad572;
    /* @22 */	jbyte ___pad573;
    /* @23 */	jbyte ___pad574;
};

struct Java_com_sun_pisces_Transform6 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Transform4 */
    /*  @4 */	jint m00;
    /*  @8 */	jint m01;
    /* @12 */	jint m10;
    /* @16 */	jint m11;
    /* com/sun/pisces/Transform6 */
    /* @20 */	jint m02;
    /* @24 */	jint m12;
};

struct Java_com_sun_perseus_j2d_PiscesRenderGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
    /* @44 */	jint pack2;
    /* com/sun/perseus/j2d/PiscesRenderGraphics */
    /* @48 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintTransform;
    /* @56 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @60 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /* @64 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST imageTransform;
    /* @68 */	jint width;
    /* @72 */	jint height;
    /* @76 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST renderingTile;
    /* @80 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST primitiveTile;
    /* @84 */	jboolean needSetTransform;
    /* @85 */	jbyte ___pad575;
    /* @86 */	jbyte ___pad576;
    /* @87 */	jbyte ___pad577;
};

struct Java_com_sun_pisces_PiscesRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/PiscesRenderer */
    /*  @4 */	jlong nativePtr;
    /* @12 */	struct Java_com_sun_pisces_AbstractSurface * JVM_FIELD_CONST surface;
    /* @16 */	struct Java_com_sun_pisces_NativeFinalizer * JVM_FIELD_CONST finalizer;
    /* @20 */	jint_array * JVM_FIELD_CONST gcm_fractions;
    /* @24 */	jint_array * JVM_FIELD_CONST gcm_rgba;
    /* @28 */	jint gcm_cycleMethod;
    /* @32 */	struct Java_com_sun_pisces_GradientColorMap * JVM_FIELD_CONST gradientColorMap;
};

struct Java_com_sun_perseus_j2d_PaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintDef */
};

struct Java_com_sun_perseus_j2d_LinearGradientPaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/LinearGradientPaintDef */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	jfloat x0;
    /* @12 */	jfloat y0;
    /* @16 */	jfloat x1;
    /* @20 */	jfloat y1;
    /* @24 */	jfloat_array * JVM_FIELD_CONST fractions;
    /* @28 */	jint_array * JVM_FIELD_CONST frac;
    /* @32 */	jint_array * JVM_FIELD_CONST rgba;
    /* @36 */	jint_array * JVM_FIELD_CONST lrgba;
    /* @40 */	jint lastPaintOpacity;
    /* @44 */	jint cycleMethod;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST gradientTransform;
    /* @52 */	jboolean isObjectBBox;
    /* @53 */	jbyte ___pad578;
    /* @54 */	jbyte ___pad579;
    /* @55 */	jbyte ___pad580;
};

struct Java_com_sun_perseus_j2d_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Messages */
};

struct Java_com_sun_pisces_Transform4 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Transform4 */
    /*  @4 */	jint m00;
    /*  @8 */	jint m01;
    /* @12 */	jint m10;
    /* @16 */	jint m11;
};

struct Java_com_sun_perseus_j2d_TileSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/perseus/j2d/TileSink */
    /*  @4 */	jint minX;
    /*  @8 */	jint minY;
    /* @12 */	jint maxX;
    /* @16 */	jint maxY;
};

struct Java_com_sun_pisces_Transformer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/Transformer */
    /*  @4 */	struct Java_com_sun_pisces_PathSink * JVM_FIELD_CONST output;
    /*  @8 */	jlong m00;
    /* @16 */	jlong m01;
    /* @24 */	jlong m02;
    /* @32 */	jlong m10;
    /* @40 */	jlong m11;
    /* @48 */	jlong m12;
    /* @56 */	jboolean scaleAndTranslate;
    /* @57 */	jbyte ___pad581;
    /* @58 */	jbyte ___pad582;
    /* @59 */	jbyte ___pad583;
};

struct Java_com_sun_perseus_j2d_PathSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PathSupport */
};

struct Java_com_sun_pisces_Stroker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/Stroker */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint lineWidth;
    /* @12 */	jint capStyle;
    /* @16 */	jint joinStyle;
    /* @20 */	jint miterLimit;
    /* @24 */	struct Java_com_sun_pisces_Transform4 * JVM_FIELD_CONST transform;
    /* @28 */	jint m00;
    /* @32 */	jint m01;
    /* @36 */	jint m10;
    /* @40 */	jint m11;
    /* @44 */	jint lineWidth2;
    /* @48 */	jlong scaledLineWidth2;
    /* @56 */	jint numPenSegments;
    /* @60 */	jint_array * JVM_FIELD_CONST pen_dx;
    /* @64 */	jint_array * JVM_FIELD_CONST pen_dy;
    /* @68 */	jboolean_array * JVM_FIELD_CONST penIncluded;
    /* @72 */	jint_array * JVM_FIELD_CONST join;
    /* @76 */	jint_array * JVM_FIELD_CONST offset;
    /* @80 */	jint_array * JVM_FIELD_CONST reverse;
    /* @84 */	jint_array * JVM_FIELD_CONST miter;
    /* @88 */	jlong miterLimitSq;
    /* @96 */	jint prev;
    /* @100 */	jint rindex;
    /* @104 */	jint sx0;
    /* @108 */	jint sy0;
    /* @112 */	jint sx1;
    /* @116 */	jint sy1;
    /* @120 */	jint x0;
    /* @124 */	jint y0;
    /* @128 */	jint x1;
    /* @132 */	jint y1;
    /* @136 */	jint mx0;
    /* @140 */	jint my0;
    /* @144 */	jint mx1;
    /* @148 */	jint my1;
    /* @152 */	jint omx;
    /* @156 */	jint omy;
    /* @160 */	jint lx0;
    /* @164 */	jint ly0;
    /* @168 */	jint lx1;
    /* @172 */	jint ly1;
    /* @176 */	jint lx0p;
    /* @180 */	jint ly0p;
    /* @184 */	jint px0;
    /* @188 */	jint py0;
    /* @192 */	jdouble m00_2_m01_2;
    /* @200 */	jdouble m10_2_m11_2;
    /* @208 */	jdouble m00_m10_m01_m11;
    /* @216 */	jboolean started;
    /* @217 */	jboolean lineToOrigin;
    /* @218 */	jboolean joinToOrigin;
    /* @219 */	jboolean joinSegment;
};

struct Java_com_sun_pisces_Dasher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/Dasher */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint_array * JVM_FIELD_CONST dash;
    /* @12 */	jint startPhase;
    /* @16 */	jint startIdx;
    /* @20 */	jint idx;
    /* @24 */	jint phase;
    /* @28 */	jint sx;
    /* @32 */	jint sy;
    /* @36 */	jint x0;
    /* @40 */	jint y0;
    /* @44 */	jint m00;
    /* @48 */	jint m01;
    /* @52 */	jint m10;
    /* @56 */	jint m11;
    /* @60 */	struct Java_com_sun_pisces_Transform4 * JVM_FIELD_CONST transform;
    /* @64 */	jlong ldet;
    /* @72 */	jint sx1;
    /* @76 */	jint sy1;
    /* @80 */	jboolean symmetric;
    /* @81 */	jboolean firstDashOn;
    /* @82 */	jboolean starting;
    /* @83 */	jbyte ___pad584;
};

struct Java_com_sun_pisces_Flattener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/Flattener */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint flatness;
    /* @12 */	jint flatnessSq;
    /* @16 */	jint x0;
    /* @20 */	jint y0;
};

struct Java_com_sun_pisces_PathSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PathSource */
};

struct Java_com_sun_pisces_PathStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/PathStore */
    /*  @4 */	jint numSegments;
    /*  @8 */	jint_array * JVM_FIELD_CONST pathData;
    /* @12 */	jint dindex;
    /* @16 */	jbyte_array * JVM_FIELD_CONST pathTypes;
    /* @20 */	jint tindex;
    /* @24 */	jint x0;
    /* @28 */	jint y0;
    /* @32 */	jint sx0;
    /* @36 */	jint sy0;
    /* @40 */	jint xp;
    /* @44 */	jint yp;
};

struct Java_com_sun_perseus_j2d_RenderContext {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
    /* @44 */	jint pack2;
};

struct Java_com_sun_perseus_j2d_TextRenderingProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/TextRenderingProperties */
};

struct Java_org_w3c_dom_svg_SVGPoint {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGPoint */
};

struct Java_com_sun_perseus_j2d_Point {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Point */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat y;
};

struct Java_com_sun_perseus_j2d_RadialGradientPaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RadialGradientPaintDef */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	jfloat cx;
    /* @12 */	jfloat cy;
    /* @16 */	jfloat fx;
    /* @20 */	jfloat fy;
    /* @24 */	jfloat r;
    /* @28 */	jfloat_array * JVM_FIELD_CONST fractions;
    /* @32 */	jint_array * JVM_FIELD_CONST frac;
    /* @36 */	jint_array * JVM_FIELD_CONST rgba;
    /* @40 */	jint_array * JVM_FIELD_CONST lrgba;
    /* @44 */	jint lastPaintOpacity;
    /* @48 */	jint cycleMethod;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST gradientTransform;
    /* @56 */	jboolean isObjectBBox;
    /* @57 */	jbyte ___pad585;
    /* @58 */	jbyte ___pad586;
    /* @59 */	jbyte ___pad587;
};

struct Java_org_w3c_dom_svg_SVGException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* org/w3c/dom/svg/SVGException */
    /* @12 */	jshort code;
    /* @13 */	jbyte ___pad588;
    /* @14 */	jbyte ___pad589;
};

struct Java_com_sun_perseus_midp_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/Messages */
};

struct Java_com_sun_perseus_midp_SVGCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jboolean isRotated;
    /* @30 */	jbyte ___pad590;
    /* @31 */	jbyte ___pad591;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad592;
    /* @38 */	jbyte ___pad593;
    /* @39 */	jbyte ___pad594;
    /* com/sun/perseus/midp/SVGCanvas */
    /* @40 */	jint lastX;
    /* @44 */	jint lastY;
    /* @48 */	jint state;
    /* @52 */	struct Java_com_sun_perseus_model_SimpleCanvasManager * JVM_FIELD_CONST canvasManager;
    /* @56 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @60 */	struct Java_com_sun_pisces_NativeSurface * JVM_FIELD_CONST offscreen;
    /* @64 */	struct Java_com_sun_pisces_GraphicsSurfaceDestination * JVM_FIELD_CONST gsd;
    /* @68 */	jint offscreenWidth;
    /* @72 */	jint offscreenHeight;
    /* @76 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @80 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @84 */	struct Java_javax_microedition_m2g_SVGEventListener * JVM_FIELD_CONST svgEventListener;
    /* @88 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST updateQueue;
    /* @92 */	struct Java_com_sun_perseus_model_SMILSample * JVM_FIELD_CONST smilSample;
    /* @96 */	struct Java_com_sun_perseus_model_SMILSample_00024DocumentWallClock * JVM_FIELD_CONST clock;
    /* @100 */	jfloat timeIncrement;
    /* @104 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastMouseTarget;
    /* @108 */	jboolean lastWasPressed;
    /* @109 */	jboolean ignoreCanvasUpdate;
    /* @110 */	jbyte ___pad595;
    /* @111 */	jbyte ___pad596;
};

struct Java_javax_microedition_m2g_SVGImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
    /* javax/microedition/m2g/SVGImage */
};

struct Java_javax_microedition_m2g_SVGEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGEventListener */
};

struct Java_javax_microedition_m2g_SVGAnimator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGAnimator */
};

struct Java_com_sun_perseus_midp_SVGAnimatorImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGAnimator */
    /* com/sun/perseus/midp/SVGAnimatorImpl */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST svgCanvas;
};

struct Java_com_sun_perseus_model_SimpleCanvasManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @12 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @16 */	struct Java_com_sun_perseus_model_CanvasUpdateListener * JVM_FIELD_CONST canvasUpdateListener;
    /* @20 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST clearPaint;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @28 */	jboolean canvasConsumed;
    /* @29 */	jboolean needRepaint;
    /* @30 */	jboolean isOff;
    /* @31 */	jbyte ___pad597;
};

struct Java_com_sun_perseus_midp_SVGCanvas_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$1 */
    /*  @4 */	jint val_044width;
    /*  @8 */	jint val_044height;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_000242 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$2 */
    /*  @4 */	jfloat_array * JVM_FIELD_CONST val_044pt;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044eventType;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_000243 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$3 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044eventType;
    /*  @8 */	jint val_044keyCode;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_000244 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$4 */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_000245 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$5 */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_SMILSample_00024DocumentWallClock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample$DocumentWallClock */
    /*  @4 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST tcrs;
    /*  @8 */	jlong lastSample;
    /* @16 */	jboolean reset;
    /* @17 */	jbyte ___pad598;
    /* @18 */	jbyte ___pad599;
    /* @19 */	jbyte ___pad600;
};

struct Java_com_sun_pisces_GraphicsSurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/GraphicsSurfaceDestination */
    /*  @4 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST g;
};

struct Java_com_sun_pisces_NativeSurface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/AbstractSurface */
    /*  @4 */	jlong nativePtr;
    /* @12 */	struct Java_com_sun_pisces_NativeFinalizer * JVM_FIELD_CONST finalizer;
    /* com/sun/pisces/NativeSurface */
};

struct Java_com_sun_perseus_model_SMILSample {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample */
    /*  @4 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST doc;
    /*  @8 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST root;
    /* @12 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST currentTime;
    /* @16 */	struct Java_com_sun_perseus_model_SMILSample_00024Clock * JVM_FIELD_CONST clock;
};

struct Java_com_sun_perseus_model_SMILSample_00024Clock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample$Clock */
};

struct Java_com_sun_perseus_model_CanvasUpdateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CanvasUpdateListener */
};

struct Java_com_sun_pisces_Surface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Surface */
};

struct Java_com_sun_perseus_model_DirtyAreaManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateAdapter */
    /*  @4 */	struct Java_java_lang_Exception * JVM_FIELD_CONST loadingFailedException;
    /*  @8 */	jboolean loadComplete;
    /*  @9 */	jboolean loadingFailed;
    /* @10 */	jboolean loadStarting;
    /* @11 */	jbyte ___pad601;
    /* com/sun/perseus/model/DirtyAreaManager */
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST dirtyNodes;
    /* @16 */	struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileElement * JVM_FIELD_CONST rootTile;
    /* @20 */	struct Java_com_sun_perseus_model_Viewport * JVM_FIELD_CONST vp;
    /* @24 */	jint tileMinSize;
    /* @28 */	jint lastWidth;
    /* @32 */	jint lastHeight;
    /* @36 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST lastRG;
};

struct Java_com_sun_pisces_NativeFinalizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeFinalizer */
    /*  @4 */	struct Java_com_sun_pisces_NativeFinalization * JVM_FIELD_CONST guardedObject;
};

struct Java_com_sun_pisces_AbstractSurface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/AbstractSurface */
    /*  @4 */	jlong nativePtr;
    /* @12 */	struct Java_com_sun_pisces_NativeFinalizer * JVM_FIELD_CONST finalizer;
};

struct Java_com_sun_pisces_AbstractSurface_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/AbstractSurface$1 */
};

struct Java_com_sun_pisces_SurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/SurfaceDestination */
};

struct Java_com_sun_pisces_NativeFinalization {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeFinalization */
};

struct Java_com_sun_perseus_model_BaseValue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/BaseValue */
};

struct Java_com_sun_perseus_model_RefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RefValues */
};

struct Java_com_sun_perseus_model_TimedElementSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad602;
};

struct Java_com_sun_perseus_model_Animation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad603;
    /* @30 */	jbyte ___pad604;
    /* @31 */	jbyte ___pad605;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad606;
    /* @71 */	jbyte ___pad607;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad608;
    /* @110 */	jbyte ___pad609;
    /* @111 */	jbyte ___pad610;
};

struct Java_com_sun_perseus_model_Segment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Segment */
};

struct Java_com_sun_perseus_model_TimeContainerSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad611;
    /* com/sun/perseus/model/TimeContainerSupport */
    /* @104 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleTime;
    /* @108 */	struct Java_java_util_Vector * JVM_FIELD_CONST timedElementChildren;
};

struct Java_com_sun_perseus_model_TimedElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad612;
    /* @30 */	jbyte ___pad613;
    /* @31 */	jbyte ___pad614;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad615;
    /* @71 */	jbyte ___pad616;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_TimeCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad617;
    /* @10 */	jbyte ___pad618;
    /* @11 */	jbyte ___pad619;
};

struct Java_org_w3c_dom_svg_SVGAnimationElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGAnimationElement */
};

struct Java_com_sun_perseus_model_AbstractAnimate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad620;
    /* @30 */	jbyte ___pad621;
    /* @31 */	jbyte ___pad622;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad623;
    /* @71 */	jbyte ___pad624;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad625;
    /* @110 */	jbyte ___pad626;
    /* @111 */	jbyte ___pad627;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @128 */	jint calcMode;
    /* @132 */	jint actualCalcMode;
    /* @136 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @140 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @144 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @148 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @168 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @172 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @176 */	jboolean additive;
    /* @177 */	jboolean accumulate;
    /* @178 */	jboolean isToAnimation;
    /* @179 */	jbyte ___pad628;
};

struct Java_com_sun_perseus_model_RenderingManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RenderingManager */
    /*  @4 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST node;
    /*  @8 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST rTile;
    /* @12 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST lastRenderedTile;
    /* @16 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST lrtCache;
    /* @20 */	jboolean rTileDirty;
    /* @21 */	jbyte ___pad629;
    /* @22 */	jbyte ___pad630;
    /* @23 */	jbyte ___pad631;
};

struct Java_com_sun_perseus_model_AbstractRenderingNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad632;
    /* @30 */	jbyte ___pad633;
    /* @31 */	jbyte ___pad634;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad635;
    /* @54 */	jbyte ___pad636;
    /* @55 */	jbyte ___pad637;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
    /* com/sun/perseus/model/AbstractRenderingNodeProxy */
    /* @104 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
};

struct Java_com_sun_perseus_model_AbstractRenderingNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad638;
    /* @30 */	jbyte ___pad639;
    /* @31 */	jbyte ___pad640;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad641;
    /* @71 */	jbyte ___pad642;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
};

struct Java_org_w3c_dom_svg_SVGLocatableElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGLocatableElement */
};

struct Java_com_sun_perseus_model_DecoratedNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DecoratedNode */
};

struct Java_com_sun_perseus_model_GraphicsNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GraphicsNode */
};

struct Java_com_sun_perseus_model_CompositeGraphicsNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad643;
    /* @30 */	jbyte ___pad644;
    /* @31 */	jbyte ___pad645;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad646;
    /* @71 */	jbyte ___pad647;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
};

struct Java_com_sun_perseus_model_CompositeGraphicsNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad648;
    /* @30 */	jbyte ___pad649;
    /* @31 */	jbyte ___pad650;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad651;
    /* @54 */	jbyte ___pad652;
    /* @55 */	jbyte ___pad653;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
};

struct Java_com_sun_perseus_model_TransformSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TransformSegment */
    /*  @4 */	jfloat_array * JVM_FIELD_CONST start;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST end;
    /* @12 */	jint type;
};

struct Java_com_sun_perseus_model_FloatSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FloatSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_FloatTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad654;
    /* @30 */	jbyte ___pad655;
    /* @31 */	jbyte ___pad656;
    /* com/sun/perseus/model/FloatTraitAnim */
};

struct Java_com_sun_perseus_model_TransformTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad657;
    /* @30 */	jbyte ___pad658;
    /* @31 */	jbyte ___pad659;
    /* com/sun/perseus/model/FloatTraitAnim */
    /* com/sun/perseus/model/TransformTraitAnim */
};

struct Java_com_sun_perseus_model_LeafMotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/LeafMotionSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_MotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/MotionSegment */
};

struct Java_com_sun_perseus_model_AnimateMotion {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad660;
    /* @30 */	jbyte ___pad661;
    /* @31 */	jbyte ___pad662;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad663;
    /* @71 */	jbyte ___pad664;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad665;
    /* @110 */	jbyte ___pad666;
    /* @111 */	jbyte ___pad667;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @128 */	jint calcMode;
    /* @132 */	jint actualCalcMode;
    /* @136 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @140 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @144 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @148 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @168 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @172 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @176 */	jboolean additive;
    /* @177 */	jboolean accumulate;
    /* @178 */	jboolean isToAnimation;
    /* @179 */	jbyte ___pad668;
    /* com/sun/perseus/model/AnimateMotion */
    /* @180 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @184 */	jfloat_array * JVM_FIELD_CONST keyPoints;
    /* @188 */	jfloat rotate;
    /* @192 */	jfloat cosRotate;
    /* @196 */	jfloat sinRotate;
    /* @200 */	jint rotateType;
    /* @204 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST pathRefValues;
    /* @208 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST mpathRefValues;
};

struct Java_com_sun_perseus_model_MotionTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad669;
    /* @30 */	jbyte ___pad670;
    /* @31 */	jbyte ___pad671;
    /* com/sun/perseus/model/FloatTraitAnim */
    /* com/sun/perseus/model/TransformTraitAnim */
    /* com/sun/perseus/model/MotionTraitAnim */
};

struct Java_com_sun_perseus_model_AbstractShapeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad672;
    /* @30 */	jbyte ___pad673;
    /* @31 */	jbyte ___pad674;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad675;
    /* @71 */	jbyte ___pad676;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
};

struct Java_com_sun_perseus_model_AbstractShapeNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad677;
    /* @30 */	jbyte ___pad678;
    /* @31 */	jbyte ___pad679;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad680;
    /* @54 */	jbyte ___pad681;
    /* @55 */	jbyte ___pad682;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
    /* com/sun/perseus/model/AbstractRenderingNodeProxy */
    /* @104 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNodeProxy */
};

struct Java_org_w3c_dom_events_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/Event */
};

struct Java_com_sun_perseus_model_EventBaseCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad683;
    /* @10 */	jbyte ___pad684;
    /* @11 */	jbyte ___pad685;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
};

struct Java_com_sun_perseus_model_AccessKeyCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad686;
    /* @10 */	jbyte ___pad687;
    /* @11 */	jbyte ___pad688;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
    /* com/sun/perseus/model/AccessKeyCondition */
    /* @36 */	jchar accessKey;
    /* @37 */	jbyte ___pad689;
    /* @38 */	jbyte ___pad690;
};

struct Java_com_sun_perseus_model_StructureNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad691;
    /* @30 */	jbyte ___pad692;
    /* @31 */	jbyte ___pad693;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad694;
    /* @71 */	jbyte ___pad695;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
};

struct Java_com_sun_perseus_model_TextNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TextNode */
};

struct Java_com_sun_perseus_model_Group {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad696;
    /* @30 */	jbyte ___pad697;
    /* @31 */	jbyte ___pad698;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad699;
    /* @71 */	jbyte ___pad700;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
};

struct Java_com_sun_perseus_model_StringSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/StringSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_StringTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad701;
    /* @30 */	jbyte ___pad702;
    /* @31 */	jbyte ___pad703;
    /* com/sun/perseus/model/StringTraitAnim */
    /* @32 */	jobject_array * JVM_FIELD_CONST baseValue;
};

struct Java_com_sun_perseus_model_Animate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad704;
    /* @30 */	jbyte ___pad705;
    /* @31 */	jbyte ___pad706;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad707;
    /* @71 */	jbyte ___pad708;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad709;
    /* @110 */	jbyte ___pad710;
    /* @111 */	jbyte ___pad711;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @128 */	jint calcMode;
    /* @132 */	jint actualCalcMode;
    /* @136 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @140 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @144 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @148 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @168 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @172 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @176 */	jboolean additive;
    /* @177 */	jboolean accumulate;
    /* @178 */	jboolean isToAnimation;
    /* @179 */	jbyte ___pad712;
    /* com/sun/perseus/model/Animate */
    /* @180 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
};

struct Java_com_sun_perseus_model_AnimateTransform {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad713;
    /* @30 */	jbyte ___pad714;
    /* @31 */	jbyte ___pad715;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad716;
    /* @71 */	jbyte ___pad717;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad718;
    /* @110 */	jbyte ___pad719;
    /* @111 */	jbyte ___pad720;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @128 */	jint calcMode;
    /* @132 */	jint actualCalcMode;
    /* @136 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @140 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @144 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @148 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @168 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @172 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @176 */	jboolean additive;
    /* @177 */	jboolean accumulate;
    /* @178 */	jboolean isToAnimation;
    /* @179 */	jbyte ___pad721;
    /* com/sun/perseus/model/Animate */
    /* @180 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
    /* com/sun/perseus/model/AnimateTransform */
};

struct Java_com_sun_perseus_model_CanvasManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @12 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @16 */	struct Java_com_sun_perseus_model_CanvasUpdateListener * JVM_FIELD_CONST canvasUpdateListener;
    /* @20 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST clearPaint;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @28 */	jboolean canvasConsumed;
    /* @29 */	jboolean needRepaint;
    /* @30 */	jboolean isOff;
    /* @31 */	jbyte ___pad722;
    /* com/sun/perseus/model/CanvasManager */
    /* @32 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST progressiveNode;
    /* @36 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST needLoadNode;
    /* @40 */	struct Java_com_sun_perseus_model_SMILSample * JVM_FIELD_CONST sampler;
    /* @44 */	jlong smilRate;
    /* @52 */	jboolean loading;
    /* @53 */	jbyte ___pad723;
    /* @54 */	jbyte ___pad724;
    /* @55 */	jbyte ___pad725;
};

struct Java_com_sun_perseus_model_CanvasManager_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CanvasManager$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_CanvasManager * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_CompositeMotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CompositeMotionSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jfloat length;
    /* @12 */	jfloat_array * JVM_FIELD_CONST nSegLength;
};

struct Java_com_sun_perseus_model_ConditionalProcessing {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ConditionalProcessing */
};

struct Java_com_sun_perseus_model_DefaultImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST cache;
    /*  @8 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST loaderUtil;
};

struct Java_com_sun_perseus_model_DefaultImageLoader_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_DefaultImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_RasterImageConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RasterImageConsumer */
};

struct Java_com_sun_perseus_model_DefaultImageLoader_00024ImageLoadRunnable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$ImageLoadRunnable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST uri;
    /*  @8 */	struct Java_com_sun_perseus_model_RasterImageConsumer * JVM_FIELD_CONST node;
    /* @12 */	struct Java_com_sun_perseus_model_DefaultImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_DefaultImageLoader_00024ImageSetter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$ImageSetter */
    /*  @4 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST img;
    /*  @8 */	struct Java_com_sun_perseus_model_RasterImageConsumer * JVM_FIELD_CONST node;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST uri;
};

struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableQueueHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$RunnableQueueHandler */
};

struct Java_com_sun_perseus_model_Defs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad726;
    /* @30 */	jbyte ___pad727;
    /* @31 */	jbyte ___pad728;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad729;
    /* @71 */	jbyte ___pad730;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Defs */
};

struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
    /* com/sun/perseus/model/DirtyAreaManager$TileElement */
    /* @20 */	struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileQuadrant * JVM_FIELD_CONST parent;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileElement * JVM_FIELD_CONST next;
    /* @28 */	jboolean hit;
    /* @29 */	jbyte ___pad731;
    /* @30 */	jbyte ___pad732;
    /* @31 */	jbyte ___pad733;
};

struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileQuadrant {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
    /* com/sun/perseus/model/DirtyAreaManager$TileElement */
    /* @20 */	struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileQuadrant * JVM_FIELD_CONST parent;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager_00024TileElement * JVM_FIELD_CONST next;
    /* @28 */	jboolean hit;
    /* @29 */	jbyte ___pad734;
    /* @30 */	jbyte ___pad735;
    /* @31 */	jbyte ___pad736;
    /* com/sun/perseus/model/DirtyAreaManager$TileQuadrant */
    /* @32 */	jobject_array * JVM_FIELD_CONST children;
};

struct Java_com_sun_perseus_model_GenericElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad737;
    /* @30 */	jbyte ___pad738;
    /* @31 */	jbyte ___pad739;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad740;
    /* @71 */	jbyte ___pad741;
    /* com/sun/perseus/model/GenericElementNode */
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST content;
};

struct Java_com_sun_perseus_model_Ellipse {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad742;
    /* @30 */	jbyte ___pad743;
    /* @31 */	jbyte ___pad744;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad745;
    /* @71 */	jbyte ___pad746;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Ellipse */
    /* @132 */	jfloat x;
    /* @136 */	jfloat y;
    /* @140 */	jfloat width;
    /* @144 */	jfloat height;
    /* @148 */	jboolean isCircle;
    /* @149 */	jbyte ___pad747;
    /* @150 */	jbyte ___pad748;
    /* @151 */	jbyte ___pad749;
};

struct Java_com_sun_perseus_model_FloatRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FloatRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST segLength;
};

struct Java_com_sun_perseus_model_HKern {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad750;
    /* @30 */	jbyte ___pad751;
    /* @31 */	jbyte ___pad752;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad753;
    /* @71 */	jbyte ___pad754;
    /* com/sun/perseus/model/HKern */
    /* @72 */	jobject_array * JVM_FIELD_CONST u1;
    /* @76 */	jobject_array * JVM_FIELD_CONST u2;
    /* @80 */	jobject_array * JVM_FIELD_CONST g1;
    /* @84 */	jobject_array * JVM_FIELD_CONST g2;
    /* @88 */	jfloat k;
    /* @92 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST nextHKern;
};

struct Java_com_sun_perseus_model_Glyph {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad755;
    /* @30 */	jbyte ___pad756;
    /* @31 */	jbyte ___pad757;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad758;
    /* @71 */	jbyte ___pad759;
    /* com/sun/perseus/model/Glyph */
    /* @72 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST d;
    /* @76 */	jfloat horizontalAdvanceX;
    /* @80 */	jfloat computedHorizontalAdvanceX;
    /* @84 */	jfloat origin;
    /* @88 */	jfloat emSquareScale;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST unicode;
    /* @96 */	jobject_array * JVM_FIELD_CONST glyphName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_Font {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad760;
    /* @30 */	jbyte ___pad761;
    /* @31 */	jbyte ___pad762;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad763;
    /* @71 */	jbyte ___pad764;
    /* com/sun/perseus/model/Font */
    /* @72 */	jfloat horizontalOriginX;
    /* @76 */	jfloat horizontalAdvanceX;
    /* @80 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST fontFace;
    /* @84 */	struct Java_com_sun_perseus_model_Glyph * JVM_FIELD_CONST missingGlyph;
    /* @88 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST firstHKern;
    /* @92 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST lastHKern;
};

struct Java_com_sun_perseus_model_GlyphProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GlyphProxy */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat rotate;
    /* @12 */	struct Java_com_sun_perseus_model_Glyph * JVM_FIELD_CONST proxied;
    /* @16 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST nextSibling;
    /* @20 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST prevSibling;
};

struct Java_com_sun_perseus_model_GlyphLayout {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GlyphLayout */
    /*  @4 */	jfloat advance;
    /*  @8 */	jfloat x;
    /* @12 */	jfloat y;
    /* @16 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST firstChild;
    /* @20 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST lastChild;
    /* @24 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST prevSibling;
    /* @28 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST nextSibling;
    /* @32 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @36 */	jfloat_array * JVM_FIELD_CONST helperDashArray;
};

struct Java_com_sun_perseus_model_Stop {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad765;
    /* @30 */	jbyte ___pad766;
    /* @31 */	jbyte ___pad767;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad768;
    /* @71 */	jbyte ___pad769;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/Stop */
    /* @120 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST stopColor;
    /* @124 */	jfloat stopOpacity;
    /* @128 */	jfloat offset;
};

struct Java_com_sun_perseus_model_PaintElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad770;
    /* @30 */	jbyte ___pad771;
    /* @31 */	jbyte ___pad772;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad773;
    /* @71 */	jbyte ___pad774;
    /* com/sun/perseus/model/PaintElement */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @76 */	jboolean isObjectBBox;
    /* @77 */	jbyte ___pad775;
    /* @78 */	jbyte ___pad776;
    /* @79 */	jbyte ___pad777;
};

struct Java_com_sun_perseus_model_GradientElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad778;
    /* @30 */	jbyte ___pad779;
    /* @31 */	jbyte ___pad780;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad781;
    /* @71 */	jbyte ___pad782;
    /* com/sun/perseus/model/PaintElement */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @76 */	jboolean isObjectBBox;
    /* @77 */	jbyte ___pad783;
    /* @78 */	jbyte ___pad784;
    /* @79 */	jbyte ___pad785;
    /* com/sun/perseus/model/GradientElement */
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @84 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @88 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @92 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
};

struct Java_com_sun_perseus_model_ImageNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad786;
    /* @30 */	jbyte ___pad787;
    /* @31 */	jbyte ___pad788;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad789;
    /* @71 */	jbyte ___pad790;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/ImageNode */
    /* @132 */	jfloat x;
    /* @136 */	jfloat y;
    /* @140 */	jfloat width;
    /* @144 */	jfloat height;
    /* @148 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST image;
    /* @152 */	struct Java_java_lang_String * JVM_FIELD_CONST href;
    /* @156 */	struct Java_java_lang_String * JVM_FIELD_CONST absoluteURI;
    /* @160 */	jint align;
    /* @164 */	jboolean imageLoaded;
    /* @165 */	jbyte ___pad791;
    /* @166 */	jbyte ___pad792;
    /* @167 */	jbyte ___pad793;
};

struct Java_com_sun_perseus_model_TimeInterval {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInterval */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST begin;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST end;
    /* @12 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastDur;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
};

struct Java_com_sun_perseus_model_IntervalTimeInstance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInstance */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST time;
    /* @12 */	jboolean clearOnReset;
    /* @13 */	jboolean isBegin;
    /* @14 */	jbyte ___pad794;
    /* @15 */	jbyte ___pad795;
    /* com/sun/perseus/model/IntervalTimeInstance */
    /* @16 */	jlong offset;
    /* @24 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST timeInterval;
    /* @28 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST syncBase;
    /* @32 */	jboolean isBeginSync;
    /* @33 */	jbyte ___pad796;
    /* @34 */	jbyte ___pad797;
    /* @35 */	jbyte ___pad798;
};

struct Java_com_sun_perseus_model_TimeInstance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInstance */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST time;
    /* @12 */	jboolean clearOnReset;
    /* @13 */	jboolean isBegin;
    /* @14 */	jbyte ___pad799;
    /* @15 */	jbyte ___pad800;
};

struct Java_com_sun_perseus_model_Line {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad801;
    /* @30 */	jbyte ___pad802;
    /* @31 */	jbyte ___pad803;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad804;
    /* @71 */	jbyte ___pad805;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Line */
    /* @132 */	jfloat x1;
    /* @136 */	jfloat y1;
    /* @140 */	jfloat x2;
    /* @144 */	jfloat y2;
};

struct Java_com_sun_perseus_model_LinearGradient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad806;
    /* @30 */	jbyte ___pad807;
    /* @31 */	jbyte ___pad808;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad809;
    /* @71 */	jbyte ___pad810;
    /* com/sun/perseus/model/PaintElement */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @76 */	jboolean isObjectBBox;
    /* @77 */	jbyte ___pad811;
    /* @78 */	jbyte ___pad812;
    /* @79 */	jbyte ___pad813;
    /* com/sun/perseus/model/GradientElement */
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @84 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @88 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @92 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* com/sun/perseus/model/LinearGradient */
    /* @96 */	jfloat x1;
    /* @100 */	jfloat y1;
    /* @104 */	jfloat x2;
    /* @108 */	jfloat y2;
};

struct Java_com_sun_perseus_model_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Messages */
};

struct Java_com_sun_perseus_model_MotionRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/MotionRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST nSegLength;
    /* @20 */	jfloat_array * JVM_FIELD_CONST segLength;
    /* @24 */	struct Java_com_sun_perseus_model_AnimateMotion * JVM_FIELD_CONST motion;
};

struct Java_com_sun_perseus_model_OffsetCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad814;
    /* @10 */	jbyte ___pad815;
    /* @11 */	jbyte ___pad816;
    /* com/sun/perseus/model/OffsetCondition */
    /* @12 */	jlong offset;
};

struct Java_com_sun_perseus_model_PaintElement_00024Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintElement$Reference */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST paintType;
    /* @12 */	struct Java_com_sun_perseus_model_PaintElement * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_PaintServerReference_00024Unresolved {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintServerReference$Unresolved */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST paintType;
};

struct Java_com_sun_perseus_model_PaintServerReference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintServerReference */
};

struct Java_com_sun_perseus_model_RadialGradient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad817;
    /* @30 */	jbyte ___pad818;
    /* @31 */	jbyte ___pad819;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad820;
    /* @71 */	jbyte ___pad821;
    /* com/sun/perseus/model/PaintElement */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @76 */	jboolean isObjectBBox;
    /* @77 */	jbyte ___pad822;
    /* @78 */	jbyte ___pad823;
    /* @79 */	jbyte ___pad824;
    /* com/sun/perseus/model/GradientElement */
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @84 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @88 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @92 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* com/sun/perseus/model/RadialGradient */
    /* @96 */	jfloat cx;
    /* @100 */	jfloat cy;
    /* @104 */	jfloat r;
};

struct Java_com_sun_perseus_model_Rect {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad825;
    /* @30 */	jbyte ___pad826;
    /* @31 */	jbyte ___pad827;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad828;
    /* @71 */	jbyte ___pad829;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Rect */
    /* @132 */	jfloat width;
    /* @136 */	jfloat height;
    /* @140 */	jfloat x;
    /* @144 */	jfloat y;
    /* @148 */	jfloat aw;
    /* @152 */	jfloat ah;
};

struct Java_com_sun_perseus_model_RepeatCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad830;
    /* @10 */	jbyte ___pad831;
    /* @11 */	jbyte ___pad832;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
    /* com/sun/perseus/model/RepeatCondition */
    /* @36 */	jint repeatCount;
};

struct Java_org_w3c_dom_svg_SVGSVGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGSVGElement */
};

struct Java_com_sun_perseus_model_SVG {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad833;
    /* @30 */	jbyte ___pad834;
    /* @31 */	jbyte ___pad835;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad836;
    /* @71 */	jbyte ___pad837;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/SVG */
    /* @128 */	jobject_array * JVM_FIELD_CONST viewBox;
    /* @132 */	jint align;
    /* @136 */	jfloat width;
    /* @140 */	jfloat height;
    /* @144 */	jfloat currentScale;
    /* @148 */	jfloat tx;
    /* @152 */	jfloat ty;
    /* @156 */	jfloat currentRotate;
    /* @160 */	jfloat currentTimeDelta;
};

struct Java_com_sun_perseus_model_SVGImageImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
    /* javax/microedition/m2g/SVGImage */
    /* com/sun/perseus/model/SVGImageImpl */
    /*  @4 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /*  @8 */	struct Java_com_sun_perseus_model_SVGImageLoader * JVM_FIELD_CONST svgImageLoader;
    /* @12 */	struct Java_org_w3c_dom_svg_SVGElement * JVM_FIELD_CONST lastElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST waitURI;
    /* @20 */	jboolean isBrokenImage;
    /* @21 */	jbyte ___pad838;
    /* @22 */	jbyte ___pad839;
    /* @23 */	jbyte ___pad840;
};

struct Java_com_sun_perseus_model_SVGImageImpl_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SVGImageImpl$1 */
    /*  @4 */	jfloat val_044seconds;
    /*  @8 */	struct Java_com_sun_perseus_model_SVGImageImpl * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_SVGImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST cache;
    /*  @8 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST __dup1__loaderUtil;
    /* com/sun/perseus/model/SVGImageLoader */
    /* @12 */	struct Java_javax_microedition_m2g_ExternalResourceHandler * JVM_FIELD_CONST handler;
    /* @16 */	struct Java_com_sun_perseus_model_SVGImageImpl * JVM_FIELD_CONST svgImage;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST rasterImageConsumerTable;
    /* @24 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST loaderUtil;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingNeedsURI;
    /* @32 */	jboolean documentLoaded;
    /* @33 */	jbyte ___pad841;
    /* @34 */	jbyte ___pad842;
    /* @35 */	jbyte ___pad843;
};

struct Java_javax_microedition_m2g_ExternalResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ExternalResourceHandler */
};

struct Java_javax_microedition_m2g_ScalableImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
};

struct Java_com_sun_perseus_model_SVGImageLoader_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SVGImageLoader$1 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044uri;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST val_044image;
    /* @12 */	struct Java_com_sun_perseus_model_SVGImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_Set {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad844;
    /* @30 */	jbyte ___pad845;
    /* @31 */	jbyte ___pad846;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad847;
    /* @71 */	jbyte ___pad848;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @80 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @84 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @88 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @104 */	jint type;
    /* @108 */	jboolean hasNoEffect;
    /* @109 */	jbyte ___pad849;
    /* @110 */	jbyte ___pad850;
    /* @111 */	jbyte ___pad851;
    /* com/sun/perseus/model/Set */
    /* @112 */	jobject_array * JVM_FIELD_CONST to;
    /* @116 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
};

struct Java_com_sun_perseus_model_ShapeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad852;
    /* @30 */	jbyte ___pad853;
    /* @31 */	jbyte ___pad854;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad855;
    /* @71 */	jbyte ___pad856;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @128 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/ShapeNode */
    /* @132 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST path;
    /* @136 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_SimpleCanvasManager_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_SimpleCanvasManager * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_SolidColor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad857;
    /* @30 */	jbyte ___pad858;
    /* @31 */	jbyte ___pad859;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad860;
    /* @71 */	jbyte ___pad861;
    /* com/sun/perseus/model/PaintElement */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @76 */	jboolean isObjectBBox;
    /* @77 */	jbyte ___pad862;
    /* @78 */	jbyte ___pad863;
    /* @79 */	jbyte ___pad864;
    /* com/sun/perseus/model/SolidColor */
    /* @80 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST solidColor;
    /* @84 */	jfloat solidOpacity;
    /* @88 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST compoundColor;
};

struct Java_com_sun_perseus_model_StrictElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad865;
    /* @30 */	jbyte ___pad866;
    /* @31 */	jbyte ___pad867;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad868;
    /* @71 */	jbyte ___pad869;
    /* com/sun/perseus/model/StrictElement */
    /* @72 */	jobject_array * JVM_FIELD_CONST requiredTraits;
    /* @76 */	jobject_array * JVM_FIELD_CONST requiredTraitsNS;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* @84 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
};

struct Java_com_sun_perseus_model_StringRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/StringRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST length;
};

struct Java_com_sun_perseus_model_StructureNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad870;
    /* @30 */	jbyte ___pad871;
    /* @31 */	jbyte ___pad872;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad873;
    /* @54 */	jbyte ___pad874;
    /* @55 */	jbyte ___pad875;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @104 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @108 */	jfloat fontSize;
};

struct Java_com_sun_perseus_model_Switch {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad876;
    /* @30 */	jbyte ___pad877;
    /* @31 */	jbyte ___pad878;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad879;
    /* @71 */	jbyte ___pad880;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Switch */
};

struct Java_com_sun_perseus_model_Symbol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad881;
    /* @30 */	jbyte ___pad882;
    /* @31 */	jbyte ___pad883;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad884;
    /* @71 */	jbyte ___pad885;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Symbol */
    /* @140 */	jobject_array * JVM_FIELD_CONST viewBox;
};

struct Java_com_sun_perseus_model_TimeDependent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeDependent */
};

struct Java_com_sun_perseus_model_SyncBaseCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad886;
    /* @10 */	jbyte ___pad887;
    /* @11 */	jbyte ___pad888;
    /* com/sun/perseus/model/SyncBaseCondition */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST syncBaseId;
    /* @16 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST syncBase;
    /* @20 */	jlong offset;
    /* @28 */	jboolean isBeginSync;
    /* @29 */	jbyte ___pad889;
    /* @30 */	jbyte ___pad890;
    /* @31 */	jbyte ___pad891;
};

struct Java_com_sun_perseus_model_Text {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad892;
    /* @30 */	jbyte ___pad893;
    /* @31 */	jbyte ___pad894;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad895;
    /* @71 */	jbyte ___pad896;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Text */
    /* @140 */	struct Java_java_lang_String * JVM_FIELD_CONST content;
    /* @144 */	jfloat_array * JVM_FIELD_CONST x;
    /* @148 */	jfloat_array * JVM_FIELD_CONST y;
    /* @152 */	jfloat_array * JVM_FIELD_CONST rotate;
    /* @156 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST firstChunk;
    /* @160 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST lastChunk;
    /* @164 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* @168 */	jfloat_array * JVM_FIELD_CONST helperDashArray;
};

struct Java_com_sun_perseus_model_TextProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad897;
    /* @30 */	jbyte ___pad898;
    /* @31 */	jbyte ___pad899;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad900;
    /* @54 */	jbyte ___pad901;
    /* @55 */	jbyte ___pad902;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @104 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @108 */	jfloat fontSize;
    /* com/sun/perseus/model/TextProxy */
    /* @112 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* @116 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST firstChunk;
    /* @120 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST lastChunk;
};

struct Java_com_sun_perseus_model_TimeContainerNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad903;
    /* @30 */	jbyte ___pad904;
    /* @31 */	jbyte ___pad905;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad906;
    /* @71 */	jbyte ___pad907;
    /* com/sun/perseus/model/TimedElementNode */
    /* @72 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/TimeContainerNode */
    /* @80 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainerSupport;
};

struct Java_com_sun_perseus_model_TransformRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TransformRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST segLength;
};

struct Java_com_sun_perseus_model_Use {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad908;
    /* @30 */	jbyte ___pad909;
    /* @31 */	jbyte ___pad910;
    /* com/sun/perseus/model/CompositeNode */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @48 */	jobject_array * JVM_FIELD_CONST conditionalAttributes;
    /* @52 */	jint xmlSpace;
    /* @56 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @68 */	jboolean paintNeedsLoad;
    /* @69 */	jboolean buildingProxy;
    /* @70 */	jbyte ___pad911;
    /* @71 */	jbyte ___pad912;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @72 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @76 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @84 */	jfloat strokeWidth;
    /* @88 */	jfloat strokeMiterLimit;
    /* @92 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @96 */	jfloat strokeDashOffset;
    /* @100 */	jint pack;
    /* @104 */	jint pack2;
    /* @108 */	jint markers;
    /* @112 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @120 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @124 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Use */
    /* @140 */	jfloat x;
    /* @144 */	jfloat y;
    /* @148 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST proxy;
    /* @152 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @156 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST ref;
};

struct Java_com_sun_perseus_model_UseProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	jint canRenderState;
    /* @24 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @28 */	jboolean loaded;
    /* @29 */	jbyte ___pad913;
    /* @30 */	jbyte ___pad914;
    /* @31 */	jbyte ___pad915;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @48 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @52 */	jboolean expanded;
    /* @53 */	jbyte ___pad916;
    /* @54 */	jbyte ___pad917;
    /* @55 */	jbyte ___pad918;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @60 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @64 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @72 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @76 */	jint fillRule;
    /* @80 */	jfloat strokeWidth;
    /* @84 */	jfloat strokeMiterLimit;
    /* @88 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @92 */	jfloat strokeDashOffset;
    /* @96 */	jint pack;
    /* @100 */	jint pack2;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @104 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @108 */	jfloat fontSize;
    /* com/sun/perseus/model/UseProxy */
};

struct Java_com_sun_perseus_parser_AbstractParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
};

struct Java_com_sun_perseus_util_SVGConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/SVGConstants */
};

struct Java_com_sun_perseus_parser_NumberParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
};

struct Java_com_sun_perseus_platform_FilterInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/FilterInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_perseus_platform_BufferedInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/FilterInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/perseus/platform/BufferedInputStream */
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jint count;
    /* @16 */	jint pos;
    /* @20 */	jint markpos;
    /* @24 */	jint marklimit;
};

struct Java_com_sun_perseus_platform_GZIPInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/GZIPInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint count;
    /* @16 */	jint idx;
    /* @20 */	jint curByte;
    /* @24 */	jint curPos;
};

struct Java_com_sun_perseus_platform_GZIPSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/GZIPSupport */
};

struct Java_com_sun_perseus_platform_HuffmanTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/HuffmanTable */
    /*  @4 */	struct Java_com_sun_perseus_platform_GZIPInputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST codeTable;
    /* @12 */	jint minLen;
};

struct Java_com_sun_perseus_platform_MathSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/MathSupport */
};

struct Java_com_sun_perseus_platform_PURL {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/PURL */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @12 */	jint port;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST file;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST authority;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST userInfo;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST ref;
    /* @40 */	struct Java_java_lang_Object * JVM_FIELD_CONST hostAddress;
    /* @44 */	jint hashCode;
};

struct Java_com_sun_perseus_platform_PURLStreamHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/PURLStreamHandler */
};

struct Java_com_sun_perseus_platform_Parts {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/Parts */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST ref;
};

struct Java_com_sun_perseus_platform_ResourceHandler_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ResourceHandler$1 */
};

struct Java_com_sun_perseus_platform_ResourceHandler_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ResourceHandler$SecurityTrusted */
};

struct Java_com_sun_perseus_platform_ResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ResourceHandler */
};

struct Java_com_sun_perseus_platform_ThreadSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ThreadSupport */
};

struct Java_com_sun_perseus_platform_URLResolver {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/URLResolver */
};

struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST prev;
};

struct Java_com_sun_perseus_util_DoublyLinkedList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST head;
    /*  @8 */	jint size;
};

struct Java_com_sun_perseus_util_RunnableQueue_00024Link {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST prev;
    /* com/sun/perseus/util/RunnableQueue$Link */
    /* @12 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /* @16 */	struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableHandler * JVM_FIELD_CONST runHandler;
};

struct Java_com_sun_perseus_util_RunnableQueue_00024LockableLink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_00024Node * JVM_FIELD_CONST prev;
    /* com/sun/perseus/util/RunnableQueue$Link */
    /* @12 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /* @16 */	struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableHandler * JVM_FIELD_CONST runHandler;
    /* com/sun/perseus/util/RunnableQueue$LockableLink */
    /* @20 */	jboolean locked;
    /* @21 */	jbyte ___pad919;
    /* @22 */	jbyte ___pad920;
    /* @23 */	jbyte ___pad921;
};

struct Java_com_sun_perseus_util_RunnableQueue_00024VoidQueueHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$VoidQueueHandler */
};

struct Java_com_sun_perseus_util_Scheduler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/Scheduler */
    /*  @4 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST rq;
    /*  @8 */	jobject_array * JVM_FIELD_CONST entries;
};

struct Java_com_sun_perseus_util_Scheduler_00024Entry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/Scheduler$Entry */
    /*  @4 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /*  @8 */	jlong interval;
    /* @16 */	jlong nextRun;
    /* @24 */	struct Java_com_sun_perseus_util_RunnableQueue_00024RunnableHandler * JVM_FIELD_CONST handler;
    /* @28 */	jboolean live;
    /* @29 */	jbyte ___pad922;
    /* @30 */	jbyte ___pad923;
    /* @31 */	jbyte ___pad924;
};

struct Java_com_sun_perseus_util_SimpleTokenizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/SimpleTokenizer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST data;
    /*  @8 */	jint length;
    /* @12 */	jchar_array * JVM_FIELD_CONST del;
    /* @16 */	jint cur;
};

struct Java_com_sun_pisces_AbstractSurface_00024AbstractSurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/AbstractSurface$AbstractSurfaceDestination */
    /*  @4 */	struct Java_com_sun_pisces_AbstractSurface * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_pisces_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Configuration */
};

struct Java_com_sun_pisces_Face {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Face */
    /*  @4 */	jobject_array * JVM_FIELD_CONST paths;
    /*  @8 */	jint_array * JVM_FIELD_CONST minX;
    /* @12 */	jint_array * JVM_FIELD_CONST minY;
    /* @16 */	jint_array * JVM_FIELD_CONST width;
    /* @20 */	jint_array * JVM_FIELD_CONST height;
    /* @24 */	jdouble scale;
};

struct Java_com_sun_pisces_GZIPInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/pisces/GZIPInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint count;
    /* @16 */	jint idx;
    /* @20 */	jint curByte;
    /* @24 */	jint curPos;
};

struct Java_com_sun_pisces_GradientColorMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/GradientColorMap */
    /*  @4 */	jint cycleMethod;
    /*  @8 */	jint_array * JVM_FIELD_CONST fractions;
    /* @12 */	jint_array * JVM_FIELD_CONST rgba;
    /* @16 */	jint_array * JVM_FIELD_CONST colors;
};

struct Java_com_sun_pisces_HuffmanTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/HuffmanTable */
    /*  @4 */	struct Java_com_sun_pisces_GZIPInputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST codeTable;
    /* @12 */	jint minLen;
};

struct Java_com_sun_pisces_NativeFinalizer_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeFinalizer$1 */
};

struct Java_com_sun_pisces_NativeFinalizer_00024RendererNativeFinalizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeFinalizer */
    /*  @4 */	struct Java_com_sun_pisces_NativeFinalization * JVM_FIELD_CONST guardedObject;
    /* com/sun/pisces/NativeFinalizer$RendererNativeFinalizer */
};

struct Java_com_sun_pisces_NativeFinalizer_00024SurfaceNativeFinalizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeFinalizer */
    /*  @4 */	struct Java_com_sun_pisces_NativeFinalization * JVM_FIELD_CONST guardedObject;
    /* com/sun/pisces/NativeFinalizer$SurfaceNativeFinalizer */
};

struct Java_com_sun_pisces_Paint {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Paint */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /*  @8 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST inverse;
};

struct Java_com_sun_pisces_PiscesFinalizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesFinalizer */
};

struct Java_com_sun_pisces_PiscesFont {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesFont */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	jint style;
    /* @12 */	jint size;
    /* @16 */	struct Java_com_sun_pisces_Face * JVM_FIELD_CONST face;
};

struct Java_com_sun_pisces_PiscesLibrary {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesLibrary */
};

struct Java_com_sun_pisces_PiscesMath {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesMath */
};

struct Java_com_sun_pisces_RendererBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/RendererBase */
    /*  @4 */	jint imageType;
};

struct Java_com_sun_ukit_jaxp_Attrs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Attrs */
    /*  @4 */	jobject_array * JVM_FIELD_CONST mItems;
    /*  @8 */	jchar mLength;
    /* @9 */	jbyte ___pad925;
    /* @10 */	jbyte ___pad926;
};

struct Java_com_sun_ukit_jaxp_Input {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Input */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST pubid;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST sysid;
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST src;
    /* @16 */	jchar_array * JVM_FIELD_CONST chars;
    /* @20 */	jint chLen;
    /* @24 */	jint chIdx;
    /* @28 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST next;
};

struct Java_com_sun_ukit_jaxp_Pair {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Pair */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	jchar_array * JVM_FIELD_CONST chars;
    /* @16 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST list;
    /* @20 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST next;
    /* @24 */	jchar id;
    /* @25 */	jbyte ___pad927;
    /* @26 */	jbyte ___pad928;
};

struct Java_com_sun_ukit_jaxp_Parser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParser */
    /* com/sun/ukit/jaxp/Parser */
    /*  @4 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mNoNS;
    /*  @8 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mXml;
    /* @12 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST mHand;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mEnt;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mPEnt;
    /* @24 */	jchar_array * JVM_FIELD_CONST mBuff;
    /* @28 */	jint mBuffIdx;
    /* @32 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mPref;
    /* @36 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mElm;
    /* @40 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mAttL;
    /* @44 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST mInp;
    /* @48 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST mDoc;
    /* @52 */	jchar_array * JVM_FIELD_CONST mChars;
    /* @56 */	jint mChLen;
    /* @60 */	jint mChIdx;
    /* @64 */	struct Java_com_sun_ukit_jaxp_Attrs * JVM_FIELD_CONST mAttrs;
    /* @68 */	jobject_array * JVM_FIELD_CONST mItems;
    /* @72 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mDltd;
    /* @76 */	jshort mSt;
    /* @78 */	jchar mESt;
    /* @80 */	jchar mAttrIdx;
    /* @82 */	jboolean mIsSAlone;
    /* @83 */	jboolean mIsNSAware;
};

struct Java_com_sun_ukit_jaxp_ReaderUTF8 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/ukit/jaxp/ReaderUTF8 */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST is;
};

struct Java_com_sun_ukit_jaxp_ReaderUTF16 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/ukit/jaxp/ReaderUTF16 */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST is;
    /* @16 */	jchar bo;
    /* @17 */	jbyte ___pad929;
    /* @18 */	jbyte ___pad930;
};

struct Java_com_sun_ukit_jaxp_ParserFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParserFactory */
    /*  @4 */	jboolean namespaceAware;
    /*  @5 */	jboolean validating;
    /* @6 */	jbyte ___pad931;
    /* @7 */	jbyte ___pad932;
    /* com/sun/ukit/jaxp/ParserFactory */
    /*  @8 */	jboolean namespaces;
    /*  @9 */	jboolean prefixes;
    /* @10 */	jbyte ___pad933;
    /* @11 */	jbyte ___pad934;
};

struct Java_org_xml_sax_SAXNotRecognizedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXNotRecognizedException */
};

struct Java_java_lang_ArrayStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArrayStoreException */
};

struct Java_java_lang_Character {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Character */
    /*  @4 */	jchar value;
    /* @5 */	jbyte ___pad935;
    /* @6 */	jbyte ___pad936;
};

struct Java_java_lang_FloatingDecimal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FloatingDecimal */
    /*  @4 */	jint decExponent;
    /*  @8 */	jchar_array * JVM_FIELD_CONST digits;
    /* @12 */	jint nDigits;
    /* @16 */	jint bigIntExp;
    /* @20 */	jint bigIntNBits;
    /* @24 */	jint roundDir;
    /* @28 */	jboolean isExceptional;
    /* @29 */	jboolean isNegative;
    /* @30 */	jboolean mustSetRoundDir;
    /* @31 */	jbyte ___pad937;
};

struct Java_java_lang_FDBigInt {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FDBigInt */
    /*  @4 */	jint nWords;
    /*  @8 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_java_lang_IllegalThreadStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/IllegalThreadStateException */
};

struct Java_java_lang_NegativeArraySizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NegativeArraySizeException */
};

struct Java_java_lang_UnsupportedOperationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/UnsupportedOperationException */
};

struct Java_java_rmi_Remote {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/rmi/Remote */
};

struct Java_java_util_EmptyStackException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/EmptyStackException */
};

struct Java_java_util_HashtableEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/HashtableEntry */
    /*  @4 */	jint hash;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /* @16 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST next;
};

struct Java_java_util_Hashtable_00024HashtableEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable$HashtableEnumerator */
    /*  @4 */	jint index;
    /*  @8 */	jobject_array * JVM_FIELD_CONST table;
    /* @12 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST entry;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST this_0440;
    /* @20 */	jboolean keys;
    /* @21 */	jbyte ___pad938;
    /* @22 */	jbyte ___pad939;
    /* @23 */	jbyte ___pad940;
};

struct Java_java_util_Random {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Random */
    /*  @4 */	jlong seed;
};

struct Java_java_util_VectorEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/VectorEnumerator */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST vector;
    /*  @8 */	jint count;
};

struct Java_javax_microedition_io_Connector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connector */
};

struct Java_javax_microedition_io_PushRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/PushRegistry */
};

struct Java_javax_microedition_io_StreamConnectionNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnectionNotifier */
};

struct Java_javax_microedition_io_ServerSocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ServerSocketConnection */
};

struct Java_javax_microedition_io_file_FileSystemEventHandlerBase_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase$1 */
};

struct Java_javax_microedition_io_file_FileSystemEventHandlerBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase */
};

struct Java_javax_microedition_io_file_FileSystemEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase */
    /* javax/microedition/io/file/FileSystemEventHandler */
};

struct Java_javax_microedition_io_file_FileSystemEventHandlerBase_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase$SecurityTrusted */
};

struct Java_javax_microedition_io_file_FileSystemListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemListener */
};

struct Java_javax_microedition_io_file_FileSystemRegistry_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemRegistry$1 */
    /*  @4 */	jobject_array * JVM_FIELD_CONST roots;
    /*  @8 */	jint index;
};

struct Java_javax_microedition_io_file_FileSystemRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemRegistry */
};

struct Java_javax_microedition_lcdui_AWFImages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AWFImages */
};

struct Java_javax_microedition_lcdui_AbstractImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageData */
};

struct Java_javax_microedition_lcdui_ImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageData */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	jbyte_array * JVM_FIELD_CONST pixelData;
    /* @16 */	jbyte_array * JVM_FIELD_CONST alphaData;
    /* @20 */	jint nativePixelData;
    /* @24 */	jint nativeAlphaData;
    /* @28 */	jboolean isMutable;
    /* @29 */	jbyte ___pad941;
    /* @30 */	jbyte ___pad942;
    /* @31 */	jbyte ___pad943;
};

struct Java_javax_microedition_lcdui_AbstractImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageDataFactory */
};

struct Java_javax_microedition_lcdui_AbstractKeyboardLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad944;
    /* @47 */	jbyte ___pad945;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad946;
    /* @91 */	jbyte ___pad947;
};

struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractKeyboardLayer$CommandReflector */
    /*  @4 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST loc;
    /*  @8 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST rem;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST lis;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST dis;
    /* @20 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* javax/microedition/lcdui/AbstractKeyboardLayer$MonitorThread */
    /* @28 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer * JVM_FIELD_CONST this_0440;
    /* @32 */	jboolean stopped;
    /* @33 */	jbyte ___pad948;
    /* @34 */	jbyte ___pad949;
    /* @35 */	jbyte ___pad950;
};

struct Java_javax_microedition_lcdui_CanvasLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	jlong lastTimeInvalidate;
    /* @12 */	struct Java_javax_microedition_lcdui_LFTimer * JVM_FIELD_CONST invalidateTimer;
    /* @16 */	jint INVALIDATE_REQUESTS_PERIOD;
    /* @20 */	jint INVALIDATE_REQUESTS_GRACE;
    /* @24 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @28 */	jint_array * JVM_FIELD_CONST viewport;
    /* @32 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @36 */	jint state;
    /* @40 */	jint stickyKeyMask;
    /* @44 */	jint currentKeyMask;
    /* @48 */	jboolean invalidScroll;
    /* @49 */	jboolean defferedSizeChange;
    /* @50 */	jboolean sawPointerPress;
    /* @51 */	jboolean sawKeyPress;
    /* @52 */	jboolean pendingInvalidate;
    /* @53 */	jbyte ___pad951;
    /* @54 */	jbyte ___pad952;
    /* @55 */	jbyte ___pad953;
    /* javax/microedition/lcdui/CanvasLFImpl */
    /* @56 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @60 */	struct Java_java_util_Vector * JVM_FIELD_CONST embeddedVideos;
    /* @64 */	jboolean needRepaintBackground;
    /* @65 */	jboolean isDisplayRotated;
    /* @66 */	jbyte ___pad954;
    /* @67 */	jbyte ___pad955;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST cachedInputSession;
    /* @64 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @68 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @76 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @80 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jint dhheight;
    /* @112 */	jint dhwidth;
    /* @116 */	jboolean editable;
    /* @117 */	jboolean firstTimeInTraverse;
    /* @118 */	jboolean pt_popupOpen;
    /* @119 */	jboolean showIMPopup;
    /* @120 */	jboolean usePreferredX;
    /* @121 */	jboolean showKeyboard;
    /* @122 */	jboolean pressedIn;
    /* @123 */	jboolean dhsizes_valid;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1AWF_1F {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad956;
    /* @47 */	jbyte ___pad957;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad958;
    /* @91 */	jbyte ___pad959;
    /* javax/microedition/lcdui/KeyboardLayer_AWF_F */
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardClose;
    /* @96 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardBack;
    /* @100 */	struct Java_javax_microedition_lcdui_VirtualKeyboard_1AWF_1F * JVM_FIELD_CONST vk;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /* @108 */	jint current_quad;
    /* @112 */	jint inputState;
    /* @116 */	jobject_array * JVM_FIELD_CONST keys;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1awf {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad960;
    /* @47 */	jbyte ___pad961;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad962;
    /* @91 */	jbyte ___pad963;
    /* javax/microedition/lcdui/KeyboardLayer_awf */
    /* @92 */	jint neededColumns;
    /* @96 */	jint neededRows;
    /* @100 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardClose;
    /* @104 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardBack;
    /* @108 */	struct Java_javax_microedition_lcdui_VirtualKeyboard_1awf * JVM_FIELD_CONST vk;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /* @116 */	jint inputState;
    /* @120 */	jobject_array * JVM_FIELD_CONST keys;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1danzeff {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad964;
    /* @47 */	jbyte ___pad965;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad966;
    /* @91 */	jbyte ___pad967;
    /* javax/microedition/lcdui/KeyboardLayer_RichEditing */
    /* @92 */	jint current_quad;
    /* @96 */	jboolean cached_ok;
    /* @97 */	jboolean cached_cancel;
    /* @98 */	jbyte ___pad968;
    /* @99 */	jbyte ___pad969;
    /* javax/microedition/lcdui/KeyboardLayer_danzeff */
    /* @100 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdOK;
    /* @104 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdCancel;
    /* @108 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdClear;
    /* @112 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdCopyAll;
    /* @116 */	struct Java_javax_microedition_lcdui_VirtualKeyboard_1danzeff * JVM_FIELD_CONST vk;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /* @124 */	jint inputState;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1qwert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad970;
    /* @47 */	jbyte ___pad971;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad972;
    /* @91 */	jbyte ___pad973;
    /* javax/microedition/lcdui/KeyboardLayer_qwert */
    /* @92 */	jint neededColumns;
    /* @96 */	jint neededRows;
    /* @100 */	struct Java_javax_microedition_lcdui_VirtualKeyboard_1qwert * JVM_FIELD_CONST vk;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /* @108 */	jint current_quad;
    /* @112 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardClose;
    /* @116 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keyboardCancel;
    /* @120 */	struct Java_com_pspkvm_midp_lcdui_vk_qwert_IMCandidateBar * JVM_FIELD_CONST candidateBar;
    /* @124 */	jobject_array * JVM_FIELD_CONST keys;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1semichordal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad974;
    /* @47 */	jbyte ___pad975;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad976;
    /* @91 */	jbyte ___pad977;
    /* javax/microedition/lcdui/KeyboardLayer_RichEditing */
    /* @92 */	jint current_quad;
    /* @96 */	jboolean cached_ok;
    /* @97 */	jboolean cached_cancel;
    /* @98 */	jbyte ___pad978;
    /* @99 */	jbyte ___pad979;
    /* javax/microedition/lcdui/KeyboardLayer_semichordal */
    /* @100 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdOK;
    /* @104 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdCancel;
    /* @108 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdToggleDisplay;
    /* @112 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdClear;
    /* @116 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdCopyAll;
    /* @120 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cmdRotateMap;
    /* @124 */	struct Java_javax_microedition_lcdui_VirtualKeyboard_1semichordal * JVM_FIELD_CONST vk;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /* @132 */	jint inputState;
};

struct Java_javax_microedition_lcdui_VirtualKeyboardListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardListener */
};

struct Java_javax_microedition_lcdui_VirtualKeyboard_1qwert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
    /* javax/microedition/lcdui/VirtualKeyboard_qwert */
    /*  @4 */	struct Java_javax_microedition_lcdui_VirtualKeyboardListener * JVM_FIELD_CONST vkl;
    /*  @8 */	jint kbX;
    /* @12 */	jint kbY;
    /* @16 */	jint kbWidth;
    /* @20 */	jint kbHeight;
    /* @24 */	jint fontW;
    /* @28 */	jint fontH;
    /* @32 */	jint buttonW;
    /* @36 */	jint buttonH;
    /* @40 */	jint fontWCenter;
    /* @44 */	jint fontHTop;
    /* @48 */	jint maxRows;
    /* @52 */	jint maxColumns;
    /* @56 */	jint fullColumns;
    /* @60 */	jint currentChar;
    /* @64 */	jint currentKeyboard;
    /* @68 */	jint candidateFieldHeight;
    /* @72 */	jobject_array * JVM_FIELD_CONST keys;
    /* @76 */	jint currentMeta;
    /* @80 */	jobject_array * JVM_FIELD_CONST metaKeys;
    /* @84 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST f;
    /* @88 */	jint PADDING;
    /* @92 */	jchar itemIndexWhenPressed;
    /* @94 */	jchar PRESS_OUT_OF_BOUNDS;
    /* @96 */	jboolean inMetaKeys;
    /* @97 */	jboolean inShift;
    /* @98 */	jboolean textKbd;
    /* @99 */	jboolean select_active;
};

struct Java_javax_microedition_lcdui_VirtualKeyboard_1semichordal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
    /* javax/microedition/lcdui/VirtualKeyboard_semichordal */
    /*  @4 */	struct Java_javax_microedition_lcdui_VirtualKeyboardListener * JVM_FIELD_CONST vkl;
    /*  @8 */	jint display_chords_mode;
    /* @12 */	jint chordal_offset;
    /* @16 */	jint live_dpad;
    /* @20 */	jint symbolDownLast;
    /* @24 */	jint chordDownLast;
    /* @28 */	jint currentKeyboard;
    /* @32 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST c_lock_img;
    /* @36 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST key_bg_img;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sel_img;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST roman_img;
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST greek_img;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST cyrillic_img;
    /* @56 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST symbols_img;
    /* @60 */	jobject_array * JVM_FIELD_CONST map_imgs;
    /* @64 */	struct Java_javax_microedition_lcdui_SC_1Keymap * JVM_FIELD_CONST crt_map;
    /* @68 */	jint crt_map_idx;
    /* @72 */	jint kwidth;
    /* @76 */	jint kheight;
    /* @80 */	jboolean caps_lock_set;
    /* @81 */	jboolean select_on;
    /* @82 */	jboolean ls_set;
    /* @83 */	jboolean rs_set;
    /* @84 */	jboolean analog_cursor;
    /* @85 */	jboolean symbols_transient;
    /* @86 */	jboolean symbols_up;
    /* @87 */	jbyte ___pad980;
};

struct Java_javax_microedition_lcdui_KeyboardLayer_1RichEditing {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad981;
    /* @47 */	jbyte ___pad982;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/AbstractKeyboardLayer */
    /* @56 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST tfContext;
    /* @60 */	struct Java_javax_microedition_lcdui_CanvasLFImpl * JVM_FIELD_CONST cvContext;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST backupString;
    /* @68 */	jchar_array * JVM_FIELD_CONST tmpchrarray;
    /* @72 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST ok_below;
    /* @76 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024CommandReflector * JVM_FIELD_CONST cancel_below;
    /* @80 */	jobject_array * JVM_FIELD_CONST creflectors;
    /* @84 */	struct Java_javax_microedition_lcdui_AbstractKeyboardLayer_00024MonitorThread * JVM_FIELD_CONST monitorThread;
    /* @88 */	jboolean open;
    /* @89 */	jboolean justOpened;
    /* @90 */	jbyte ___pad983;
    /* @91 */	jbyte ___pad984;
    /* javax/microedition/lcdui/KeyboardLayer_RichEditing */
    /* @92 */	jint current_quad;
    /* @96 */	jboolean cached_ok;
    /* @97 */	jboolean cached_cancel;
    /* @98 */	jbyte ___pad985;
    /* @99 */	jbyte ___pad986;
};

struct Java_javax_microedition_lcdui_VirtualKeyboard_1danzeff {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
    /* javax/microedition/lcdui/VirtualKeyboard_danzeff */
    /*  @4 */	struct Java_javax_microedition_lcdui_VirtualKeyboardListener * JVM_FIELD_CONST vkl;
    /*  @8 */	jint currentKeyboard;
    /* @12 */	struct Java_javax_microedition_lcdui_DZ_1Keymap * JVM_FIELD_CONST crt_map;
    /* @16 */	jint live_key;
    /* @20 */	jint cboard;
    /* @24 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sel_img;
    /* @28 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST dnzf_img;
    /* @32 */	jboolean select_on;
    /* @33 */	jboolean lshift;
    /* @34 */	jbyte ___pad987;
    /* @35 */	jbyte ___pad988;
};

struct Java_javax_microedition_lcdui_VirtualKeyboard_1AWF_1F {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
    /* javax/microedition/lcdui/VirtualKeyboard_AWF_F */
    /*  @4 */	struct Java_javax_microedition_lcdui_VirtualKeyboardListener * JVM_FIELD_CONST vkl;
    /*  @8 */	jint fontW;
    /* @12 */	jint fontH;
    /* @16 */	jint buttonW;
    /* @20 */	jint buttonH;
    /* @24 */	jint fontWCenter;
    /* @28 */	jint fontHTop;
    /* @32 */	jint maxRows;
    /* @36 */	jint maxColumns;
    /* @40 */	jint fullColumns;
    /* @44 */	jint currentChar;
    /* @48 */	jint currentKeyboard;
    /* @52 */	jobject_array * JVM_FIELD_CONST keys;
    /* @56 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST f;
    /* @60 */	jint mainKeyOffsetX;
    /* @64 */	jint mainKeyOffsetY;
    /* @68 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_IMCandidateBar * JVM_FIELD_CONST candidateBar;
    /* @72 */	jint sel_target;
    /* @76 */	jint num0_target;
    /* @80 */	jint PADDING;
    /* @84 */	jobject_array * JVM_FIELD_CONST kmap;
    /* @88 */	jobject_array * JVM_FIELD_CONST numericMap;
    /* @92 */	jobject_array * JVM_FIELD_CONST CnMap;
    /* @96 */	jobject_array * JVM_FIELD_CONST abcMap;
    /* @100 */	jobject_array * JVM_FIELD_CONST ABCMap;
    /* @104 */	jobject_array * JVM_FIELD_CONST symbolMap;
    /* @108 */	jobject_array * JVM_FIELD_CONST strokeMap;
    /* @112 */	jchar itemIndexWhenPressed;
    /* @114 */	jchar PRESS_OUT_OF_BOUNDS;
    /* @116 */	jboolean select_on;
    /* @117 */	jbyte ___pad989;
    /* @118 */	jbyte ___pad990;
    /* @119 */	jbyte ___pad991;
};

struct Java_javax_microedition_lcdui_VirtualKeyboard_1awf {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
    /* javax/microedition/lcdui/VirtualKeyboard_awf */
    /*  @4 */	struct Java_javax_microedition_lcdui_VirtualKeyboardListener * JVM_FIELD_CONST vkl;
    /*  @8 */	jint kbX;
    /* @12 */	jint kbY;
    /* @16 */	jint kbWidth;
    /* @20 */	jint kbHeight;
    /* @24 */	jint fontW;
    /* @28 */	jint fontH;
    /* @32 */	jint buttonW;
    /* @36 */	jint buttonH;
    /* @40 */	jint fontWCenter;
    /* @44 */	jint fontHTop;
    /* @48 */	jint maxRows;
    /* @52 */	jint maxColumns;
    /* @56 */	jint fullColumns;
    /* @60 */	jint currentChar;
    /* @64 */	jint currentKeyboard;
    /* @68 */	jint textfieldHeight;
    /* @72 */	jobject_array * JVM_FIELD_CONST keys;
    /* @76 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST f;
    /* @80 */	jint mainKeyOffsetX;
    /* @84 */	jint mainKeyOffsetY;
    /* @88 */	struct Java_com_pspkvm_midp_lcdui_vk_awf_IMCandidateBar * JVM_FIELD_CONST candidateBar;
    /* @92 */	jint sel_target;
    /* @96 */	jint num0_target;
    /* @100 */	jint PADDING;
    /* @104 */	jobject_array * JVM_FIELD_CONST kmap;
    /* @108 */	jobject_array * JVM_FIELD_CONST numericMap;
    /* @112 */	jobject_array * JVM_FIELD_CONST CnMap;
    /* @116 */	jobject_array * JVM_FIELD_CONST abcMap;
    /* @120 */	jobject_array * JVM_FIELD_CONST ABCMap;
    /* @124 */	jobject_array * JVM_FIELD_CONST symbolMap;
    /* @128 */	jobject_array * JVM_FIELD_CONST strokeMap;
    /* @132 */	jchar itemIndexWhenPressed;
    /* @134 */	jchar PRESS_OUT_OF_BOUNDS;
    /* @136 */	jboolean select_on;
    /* @137 */	jbyte ___pad992;
    /* @138 */	jbyte ___pad993;
    /* @139 */	jbyte ___pad994;
};

struct Java_javax_microedition_lcdui_Alert_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Alert$1 */
    /*  @4 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_AlertLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	jlong lastTimeInvalidate;
    /* @12 */	struct Java_javax_microedition_lcdui_LFTimer * JVM_FIELD_CONST invalidateTimer;
    /* @16 */	jint INVALIDATE_REQUESTS_PERIOD;
    /* @20 */	jint INVALIDATE_REQUESTS_GRACE;
    /* @24 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @28 */	jint_array * JVM_FIELD_CONST viewport;
    /* @32 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @36 */	jint state;
    /* @40 */	jint stickyKeyMask;
    /* @44 */	jint currentKeyMask;
    /* @48 */	jboolean invalidScroll;
    /* @49 */	jboolean defferedSizeChange;
    /* @50 */	jboolean sawPointerPress;
    /* @51 */	jboolean sawKeyPress;
    /* @52 */	jboolean pendingInvalidate;
    /* @53 */	jbyte ___pad995;
    /* @54 */	jbyte ___pad996;
    /* @55 */	jbyte ___pad997;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @56 */	jint_array * JVM_FIELD_CONST viewable;
    /* @60 */	jint vScrollPosition;
    /* @64 */	jint vScrollProportion;
    /* @68 */	jint lastScrollPosition;
    /* @72 */	jint lastScrollSize;
    /* @76 */	jboolean resetToTop;
    /* @77 */	jbyte ___pad998;
    /* @78 */	jbyte ___pad999;
    /* @79 */	jbyte ___pad1000;
    /* javax/microedition/lcdui/AlertLFImpl */
    /* @80 */	jint clipx;
    /* @84 */	jint clipy;
    /* @88 */	jint clipw;
    /* @92 */	jint cliph;
    /* @96 */	jint maxScroll;
    /* @100 */	jint totalHeight;
    /* @104 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
    /* @108 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @112 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @116 */	jint titlex;
    /* @120 */	jint titley;
    /* @124 */	jint titlew;
    /* @128 */	jint titleh;
    /* @132 */	jint icony;
    /* @136 */	jint iconw;
    /* @140 */	jint iconh;
    /* @144 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @148 */	jboolean isLayoutValid;
    /* @149 */	jbyte ___pad1001;
    /* @150 */	jbyte ___pad1002;
    /* @151 */	jbyte ___pad1003;
};

struct Java_javax_microedition_lcdui_AlertLFImpl_00024TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/AlertLFImpl$TimeoutTask */
    /* @28 */	struct Java_javax_microedition_lcdui_AlertLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_00024DisplayAccessImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayAccessImpl */
    /*  @4 */	jlong lastFlushTime;
    /* @12 */	struct Java_javax_microedition_lcdui_Display_00024DisplayAccessImpl_00024FlushTimer * JVM_FIELD_CONST flushTimer;
    /* @16 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_LFTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFTimer */
    /*  @4 */	jlong state;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST monitor;
};

struct Java_javax_microedition_lcdui_TickerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLF */
};

struct Java_javax_microedition_lcdui_DisplayableLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	jlong lastTimeInvalidate;
    /* @12 */	struct Java_javax_microedition_lcdui_LFTimer * JVM_FIELD_CONST invalidateTimer;
    /* @16 */	jint INVALIDATE_REQUESTS_PERIOD;
    /* @20 */	jint INVALIDATE_REQUESTS_GRACE;
    /* @24 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @28 */	jint_array * JVM_FIELD_CONST viewport;
    /* @32 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @36 */	jint state;
    /* @40 */	jint stickyKeyMask;
    /* @44 */	jint currentKeyMask;
    /* @48 */	jboolean invalidScroll;
    /* @49 */	jboolean defferedSizeChange;
    /* @50 */	jboolean sawPointerPress;
    /* @51 */	jboolean sawKeyPress;
    /* @52 */	jboolean pendingInvalidate;
    /* @53 */	jbyte ___pad1004;
    /* @54 */	jbyte ___pad1005;
    /* @55 */	jbyte ___pad1006;
};

struct Java_javax_microedition_lcdui_ScreenLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	jlong lastTimeInvalidate;
    /* @12 */	struct Java_javax_microedition_lcdui_LFTimer * JVM_FIELD_CONST invalidateTimer;
    /* @16 */	jint INVALIDATE_REQUESTS_PERIOD;
    /* @20 */	jint INVALIDATE_REQUESTS_GRACE;
    /* @24 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @28 */	jint_array * JVM_FIELD_CONST viewport;
    /* @32 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @36 */	jint state;
    /* @40 */	jint stickyKeyMask;
    /* @44 */	jint currentKeyMask;
    /* @48 */	jboolean invalidScroll;
    /* @49 */	jboolean defferedSizeChange;
    /* @50 */	jboolean sawPointerPress;
    /* @51 */	jboolean sawKeyPress;
    /* @52 */	jboolean pendingInvalidate;
    /* @53 */	jbyte ___pad1007;
    /* @54 */	jbyte ___pad1008;
    /* @55 */	jbyte ___pad1009;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @56 */	jint_array * JVM_FIELD_CONST viewable;
    /* @60 */	jint vScrollPosition;
    /* @64 */	jint vScrollProportion;
    /* @68 */	jint lastScrollPosition;
    /* @72 */	jint lastScrollSize;
    /* @76 */	jboolean resetToTop;
    /* @77 */	jbyte ___pad1010;
    /* @78 */	jbyte ___pad1011;
    /* @79 */	jbyte ___pad1012;
};

struct Java_javax_microedition_lcdui_MMHelperImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMHelper */
    /* javax/microedition/lcdui/MMHelperImpl */
};

struct Java_javax_microedition_lcdui_ItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint pendingIndex;
    /* @60 */	jint contentX;
    /* @64 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @68 */	jboolean traversedIn;
    /* @69 */	jboolean hasFocusWhenPressed;
    /* @70 */	jbyte ___pad1013;
    /* @71 */	jbyte ___pad1014;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_00024CGPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad1015;
    /* @47 */	jbyte ___pad1016;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/ScrollablePopupLayer */
    /* @56 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl$CGPopupLayer */
    /* @60 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST lf;
    /* @64 */	jint_array * JVM_FIELD_CONST viewport;
    /* @68 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST this_0440;
    /* @72 */	jboolean popupDrawnDown;
    /* @73 */	jboolean sbVisible;
    /* @74 */	jboolean sizeChanged;
    /* @75 */	jboolean popUpOpen;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint pendingIndex;
    /* @60 */	jint contentX;
    /* @64 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @68 */	jboolean traversedIn;
    /* @69 */	jboolean hasFocusWhenPressed;
    /* @70 */	jbyte ___pad1017;
    /* @71 */	jbyte ___pad1018;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl */
    /* @72 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_00024CGPopupLayer * JVM_FIELD_CONST popupLayer;
    /* @76 */	jint_array * JVM_FIELD_CONST viewable;
    /* @80 */	jboolean itemSelectedWhenPressed;
    /* @81 */	jbyte ___pad1019;
    /* @82 */	jbyte ___pad1020;
    /* @83 */	jbyte ___pad1021;
};

struct Java_javax_microedition_lcdui_Clipboard {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Clipboard */
};

struct Java_javax_microedition_lcdui_CustomItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/CustomItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItem * JVM_FIELD_CONST customItem;
    /* @48 */	jint preferredHeight;
    /* @52 */	jint preferredWidth;
    /* @56 */	jint minimumHeight;
    /* @60 */	jint minimumWidth;
};

struct Java_javax_microedition_lcdui_DateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad1022;
    /* @47 */	jbyte ___pad1023;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @56 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @60 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @64 */	jint mode;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @76 */	jobject_array * JVM_FIELD_CONST commands;
    /* @80 */	jint nextX;
    /* @84 */	jint nextY;
    /* @88 */	jint lastDay;
    /* @92 */	jint dayOffset;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @108 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @112 */	jint focusOn;
    /* @116 */	jint hilightedDate;
    /* @120 */	jint selectedDate;
    /* @124 */	jint popupWidth;
    /* @128 */	jint popupHeight;
    /* @132 */	jint elementWidth;
    /* @136 */	jint elementHeight;
    /* @140 */	jint timeComponentsOffset;
    /* @144 */	jint calendarTopLimit;
    /* @148 */	jint calendarBottomLimit;
    /* @152 */	jint calendarRightLimit;
    /* @156 */	jint dateHilightX;
    /* @160 */	jint dateHilightY;
    /* @164 */	jint PRESS_OUT_OF_BOUNDS;
    /* @168 */	jint itemIndexWhenPressed;
    /* @172 */	jint_array * JVM_FIELD_CONST month_bounds;
    /* @176 */	jint_array * JVM_FIELD_CONST year_bounds;
    /* @180 */	jint_array * JVM_FIELD_CONST hours_bounds;
    /* @184 */	jint_array * JVM_FIELD_CONST minutes_bounds;
    /* @188 */	jint_array * JVM_FIELD_CONST calendar_bounds;
    /* @192 */	jint_array * JVM_FIELD_CONST ampm_bounds;
    /* @196 */	jint pressedDate;
    /* @200 */	jboolean initialized;
    /* @201 */	jboolean amSelected;
    /* @202 */	jboolean amHilighted;
    /* @203 */	jboolean popUpOpen;
    /* @204 */	jboolean sizeChanged;
    /* @205 */	jboolean isIitialized;
    /* @206 */	jbyte ___pad1024;
    /* @207 */	jbyte ___pad1025;
};

struct Java_javax_microedition_lcdui_DEPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad1026;
    /* @47 */	jbyte ___pad1027;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/ScrollablePopupLayer */
    /* @56 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* javax/microedition/lcdui/DEPopupLayer */
    /* @60 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @64 */	jint_array * JVM_FIELD_CONST viewport;
    /* @68 */	jint numElements;
    /* @72 */	jobject_array * JVM_FIELD_CONST elements;
    /* @76 */	jint elementWidth;
    /* @80 */	jint elementHeight;
    /* @84 */	jint elementsToFit;
    /* @88 */	jint startIndex;
    /* @92 */	jint endIndex;
    /* @96 */	jint hilightedIndex;
    /* @100 */	jint selectedIndex;
    /* @104 */	struct Java_javax_microedition_lcdui_ScreenLFImpl * JVM_FIELD_CONST sLF;
    /* @108 */	jint itemIndexWhenPressed;
    /* @112 */	jboolean open;
    /* @113 */	jboolean sbVisible;
    /* @114 */	jboolean circularTraversal;
    /* @115 */	jbyte ___pad1028;
};

struct Java_javax_microedition_lcdui_SC_1Keys {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
};

struct Java_javax_microedition_lcdui_DZ_1Keymap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/DZ_Keymap */
};

struct Java_javax_microedition_lcdui_DZ_1Keymap_1Roman {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/DZ_Keymap */
    /* javax/microedition/lcdui/DZ_Keymap_Roman */
};

struct Java_javax_microedition_lcdui_DateFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/DateFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_DateField * JVM_FIELD_CONST df;
    /* @48 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @52 */	jint mode;
    /* @56 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @60 */	jboolean traversedIn;
    /* @61 */	jbyte ___pad1029;
    /* @62 */	jbyte ___pad1030;
    /* @63 */	jbyte ___pad1031;
};

struct Java_javax_microedition_lcdui_DateField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/DateField */
    /* @52 */	struct Java_javax_microedition_lcdui_DateFieldLF * JVM_FIELD_CONST dateFieldLF;
    /* @56 */	jint mode;
    /* @60 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @64 */	jboolean initialized;
    /* @65 */	jbyte ___pad1032;
    /* @66 */	jbyte ___pad1033;
    /* @67 */	jbyte ___pad1034;
};

struct Java_javax_microedition_lcdui_DateFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DateFieldLF */
};

struct Java_javax_microedition_lcdui_Diacriticals {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Diacriticals */
};

struct Java_javax_microedition_lcdui_Display_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$1 */
};

struct Java_javax_microedition_lcdui_Display_00024ChameleonTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$ChameleonTunnel */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_00024DisplayAccessImpl_00024FlushTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFTimer */
    /*  @4 */	jlong state;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST monitor;
    /* javax/microedition/lcdui/Display$DisplayAccessImpl$FlushTimer */
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST d;
    /* @20 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST offscreenBuffer;
    /* @24 */	jint x;
    /* @28 */	jint y;
    /* @32 */	jint width;
    /* @36 */	jint height;
    /* @40 */	struct Java_javax_microedition_lcdui_Display_00024DisplayAccessImpl * JVM_FIELD_CONST this_0441;
};

struct Java_javax_microedition_lcdui_Display_00024DisplayEventConsumerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayEventConsumerImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_00024ForegroundEventConsumerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$ForegroundEventConsumerImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_DisplayEventHandlerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayEventHandlerImpl */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_lcdui_ForegroundController * JVM_FIELD_CONST foregroundController;
    /* @12 */	struct Java_com_sun_midp_lcdui_DisplayAccess * JVM_FIELD_CONST preemptingDisplay;
    /* @16 */	jboolean preemptionDoneCalled;
    /* @17 */	jbyte ___pad1035;
    /* @18 */	jbyte ___pad1036;
    /* @19 */	jbyte ___pad1037;
};

struct Java_javax_microedition_lcdui_Display_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$SecurityTrusted */
};

struct Java_javax_microedition_lcdui_GraphicsAccessImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/GraphicsAccessImpl */
};

struct Java_javax_microedition_lcdui_VirtualKeyboardException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/lcdui/VirtualKeyboardException */
};

struct Java_javax_microedition_lcdui_DisplayableLFImpl_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFTimer */
    /*  @4 */	jlong state;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST monitor;
    /* javax/microedition/lcdui/DisplayableLFImpl$1 */
    /* @16 */	struct Java_javax_microedition_lcdui_DisplayableLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_LayoutManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LayoutManager */
    /*  @4 */	jint_array * JVM_FIELD_CONST sizingBox;
    /*  @8 */	jint viewportWidth;
    /* @12 */	jint viewportHeight;
};

struct Java_javax_microedition_lcdui_FormLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	jlong lastTimeInvalidate;
    /* @12 */	struct Java_javax_microedition_lcdui_LFTimer * JVM_FIELD_CONST invalidateTimer;
    /* @16 */	jint INVALIDATE_REQUESTS_PERIOD;
    /* @20 */	jint INVALIDATE_REQUESTS_GRACE;
    /* @24 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @28 */	jint_array * JVM_FIELD_CONST viewport;
    /* @32 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @36 */	jint state;
    /* @40 */	jint stickyKeyMask;
    /* @44 */	jint currentKeyMask;
    /* @48 */	jboolean invalidScroll;
    /* @49 */	jboolean defferedSizeChange;
    /* @50 */	jboolean sawPointerPress;
    /* @51 */	jboolean sawKeyPress;
    /* @52 */	jboolean pendingInvalidate;
    /* @53 */	jbyte ___pad1038;
    /* @54 */	jbyte ___pad1039;
    /* @55 */	jbyte ___pad1040;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @56 */	jint_array * JVM_FIELD_CONST viewable;
    /* @60 */	jint vScrollPosition;
    /* @64 */	jint vScrollProportion;
    /* @68 */	jint lastScrollPosition;
    /* @72 */	jint lastScrollSize;
    /* @76 */	jboolean resetToTop;
    /* @77 */	jbyte ___pad1041;
    /* @78 */	jbyte ___pad1042;
    /* @79 */	jbyte ___pad1043;
    /* javax/microedition/lcdui/FormLFImpl */
    /* @80 */	jint traverseIndex;
    /* @84 */	struct Java_javax_microedition_lcdui_ItemLFImpl * JVM_FIELD_CONST lastTraverseItem;
    /* @88 */	jint_array * JVM_FIELD_CONST visRect;
    /* @92 */	jobject_array * JVM_FIELD_CONST itemLFs;
    /* @96 */	jint numOfLFs;
    /* @100 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST pendingCurrentItem;
    /* @104 */	jint pointerX;
    /* @108 */	jint pointerY;
    /* @112 */	jboolean itemTraverse;
    /* @113 */	jboolean itemsModified;
    /* @114 */	jboolean pointerPressed;
    /* @115 */	jboolean scrollInitialized;
    /* @116 */	jboolean firstShown;
    /* @117 */	jboolean keepFocusOnTheScreen;
    /* @118 */	jboolean pointerIndicator;
    /* @119 */	jbyte ___pad1044;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/GaugeLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST gauge;
    /* @48 */	struct Java_javax_microedition_lcdui_GaugeLFImpl_00024GaugeUpdateTask * JVM_FIELD_CONST updateHelper;
    /* @52 */	jint percentWidth;
    /* @56 */	jint percentHeight;
    /* @60 */	jint focusBtn;
    /* @64 */	jint_array * JVM_FIELD_CONST percentLoc;
    /* @68 */	jint nextFrame;
    /* @72 */	jint pointerArea;
    /* @76 */	jboolean initialTraverse;
    /* @77 */	jboolean intTraverse;
    /* @78 */	jbyte ___pad1045;
    /* @79 */	jbyte ___pad1046;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl_00024GaugeUpdateTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/GaugeLFImpl$GaugeUpdateTask */
    /* @28 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST myGaugeLF;
    /* @32 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_ImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageDataFactory */
};

struct Java_javax_microedition_lcdui_ImageItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/ImageItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ImageItem * JVM_FIELD_CONST imgItem;
    /* @48 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_Imgs_1misc {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Imgs_misc */
};

struct Java_javax_microedition_lcdui_Imgs_1qw_1clip {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Imgs_qw_clip */
};

struct Java_javax_microedition_lcdui_KeyConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/KeyConverter */
};

struct Java_javax_microedition_lcdui_Spacer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint userPreferredWidth;
    /* @44 */	jint lockedHeight;
    /* @48 */	jint userPreferredHeight;
    /* javax/microedition/lcdui/Spacer */
    /* @52 */	struct Java_javax_microedition_lcdui_SpacerLF * JVM_FIELD_CONST spacerLF;
    /* @56 */	jint width;
    /* @60 */	jint height;
};

struct Java_javax_microedition_lcdui_SpacerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SpacerLF */
};

struct Java_javax_microedition_lcdui_LFFactoryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
    /* javax/microedition/lcdui/LFFactoryImpl */
};

struct Java_javax_microedition_lcdui_StringItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/StringItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_StringItem * JVM_FIELD_CONST strItem;
    /* @48 */	jint appearanceMode;
    /* @52 */	jboolean skipTraverse;
    /* @53 */	jbyte ___pad1047;
    /* @54 */	jbyte ___pad1048;
    /* @55 */	jbyte ___pad1049;
};

struct Java_javax_microedition_lcdui_SpacerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/SpacerLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Spacer * JVM_FIELD_CONST spacer;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_00024TextScrollPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TextScrollPainter */
    /* @28 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLFImpl$1 */
};

struct Java_javax_microedition_lcdui_TextBoxLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jboolean itemWasPressed;
    /* @43 */	jboolean isInternalCycle;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST cachedInputSession;
    /* @64 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @68 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @76 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @80 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_00024TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jint dhheight;
    /* @112 */	jint dhwidth;
    /* @116 */	jboolean editable;
    /* @117 */	jboolean firstTimeInTraverse;
    /* @118 */	jboolean pt_popupOpen;
    /* @119 */	jboolean showIMPopup;
    /* @120 */	jboolean usePreferredX;
    /* @121 */	jboolean showKeyboard;
    /* @122 */	jboolean pressedIn;
    /* @123 */	jboolean dhsizes_valid;
    /* javax/microedition/lcdui/TextBoxLFImpl */
    /* @124 */	struct Java_com_sun_midp_lcdui_TextInfo * JVM_FIELD_CONST myInfo;
    /* @128 */	jint lheight;
    /* @132 */	jboolean scrollInitialized;
    /* @133 */	jbyte ___pad1050;
    /* @134 */	jbyte ___pad1051;
    /* @135 */	jbyte ___pad1052;
};

struct Java_javax_microedition_lcdui_TickerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST owner;
    /*  @8 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
};

struct Java_javax_microedition_lcdui_LongArrayHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LongArrayHandler */
};

struct Java_javax_microedition_lcdui_MiniDateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /*  @8 */	jint_array * JVM_FIELD_CONST boundsCopy;
    /* @12 */	jint_array * JVM_FIELD_CONST dirtyBoundsCopy;
    /* @16 */	jint bgColor;
    /* @20 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint_array * JVM_FIELD_CONST bounds;
    /* @32 */	jint graphicsColor;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @40 */	jboolean dirty;
    /* @41 */	jboolean transparent;
    /* @42 */	jboolean visible;
    /* @43 */	jboolean supportsInput;
    /* @44 */	jboolean opaque;
    /* @45 */	jboolean tileBG;
    /* @46 */	jbyte ___pad1053;
    /* @47 */	jbyte ___pad1054;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @48 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @56 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @60 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @64 */	jint mode;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @76 */	jobject_array * JVM_FIELD_CONST commands;
    /* @80 */	jint nextX;
    /* @84 */	jint nextY;
    /* @88 */	jint lastDay;
    /* @92 */	jint dayOffset;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @108 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @112 */	jint focusOn;
    /* @116 */	jint hilightedDate;
    /* @120 */	jint selectedDate;
    /* @124 */	jint popupWidth;
    /* @128 */	jint popupHeight;
    /* @132 */	jint elementWidth;
    /* @136 */	jint elementHeight;
    /* @140 */	jint timeComponentsOffset;
    /* @144 */	jint calendarTopLimit;
    /* @148 */	jint calendarBottomLimit;
    /* @152 */	jint calendarRightLimit;
    /* @156 */	jint dateHilightX;
    /* @160 */	jint dateHilightY;
    /* @164 */	jint PRESS_OUT_OF_BOUNDS;
    /* @168 */	jint itemIndexWhenPressed;
    /* @172 */	jint_array * JVM_FIELD_CONST month_bounds;
    /* @176 */	jint_array * JVM_FIELD_CONST year_bounds;
    /* @180 */	jint_array * JVM_FIELD_CONST hours_bounds;
    /* @184 */	jint_array * JVM_FIELD_CONST minutes_bounds;
    /* @188 */	jint_array * JVM_FIELD_CONST calendar_bounds;
    /* @192 */	jint_array * JVM_FIELD_CONST ampm_bounds;
    /* @196 */	jint pressedDate;
    /* @200 */	jboolean initialized;
    /* @201 */	jboolean amSelected;
    /* @202 */	jboolean amHilighted;
    /* @203 */	jboolean popUpOpen;
    /* @204 */	jboolean sizeChanged;
    /* @205 */	jboolean isIitialized;
    /* @206 */	jbyte ___pad1055;
    /* @207 */	jbyte ___pad1056;
    /* javax/microedition/lcdui/MiniDateEditor */
    /* @208 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST dayPopup;
};

struct Java_javax_microedition_lcdui_SC_1Keymap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/SC_Keymap */
};

struct Java_javax_microedition_lcdui_SC_1Keymap_1Cyrillic {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/SC_Keymap */
    /* javax/microedition/lcdui/SC_Keymap_Cyrillic */
};

struct Java_javax_microedition_lcdui_SC_1Keymap_1Greek {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/SC_Keymap */
    /* javax/microedition/lcdui/SC_Keymap_Greek */
};

struct Java_javax_microedition_lcdui_SC_1Keymap_1NumericSymbolic_1Roman {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/SC_Keymap */
    /* javax/microedition/lcdui/SC_Keymap_NumericSymbolic_Roman */
};

struct Java_javax_microedition_lcdui_SC_1Keymap_1Roman {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SC_Keys */
    /* javax/microedition/lcdui/SC_Keymap */
    /* javax/microedition/lcdui/SC_Keymap_Roman */
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_00024TimerKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TimerKey */
    /* @28 */	jint key;
    /* @32 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TextFieldNav {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldNav */
};

struct Java_javax_microedition_lcdui_VirtualKeyboardInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardInterface */
};

struct Java_javax_microedition_lcdui_VirtualKeyboardMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/VirtualKeyboardMap */
    /*  @4 */	jint buttonW;
    /*  @8 */	jint buttonH;
    /* @12 */	jint fontWCenter;
    /* @16 */	jint fontHTop;
    /* @20 */	jint keyMapW;
    /* @24 */	jint keyMapH;
    /* @28 */	jint keyMapX;
    /* @32 */	jint keyMapY;
    /* @36 */	jint keyMapType;
    /* @40 */	jint keyIndex;
    /* @44 */	jint keyMapOffsetX;
    /* @48 */	jint keyMapOffsetY;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST inputKey;
    /* @56 */	jobject_array * JVM_FIELD_CONST keyName;
    /* @60 */	jint curActiveKey;
    /* @64 */	jobject_array * JVM_FIELD_CONST keyGuidImage;
};

struct Java_javax_microedition_lcdui_game_GameAccessImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/GameAccessImpl */
};

struct Java_javax_microedition_lcdui_game_Layer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad1057;
    /* @22 */	jbyte ___pad1058;
    /* @23 */	jbyte ___pad1059;
};

struct Java_javax_microedition_lcdui_game_LayerManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/LayerManager */
    /*  @4 */	jint nlayers;
    /*  @8 */	jobject_array * JVM_FIELD_CONST component;
    /* @12 */	jint viewX;
    /* @16 */	jint viewY;
    /* @20 */	jint viewWidth;
    /* @24 */	jint viewHeight;
};

struct Java_javax_microedition_lcdui_game_Sprite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad1060;
    /* @22 */	jbyte ___pad1061;
    /* @23 */	jbyte ___pad1062;
    /* javax/microedition/lcdui/game/Sprite */
    /* @24 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @28 */	jint numberFrames;
    /* @32 */	jint_array * JVM_FIELD_CONST frameCoordsX;
    /* @36 */	jint_array * JVM_FIELD_CONST frameCoordsY;
    /* @40 */	jint srcFrameWidth;
    /* @44 */	jint srcFrameHeight;
    /* @48 */	jint_array * JVM_FIELD_CONST frameSequence;
    /* @52 */	jint sequenceIndex;
    /* @56 */	jint dRefX;
    /* @60 */	jint dRefY;
    /* @64 */	jint collisionRectX;
    /* @68 */	jint collisionRectY;
    /* @72 */	jint collisionRectWidth;
    /* @76 */	jint collisionRectHeight;
    /* @80 */	jint t_currentTransformation;
    /* @84 */	jint t_collisionRectX;
    /* @88 */	jint t_collisionRectY;
    /* @92 */	jint t_collisionRectWidth;
    /* @96 */	jint t_collisionRectHeight;
    /* @100 */	jboolean customSequenceDefined;
    /* @101 */	jbyte ___pad1063;
    /* @102 */	jbyte ___pad1064;
    /* @103 */	jbyte ___pad1065;
};

struct Java_javax_microedition_lcdui_game_TiledLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad1066;
    /* @22 */	jbyte ___pad1067;
    /* @23 */	jbyte ___pad1068;
    /* javax/microedition/lcdui/game/TiledLayer */
    /* @24 */	jint cellHeight;
    /* @28 */	jint cellWidth;
    /* @32 */	jint rows;
    /* @36 */	jint columns;
    /* @40 */	jobject_array * JVM_FIELD_CONST cellMatrix;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @48 */	jint numberOfTiles;
    /* @52 */	jint_array * JVM_FIELD_CONST tileSetX;
    /* @56 */	jint_array * JVM_FIELD_CONST tileSetY;
    /* @60 */	jint_array * JVM_FIELD_CONST anim_to_static;
    /* @64 */	jint numOfAnimTiles;
};

struct Java_javax_microedition_location_Landmark {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/Landmark */
    /*  @4 */	struct Java_com_sun_j2me_location_LandmarkImpl * JVM_FIELD_CONST landmark;
};

struct Java_javax_microedition_location_LandmarkStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/location/LandmarkStore */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST storeName;
};

struct Java_javax_microedition_m2g_ScalableGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableGraphics */
    /*  @4 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST g;
    /*  @8 */	struct Java_com_sun_pisces_GraphicsSurfaceDestination * JVM_FIELD_CONST gsd;
    /* @12 */	jint qualityMode;
    /* @16 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @20 */	jfloat alpha;
    /* @24 */	struct Java_com_sun_pisces_NativeSurface * JVM_FIELD_CONST offscreen;
    /* @28 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @32 */	jint offscreenWidth;
    /* @36 */	jint offscreenHeight;
    /* @40 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
};

struct Java_javax_microedition_m3g_Object3D {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
};

struct Java_javax_microedition_m3g_KeyframeSequence {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/KeyframeSequence */
    /* @20 */	jint numKeyframes;
    /* @24 */	jint numComponents;
    /* @28 */	jint interpolation;
    /* @32 */	jint_array * JVM_FIELD_CONST times;
    /* @36 */	jfloat_array * JVM_FIELD_CONST values;
    /* @40 */	jint duration;
    /* @44 */	jint repeatMode;
    /* @48 */	jint rangeFirst;
    /* @52 */	jint rangeLast;
};

struct Java_javax_microedition_m3g_AnimationController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/AnimationController */
    /* @20 */	jfloat speed;
    /* @24 */	jfloat weight;
    /* @28 */	jint activeStart;
    /* @32 */	jint activeEnd;
    /* @36 */	jfloat refSequenceTime;
    /* @40 */	jint refWorldTime;
};

struct Java_javax_microedition_m3g_AnimationTrack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/AnimationTrack */
    /* @20 */	struct Java_javax_microedition_m3g_KeyframeSequence * JVM_FIELD_CONST sequence;
    /* @24 */	jint property;
    /* @28 */	struct Java_javax_microedition_m3g_AnimationController * JVM_FIELD_CONST controller;
};

struct Java_javax_microedition_m3g_CompositingMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/CompositingMode */
    /* @20 */	jint blending;
    /* @24 */	jfloat alphaThreshold;
    /* @28 */	jfloat depthOffsetFactor;
    /* @32 */	jfloat depthOffsetUnits;
    /* @36 */	jboolean depthTest;
    /* @37 */	jboolean depthWrite;
    /* @38 */	jboolean colorWrite;
    /* @39 */	jboolean alphaWrite;
};

struct Java_javax_microedition_m3g_Fog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Fog */
    /* @20 */	jint mode;
    /* @24 */	jint color;
    /* @28 */	jfloat density;
    /* @32 */	jfloat near;
    /* @36 */	jfloat far;
};

struct Java_javax_microedition_m3g_Material {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Material */
    /* @20 */	jint ambient;
    /* @24 */	jint diffuse;
    /* @28 */	jint emissive;
    /* @32 */	jint specular;
    /* @36 */	jfloat shininess;
    /* @40 */	jboolean vertexColorTracking;
    /* @41 */	jbyte ___pad1069;
    /* @42 */	jbyte ___pad1070;
    /* @43 */	jbyte ___pad1071;
};

struct Java_javax_microedition_m3g_PolygonMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/PolygonMode */
    /* @20 */	jint culling;
    /* @24 */	jint winding;
    /* @28 */	jint shading;
    /* @32 */	jboolean twoSidedLighting;
    /* @33 */	jboolean localCameraLighting;
    /* @34 */	jboolean perspectiveCorrection;
    /* @35 */	jbyte ___pad1072;
};

struct Java_javax_microedition_m3g_Texture2D {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Texture2D */
    /* @40 */	struct Java_javax_microedition_m3g_Image2D * JVM_FIELD_CONST image;
    /* @44 */	jint blending;
    /* @48 */	jint blendColor;
    /* @52 */	jint wrapS;
    /* @56 */	jint wrapT;
    /* @60 */	jint levelFilter;
    /* @64 */	jint imageFilter;
};

struct Java_javax_microedition_m3g_Appearance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Appearance */
    /* @20 */	jint layer;
    /* @24 */	struct Java_javax_microedition_m3g_CompositingMode * JVM_FIELD_CONST compositingMode;
    /* @28 */	struct Java_javax_microedition_m3g_Fog * JVM_FIELD_CONST fog;
    /* @32 */	struct Java_javax_microedition_m3g_PolygonMode * JVM_FIELD_CONST polygonMode;
    /* @36 */	struct Java_javax_microedition_m3g_Material * JVM_FIELD_CONST material;
    /* @40 */	jobject_array * JVM_FIELD_CONST textures;
};

struct Java_javax_microedition_m3g_Image2D {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Image2D */
    /* @20 */	jint format;
    /* @24 */	jint width;
    /* @28 */	jint height;
    /* @32 */	jint_array * JVM_FIELD_CONST argb;
    /* @36 */	jboolean __reserved__mutable;
    /* @37 */	jbyte ___pad1073;
    /* @38 */	jbyte ___pad1074;
    /* @39 */	jbyte ___pad1075;
};

struct Java_javax_microedition_m3g_Background {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Background */
    /* @20 */	jint color;
    /* @24 */	struct Java_javax_microedition_m3g_Image2D * JVM_FIELD_CONST image;
    /* @28 */	jint imageModeX;
    /* @32 */	jint imageModeY;
    /* @36 */	jint cropX;
    /* @40 */	jint cropY;
    /* @44 */	jint cropWidth;
    /* @48 */	jint cropHeight;
    /* @52 */	jboolean colorClear;
    /* @53 */	jboolean depthClear;
    /* @54 */	jbyte ___pad1076;
    /* @55 */	jbyte ___pad1077;
};

struct Java_javax_microedition_m3g_Transform {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Transform */
    /*  @4 */	jfloat_array * JVM_FIELD_CONST m;
};

struct Java_javax_microedition_m3g_Node {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1078;
    /* @71 */	jbyte ___pad1079;
};

struct Java_javax_microedition_m3g_Transformable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
};

struct Java_javax_microedition_m3g_Camera {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST __dup1__generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1080;
    /* @71 */	jbyte ___pad1081;
    /* javax/microedition/m3g/Camera */
    /* @72 */	jint type;
    /* @76 */	jfloat fovy;
    /* @80 */	jfloat aspect;
    /* @84 */	jfloat near;
    /* @88 */	jfloat far;
    /* @92 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
};

struct Java_javax_microedition_m3g_Graphics3D_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Graphics3D$1 */
};

struct Java_javax_microedition_m3g_VertexBuffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/VertexBuffer */
    /* @20 */	struct Java_javax_microedition_m3g_VertexArray * JVM_FIELD_CONST positions;
    /* @24 */	jfloat posScale;
    /* @28 */	jfloat_array * JVM_FIELD_CONST posBias;
    /* @32 */	struct Java_javax_microedition_m3g_VertexArray * JVM_FIELD_CONST normals;
    /* @36 */	struct Java_javax_microedition_m3g_VertexArray * JVM_FIELD_CONST colors;
    /* @40 */	jobject_array * JVM_FIELD_CONST texCoords;
    /* @44 */	jfloat_array * JVM_FIELD_CONST texScale;
    /* @48 */	jobject_array * JVM_FIELD_CONST texBias;
    /* @52 */	jint defaultColor;
};

struct Java_javax_microedition_m3g_IndexBuffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/IndexBuffer */
    /* @20 */	jint_array * JVM_FIELD_CONST indices;
    /* @24 */	jint_array * JVM_FIELD_CONST stripLengths;
    /* @28 */	jint firstIndex;
};

struct Java_javax_microedition_m3g_Graphics3D_00024Renderable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Graphics3D$Renderable */
    /*  @4 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST node;
    /*  @8 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST vb;
    /* @12 */	struct Java_javax_microedition_m3g_IndexBuffer * JVM_FIELD_CONST ib;
    /* @16 */	struct Java_javax_microedition_m3g_Appearance * JVM_FIELD_CONST ap;
    /* @20 */	jfloat_array * JVM_FIELD_CONST toWorld;
    /* @24 */	jfloat alpha;
    /* @28 */	jint layer;
    /* @32 */	jint scope;
};

struct Java_javax_microedition_m3g_Graphics3D {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Graphics3D */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST target;
    /*  @8 */	jint hints;
    /* @12 */	jint vpX;
    /* @16 */	jint vpY;
    /* @20 */	jint vpW;
    /* @24 */	jint vpH;
    /* @28 */	jfloat depthNear;
    /* @32 */	jfloat depthFar;
    /* @36 */	struct Java_javax_microedition_m3g_Camera * JVM_FIELD_CONST camera;
    /* @40 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST cameraToWorld;
    /* @44 */	jfloat_array * JVM_FIELD_CONST view;
    /* @48 */	jfloat_array * JVM_FIELD_CONST projection;
    /* @52 */	jobject_array * JVM_FIELD_CONST lights;
    /* @56 */	jobject_array * JVM_FIELD_CONST lightTransforms;
    /* @60 */	jint lightCount;
    /* @64 */	jint_array * JVM_FIELD_CONST ip;
    /* @68 */	jfloat_array * JVM_FIELD_CONST fp;
    /* @72 */	jobject_array * JVM_FIELD_CONST arrays;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST renderables;
    /* @80 */	jfloat_array * JVM_FIELD_CONST tmp16;
    /* @84 */	jfloat_array * JVM_FIELD_CONST spritePos;
    /* @88 */	jfloat_array * JVM_FIELD_CONST spriteTc;
    /* @92 */	jint_array * JVM_FIELD_CONST spriteStrip;
    /* @96 */	jboolean depthEnabled;
    /* @97 */	jbyte ___pad1082;
    /* @98 */	jbyte ___pad1083;
    /* @99 */	jbyte ___pad1084;
};

struct Java_javax_microedition_m3g_Light {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1085;
    /* @71 */	jbyte ___pad1086;
    /* javax/microedition/m3g/Light */
    /* @72 */	jint mode;
    /* @76 */	jint color;
    /* @80 */	jfloat intensity;
    /* @84 */	jfloat attConstant;
    /* @88 */	jfloat attLinear;
    /* @92 */	jfloat attQuadratic;
    /* @96 */	jfloat spotAngle;
    /* @100 */	jfloat spotExponent;
};

struct Java_javax_microedition_m3g_Sprite3D {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1087;
    /* @71 */	jbyte ___pad1088;
    /* javax/microedition/m3g/Sprite3D */
    /* @72 */	struct Java_javax_microedition_m3g_Image2D * JVM_FIELD_CONST image;
    /* @76 */	struct Java_javax_microedition_m3g_Appearance * JVM_FIELD_CONST appearance;
    /* @80 */	jint cropX;
    /* @84 */	jint cropY;
    /* @88 */	jint cropWidth;
    /* @92 */	jint cropHeight;
    /* @96 */	jboolean scaled;
    /* @97 */	jbyte ___pad1089;
    /* @98 */	jbyte ___pad1090;
    /* @99 */	jbyte ___pad1091;
};

struct Java_javax_microedition_m3g_VertexArray {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/VertexArray */
    /* @20 */	jint numVertices;
    /* @24 */	jint numComponents;
    /* @28 */	jint componentSize;
    /* @32 */	jbyte_array * JVM_FIELD_CONST dataB;
    /* @36 */	jshort_array * JVM_FIELD_CONST dataS;
    /* @40 */	jfloat_array * JVM_FIELD_CONST dataF;
};

struct Java_javax_microedition_m3g_World {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1092;
    /* @71 */	jbyte ___pad1093;
    /* javax/microedition/m3g/Group */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST children;
    /* javax/microedition/m3g/World */
    /* @76 */	struct Java_javax_microedition_m3g_Camera * JVM_FIELD_CONST activeCamera;
    /* @80 */	struct Java_javax_microedition_m3g_Background * JVM_FIELD_CONST background;
};

struct Java_javax_microedition_m3g_RayIntersection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/RayIntersection */
    /*  @4 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST intersected;
    /*  @8 */	jfloat distance;
    /* @12 */	jint submeshIndex;
    /* @16 */	jfloat_array * JVM_FIELD_CONST normal;
    /* @20 */	jfloat_array * JVM_FIELD_CONST ray;
    /* @24 */	jfloat_array * JVM_FIELD_CONST texS;
    /* @28 */	jfloat_array * JVM_FIELD_CONST texT;
};

struct Java_javax_microedition_m3g_Group {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1094;
    /* @71 */	jbyte ___pad1095;
    /* javax/microedition/m3g/Group */
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST children;
};

struct Java_javax_microedition_m3g_Mesh {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1096;
    /* @71 */	jbyte ___pad1097;
    /* javax/microedition/m3g/Mesh */
    /* @72 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST vertices;
    /* @76 */	jobject_array * JVM_FIELD_CONST submeshes;
    /* @80 */	jobject_array * JVM_FIELD_CONST appearances;
};

struct Java_javax_microedition_m3g_Loader_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Loader$1 */
};

struct Java_javax_microedition_m3g_Loader_00024MeshHeader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Loader$MeshHeader */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @12 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @16 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @20 */	jfloat angle;
    /* @24 */	jfloat_array * JVM_FIELD_CONST axis;
    /* @28 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* @32 */	jfloat alpha;
    /* @36 */	jint scope;
    /* @40 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST vertices;
    /* @44 */	jobject_array * JVM_FIELD_CONST submeshes;
    /* @48 */	jobject_array * JVM_FIELD_CONST appearances;
    /* @52 */	jboolean rendering;
    /* @53 */	jboolean picking;
    /* @54 */	jbyte ___pad1098;
    /* @55 */	jbyte ___pad1099;
};

struct Java_javax_microedition_m3g_Loader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Loader */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint pos;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST objects;
    /* @16 */	jboolean_array * JVM_FIELD_CONST referenced;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST referencedIdx;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST baseName;
    /* @28 */	jboolean headerIndexed;
    /* @29 */	jbyte ___pad1100;
    /* @30 */	jbyte ___pad1101;
    /* @31 */	jbyte ___pad1102;
};

struct Java_javax_microedition_m3g_MorphingMesh {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1103;
    /* @71 */	jbyte ___pad1104;
    /* javax/microedition/m3g/Mesh */
    /* @72 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST vertices;
    /* @76 */	jobject_array * JVM_FIELD_CONST submeshes;
    /* @80 */	jobject_array * JVM_FIELD_CONST appearances;
    /* javax/microedition/m3g/MorphingMesh */
    /* @84 */	jobject_array * JVM_FIELD_CONST targets;
    /* @88 */	jfloat_array * JVM_FIELD_CONST weights;
    /* @92 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST deformed;
    /* @96 */	jboolean dirty;
    /* @97 */	jbyte ___pad1105;
    /* @98 */	jbyte ___pad1106;
    /* @99 */	jbyte ___pad1107;
};

struct Java_javax_microedition_m3g_SkinnedMesh_00024Bone {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/SkinnedMesh$Bone */
    /*  @4 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST node;
    /*  @8 */	jint weight;
    /* @12 */	jint firstVertex;
    /* @16 */	jint numVertices;
    /* @20 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST meshToBoneAtRest;
};

struct Java_javax_microedition_m3g_SkinnedMesh_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/SkinnedMesh$1 */
};

struct Java_javax_microedition_m3g_SkinnedMesh {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/Transformable */
    /* @20 */	jfloat_array * JVM_FIELD_CONST translation;
    /* @24 */	jfloat orientationAngle;
    /* @28 */	jfloat_array * JVM_FIELD_CONST orientationAxis;
    /* @32 */	jfloat_array * JVM_FIELD_CONST scale;
    /* @36 */	struct Java_javax_microedition_m3g_Transform * JVM_FIELD_CONST generic;
    /* javax/microedition/m3g/Node */
    /* @40 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST parent;
    /* @44 */	jfloat alphaFactor;
    /* @48 */	jint scope;
    /* @52 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST zReference;
    /* @56 */	struct Java_javax_microedition_m3g_Node * JVM_FIELD_CONST yReference;
    /* @60 */	jint zTarget;
    /* @64 */	jint yTarget;
    /* @68 */	jboolean renderingEnabled;
    /* @69 */	jboolean pickingEnabled;
    /* @70 */	jbyte ___pad1108;
    /* @71 */	jbyte ___pad1109;
    /* javax/microedition/m3g/Mesh */
    /* @72 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST vertices;
    /* @76 */	jobject_array * JVM_FIELD_CONST submeshes;
    /* @80 */	jobject_array * JVM_FIELD_CONST appearances;
    /* javax/microedition/m3g/SkinnedMesh */
    /* @84 */	struct Java_javax_microedition_m3g_Group * JVM_FIELD_CONST skeleton;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST bones;
    /* @92 */	struct Java_javax_microedition_m3g_VertexBuffer * JVM_FIELD_CONST deformed;
};

struct Java_javax_microedition_m3g_TriangleStripArray {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Object3D */
    /*  @4 */	jint userID;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST userObject;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST tracks;
    /* @16 */	jint animatePass;
    /* javax/microedition/m3g/IndexBuffer */
    /* @20 */	jint_array * JVM_FIELD_CONST indices;
    /* @24 */	jint_array * JVM_FIELD_CONST stripLengths;
    /* @28 */	jint firstIndex;
    /* javax/microedition/m3g/TriangleStripArray */
};

struct Java_javax_microedition_m3g_M3GNative {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/M3GNative */
};

struct Java_javax_microedition_m3g_MathUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/MathUtil */
};

struct Java_javax_microedition_m3g_Picker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m3g/Picker */
    /*  @4 */	jint scope;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST ray;
    /* @12 */	jfloat bestT;
    /* @16 */	struct Java_javax_microedition_m3g_Mesh * JVM_FIELD_CONST bestMesh;
    /* @20 */	jint bestSubmesh;
    /* @24 */	jfloat_array * JVM_FIELD_CONST bestNormal;
    /* @28 */	jfloat_array * JVM_FIELD_CONST bestS;
    /* @32 */	jfloat_array * JVM_FIELD_CONST bestT2;
    /* @36 */	jint_array * JVM_FIELD_CONST outIdx;
    /* @40 */	jfloat_array * JVM_FIELD_CONST outHit;
    /* @44 */	jboolean found;
    /* @45 */	jbyte ___pad1110;
    /* @46 */	jbyte ___pad1111;
    /* @47 */	jbyte ___pad1112;
};

struct Java_javax_microedition_media_Manager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Manager */
};

struct Java_javax_microedition_media_SystemTimeBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/SystemTimeBase */
};

struct Java_javax_microedition_media_control_MetaDataControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/MetaDataControl */
};

struct Java_javax_microedition_midlet_MIDlet_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet$SecurityTrusted */
};

struct Java_javax_microedition_midlet_MIDletTunnelImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDletTunnelImpl */
};

struct Java_javax_microedition_rms_RecordListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordListener */
};

struct Java_javax_microedition_rms_RecordEnumerationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumerationImpl */
    /*  @4 */	struct Java_javax_microedition_rms_RecordStore * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_javax_microedition_rms_RecordFilter * JVM_FIELD_CONST filter;
    /* @12 */	struct Java_javax_microedition_rms_RecordComparator * JVM_FIELD_CONST comparator;
    /* @16 */	jint index;
    /* @20 */	jint_array * JVM_FIELD_CONST records;
    /* @24 */	jboolean keepEnumUpdated;
    /* @25 */	jbyte ___pad1113;
    /* @26 */	jbyte ___pad1114;
    /* @27 */	jbyte ___pad1115;
};

struct Java_javax_microedition_rms_RecordStore_000241 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordStore$1 */
};

struct Java_javax_microedition_rms_RecordStore_00024SecurityTrusted {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordStore$SecurityTrusted */
};

struct Java_javax_microedition_rms_RecordStoreNotOpenException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotOpenException */
};

struct Java_javax_xml_parsers_FactoryConfigurationError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* javax/xml/parsers/FactoryConfigurationError */
};

struct Java_javax_xml_rpc_NamespaceConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/rpc/NamespaceConstants */
};

struct Java_javax_xml_rpc_Stub {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/rpc/Stub */
};

struct Java_org_xml_sax_SAXNotSupportedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXNotSupportedException */
};

#ifdef __cplusplus
}
#endif

#endif /*_ROM_STRUCTS_H_*/
